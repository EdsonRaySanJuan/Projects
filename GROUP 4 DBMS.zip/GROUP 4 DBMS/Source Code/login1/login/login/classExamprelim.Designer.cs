﻿namespace login
{
    partial class classExamprelim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label2 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtPCSG = new TextBox();
            txtPEG = new TextBox();
            label7 = new Label();
            label8 = new Label();
            button2 = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label3.ForeColor = Color.Blue;
            label3.Location = new Point(26, 66);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(191, 24);
            label3.TabIndex = 6;
            label3.Text = "Course Subject: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label2.Location = new Point(26, 42);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(145, 24);
            label2.TabIndex = 5;
            label2.Text = "Prelim Exam";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label5.Location = new Point(26, 128);
            label5.Margin = new Padding(6, 0, 6, 0);
            label5.Name = "label5";
            label5.Size = new Size(156, 25);
            label5.TabIndex = 8;
            label5.Text = "Prelim CS Grade";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label6.Location = new Point(126, 128);
            label6.Margin = new Padding(6, 0, 6, 0);
            label6.Name = "label6";
            label6.Size = new Size(0, 25);
            label6.TabIndex = 9;
            // 
            // txtPCSG
            // 
            txtPCSG.BackColor = Color.White;
            txtPCSG.BorderStyle = BorderStyle.None;
            txtPCSG.Cursor = Cursors.IBeam;
            txtPCSG.Location = new Point(342, 128);
            txtPCSG.Multiline = true;
            txtPCSG.Name = "txtPCSG";
            txtPCSG.Size = new Size(62, 28);
            txtPCSG.TabIndex = 20;
            txtPCSG.TextChanged += txtQuiz_TextChanged;
            // 
            // txtPEG
            // 
            txtPEG.BackColor = Color.White;
            txtPEG.BorderStyle = BorderStyle.None;
            txtPEG.Cursor = Cursors.IBeam;
            txtPEG.Location = new Point(342, 171);
            txtPEG.Multiline = true;
            txtPEG.Name = "txtPEG";
            txtPEG.Size = new Size(62, 28);
            txtPEG.TabIndex = 23;
            txtPEG.TextChanged += textBox1_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label7.Location = new Point(126, 171);
            label7.Margin = new Padding(6, 0, 6, 0);
            label7.Name = "label7";
            label7.Size = new Size(0, 25);
            label7.TabIndex = 22;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label8.Location = new Point(26, 171);
            label8.Margin = new Padding(6, 0, 6, 0);
            label8.Name = "label8";
            label8.Size = new Size(300, 25);
            label8.TabIndex = 21;
            label8.Text = "Enter your Prelim desired grade:";
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(236, 223);
            button2.Name = "button2";
            button2.Size = new Size(88, 47);
            button2.TabIndex = 25;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(108, 223);
            button1.Name = "button1";
            button1.Size = new Size(88, 47);
            button1.TabIndex = 24;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // classExamprelim
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.th__1___2_;
            ClientSize = new Size(440, 290);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtPEG);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(txtPCSG);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "classExamprelim";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Prelim Exam";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private Label label2;
        private Label label5;
        private Label label6;
        private TextBox txtPCSG;
        private TextBox txtPEG;
        private Label label7;
        private Label label8;
        private Button button2;
        private Button button1;
    }
}