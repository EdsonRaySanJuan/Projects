﻿using System;
using System.Collections.Generic; // Required for List<>
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text; // Required for StringBuilder
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // For Debug.WriteLine

// Required for SQL Server interaction
using Microsoft.Data.SqlClient;

namespace login
{
    public partial class dashboard : Form
    {
        private string currentStudentID;
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        public dashboard(string studentId)
        {
            InitializeComponent();
            this.currentStudentID = studentId;
            this.Text = $"Dashboard - Student ID: {this.currentStudentID}";
        }

        private bool CheckStudentDetailsExist(int studentId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM dbo.student_details WHERE studentID = @StudentID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentId);
                    try
                    {
                        con.Open();
                        int count = (int)cmd.ExecuteScalar();
                        return count > 0;
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Dashboard CheckDetails: Error checking student details existence: {ex.Message}");
                        MessageBox.Show("Error checking student details.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) // Student Operations
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot open student section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int studentIdNumeric;
            if (!int.TryParse(this.currentStudentID, out studentIdNumeric))
            {
                MessageBox.Show("Invalid Student ID format. Cannot open student section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"Dashboard: Failed to parse student ID '{this.currentStudentID}' to int.");
                return;
            }
            bool detailsExist = CheckStudentDetailsExist(studentIdNumeric);
            student_op.Mode formMode = detailsExist ? student_op.Mode.Edit : student_op.Mode.Add;
            student_op studentForm = new student_op(studentIdNumeric, this, formMode);
            studentForm.Show();
            this.Hide();
        }

        private void buttonCourse_Click(object sender, EventArgs e) // Course Operations
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot open course section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            firstpartcourse courseForm = new firstpartcourse(this.currentStudentID, this);
            courseForm.Show();
            this.Hide();
        }

        private void buttonGoal_Click(object sender, EventArgs e) // Goal Operations
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot open goals section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int studentIdNumeric;
            if (!int.TryParse(this.currentStudentID, out studentIdNumeric))
            {
                MessageBox.Show("Invalid Student ID format. Cannot open goals section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            goals_op goalsForm = new goals_op(studentIdNumeric, this);
            goalsForm.ShowDialog();
        }

        // --- INTEGRATED SUMMARY BUTTON FUNCTIONALITY ---
        private void button1_Click_1(object sender, EventArgs e) // Summary Button
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot display summary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int studentIdNumeric;
            if (!int.TryParse(this.currentStudentID, out studentIdNumeric))
            {
                MessageBox.Show("Invalid Student ID format. Cannot display summary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"Dashboard Summary: Failed to parse student ID '{this.currentStudentID}' to int.");
                return;
            }

            StringBuilder summaryOutput = new StringBuilder();

            FetchAndAppendStudentDetails(studentIdNumeric, summaryOutput);
            summaryOutput.AppendLine();

            FetchAndAppendGradesSummary(studentIdNumeric, summaryOutput);

            MessageBox.Show(summaryOutput.ToString(), "Student Academic Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void FetchAndAppendStudentDetails(int studentId, StringBuilder summary)
        {
            summary.AppendLine("--- Student Details ---");
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT student_name, email, program, year_level FROM dbo.student_details WHERE studentID = @StudentID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentId);
                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                summary.AppendLine($"Name:         {reader["student_name"]}");
                                summary.AppendLine($"Email:        {reader["email"]}");
                                summary.AppendLine($"Program:      {reader["program"]}");
                                summary.AppendLine($"Year Level:   {reader["year_level"]}");
                            }
                            else
                            {
                                summary.AppendLine("No personal details found for this student.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        summary.AppendLine($"Error fetching student details: {ex.Message}");
                        Debug.WriteLine($"Dashboard Summary - Error fetching student details: {ex.ToString()}");
                    }
                }
            }
            summary.AppendLine("-----------------------");
        }

        private void FetchAndAppendGradesSummary(int studentId, StringBuilder summary)
        {
            summary.AppendLine("--- Academic Records ---");
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // MODIFIED QUERY: Temporarily removed join to dbo.Courses
                // This is because dbo.AcademicPeriods does not have a CourseID to link with dbo.Courses directly.
                // We need to clarify the schema link between AcademicPeriodID and a specific CourseID from dbo.Courses.
                // For now, grades will be grouped by tg.CourseID (which is AcademicPeriodID).
                string query = @"
                    SELECT
                        tg.CourseID AS AcademicPeriodID_From_TermGrades, -- Displaying this instead of CourseName/Code
                        tg.TermName,
                        tg.TotalClassStandingRaw,
                        tg.ExamScore,
                        tg.CalculatedTermGrade
                    FROM
                        dbo.TermGrades tg
                    INNER JOIN
                        dbo.AcademicPeriods ap ON tg.CourseID = ap.AcademicPeriodID 
                    WHERE
                        ap.StudentID = @StudentID
                    ORDER BY
                        tg.CourseID, 
                        CASE tg.TermName
                            WHEN 'Prelim' THEN 1
                            WHEN 'Midterm' THEN 2
                            WHEN 'Finals' THEN 3
                            ELSE 4
                        END";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentId);
                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                summary.AppendLine("No academic records found for this student.");
                            }
                            else
                            {
                                string currentAcademicPeriodID = null;
                                bool hasPrelimOrMidterm = false;
                                Dictionary<string, List<string>> periodGrades = new Dictionary<string, List<string>>();

                                while (reader.Read())
                                {
                                    // Using AcademicPeriodID for grouping since CourseName/Code is not available with current schema understanding
                                    string periodIdStr = reader["AcademicPeriodID_From_TermGrades"].ToString();
                                    string termName = reader["TermName"].ToString();

                                    if (termName == "Prelim" || termName == "Midterm")
                                    {
                                        if (!periodGrades.ContainsKey(periodIdStr))
                                        {
                                            periodGrades[periodIdStr] = new List<string>();
                                        }
                                        StringBuilder termDetails = new StringBuilder();
                                        termDetails.AppendLine($"  Term: {termName}");
                                        termDetails.AppendLine($"    Class Standing (Raw):   {FormatGrade(reader["TotalClassStandingRaw"])}");
                                        termDetails.AppendLine($"    Exam Score:             {FormatGrade(reader["ExamScore"])}");
                                        termDetails.AppendLine($"    Calculated Term Grade:  {FormatGrade(reader["CalculatedTermGrade"])}");
                                        periodGrades[periodIdStr].Add(termDetails.ToString());
                                        hasPrelimOrMidterm = true;
                                    }
                                }

                                if (!hasPrelimOrMidterm && !periodGrades.Any())
                                {
                                    summary.AppendLine("No Prelim or Midterm academic records found for this student.");
                                }
                                else
                                {
                                    bool firstPeriodOutput = true;
                                    foreach (var periodEntry in periodGrades)
                                    {
                                        if (!firstPeriodOutput)
                                        {
                                            summary.AppendLine("  --------------------");
                                        }
                                        summary.AppendLine($"\nAcademic Period ID (from TermGrades.CourseID): {periodEntry.Key}");
                                        summary.AppendLine("  (Course Name/Code unavailable with current schema info)"); // Reminder
                                        foreach (var gradeDetail in periodEntry.Value)
                                        {
                                            summary.Append(gradeDetail);
                                        }
                                        firstPeriodOutput = false;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        summary.AppendLine($"\nError fetching academic records: {ex.Message}");
                        Debug.WriteLine($"Dashboard Summary - Error fetching academic records: {ex.ToString()}");
                    }
                }
            }
            summary.AppendLine("------------------------");
        }

        private string FormatGrade(object gradeObj)
        {
            if (gradeObj == DBNull.Value || gradeObj == null)
            {
                return "N/A";
            }
            try
            {
                return Convert.ToDecimal(gradeObj).ToString("F2") + "%";
            }
            catch (FormatException)
            {
                return "Invalid Data";
            }
        }
    }

    // Placeholder for other forms - ensure their actual definitions exist
    // public partial class student_op : Form { public enum Mode { Add, Edit } /* ... */ }
    // public partial class firstpartcourse : Form { /* ... */ }
    // public partial class goals_op : Form { /* ... */ }
}