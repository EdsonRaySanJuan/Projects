﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // Make sure you are using the correct SQL Client namespace
using System.Diagnostics;

namespace login
{
    // CourseDetails class definition (ensure this is accessible - ideally in a separate file)
    // It should now include the AcademicPeriodId property.
    /*
    public class CourseDetails
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int Units { get; set; }
        public string SchoolYear { get; set; }
        public string Semester { get; set; }
        public int CourseNumber { get; set; }
        public int AcademicPeriodId { get; set; } // Make sure this is here
        // Add other relevant properties like Grade if needed later
    }
    */

    public partial class selectterm : Form
    {
        // Field to store the list of courses passed from the previous forms
        private List<CourseDetails> _allCourses;

        // *** NEW: Reference back to the form that opened selectterm (course_opX) ***
        internal Form previousForm;

        // *** NEW: Reference to the Dashboard form ***
        private Form dashboardForm;

        // Connection string for your database (make sure this matches your database)
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";


        // --- Modified Constructors ---

        // *** NEW: Constructor to receive courses, previous form, AND dashboard ***
        // This constructor is called from the last course_opX form.
        public selectterm(List<CourseDetails> courses, Form callingForm, Form dashboard) // *** Added callingForm and dashboard parameters ***
        {
            InitializeComponent();
            this._allCourses = courses; // Store the received list
            this.previousForm = callingForm; // *** Store the previous form (course_opX) ***
            this.dashboardForm = dashboard; // *** Store the dashboard reference ***

            // Populate the ComboBox with term options when the form is initialized
            PopulateTermComboBox();

            // Optional: You can display the courses here if needed
        }


        // Keep the parameterless constructor (if needed, but data and form references will be null)
        public selectterm()
        {
            InitializeComponent();
            PopulateTermComboBox();
            this.Load += (s, e) => {
                // Handle initialization when data or form references are missing
                if (_allCourses == null || previousForm == null || dashboardForm == null)
                {
                    MessageBox.Show("Warning: selectterm form initialized without required data or form references.", "Initialization Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // Optionally disable submit button if essential data/references are missing
                    Control[] foundBtn1 = this.Controls.Find("button1", true);
                    if (foundBtn1.Length > 0 && foundBtn1[0] is Button btn1) btn1.Enabled = false;
                }
            };
        }


        // Method to populate the ComboBox (assuming 'comboBox1')
        private void PopulateTermComboBox()
        {
            Control[] foundComboBox = this.Controls.Find("comboBox1", true);
            if (foundComboBox.Length > 0 && foundComboBox[0] is ComboBox comboBox1Control)
            {
                comboBox1Control.Items.Clear();
                comboBox1Control.Items.Add("Prelim");
                comboBox1Control.Items.Add("Midterm");
                comboBox1Control.Items.Add("Finals");
                comboBox1Control.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            else
            {
                MessageBox.Show("Configuration Error: 'comboBox1' not found on the form.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Control[] foundBtn1 = this.Controls.Find("button1", true);
                if (foundBtn1.Length > 0 && foundBtn1[0] is Button btn1) btn1.Enabled = false;
            }
        }

        // --- Event Handlers for Buttons ---

        // Submit button (button1_Click_1) - Modified to save data and navigate
        private void button1_Click_1(object sender, EventArgs e)
        {
            Control[] foundComboBox = this.Controls.Find("comboBox1", true);
            ComboBox comboBox1Control = null;
            if (foundComboBox.Length > 0 && foundComboBox[0] is ComboBox cb)
            {
                comboBox1Control = cb;
            }
            else
            {
                MessageBox.Show("Configuration Error: 'comboBox1' not found on the form.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedTerm = comboBox1Control.SelectedItem?.ToString();

            // Validate that a term has been selected
            if (string.IsNullOrWhiteSpace(selectedTerm))
            {
                MessageBox.Show("Please select a term.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                comboBox1Control.Focus();
                return;
            }

            // Ensure course data and form references were received
            if (_allCourses == null || _allCourses.Count == 0)
            {
                MessageBox.Show("No course data to save.", "Data Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Decide where to navigate if no data (maybe back to selectcourse without data?)
                NavigateToSelectCourse(selectedTerm); // Still attempt navigation even if no data to process
                return;
            }

            if (previousForm == null || dashboardForm == null)
            {
                MessageBox.Show("Form references are missing. Cannot proceed with navigation.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // --- Database Saving Logic ---
            bool saveSuccessful = SaveCoursesToDatabase(this._allCourses, selectedTerm);

            if (saveSuccessful)
            {
                MessageBox.Show($"Course data for {selectedTerm} saved successfully!", "Save Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Proceed with navigation after successful save
                NavigateToSelectCourse(selectedTerm); // Navigate back to selectcourse, passing the selected term
            }
            else
            {
                MessageBox.Show("Failed to save course data.", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Decide where to navigate after save failure (maybe stay on selectterm or go back?)
                this.Show(); // Ensure this form is visible
            }
        }


        // --- Method to save courses to the database (from previous discussion) ---
        private bool SaveCoursesToDatabase(List<CourseDetails> courses, string term)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Loop through the list of courses and insert each one
                    foreach (var course in courses)
                    {
                        // *** IMPORTANT: Update the SQL INSERT statement and column names ***
                        // *** to include AcademicPeriodId and match your actual table. ***
                        string query = @"INSERT INTO Courses (SchoolYear, Semester, CourseNumber, CourseCode, CourseName, Units, Term, AcademicPeriodId)
                                         VALUES (@SchoolYear, @Semester, @CourseNumber, @CourseCode, @CourseName, @Units, @Term, @AcademicPeriodId)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Add parameters to prevent SQL injection
                            command.Parameters.AddWithValue("@SchoolYear", course.SchoolYear);
                            command.Parameters.AddWithValue("@Semester", course.Semester);
                            command.Parameters.AddWithValue("@CourseNumber", course.CourseNumber);
                            command.Parameters.AddWithValue("@CourseCode", course.Code);
                            command.Parameters.AddWithValue("@CourseName", course.Name);
                            command.Parameters.AddWithValue("@Units", course.Units);
                            command.Parameters.AddWithValue("@Term", term); // Save the selected term with each course
                            command.Parameters.AddWithValue("@AcademicPeriodId", course.AcademicPeriodId); // *** NEW: Add AcademicPeriodId parameter ***

                            command.ExecuteNonQuery(); // Execute the insert command
                        }
                    }

                    return true; // Save successful
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show($"Database Error: {sqlEx.Message}\nSQL: {sqlEx.StackTrace}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debug.WriteLine($"SQL Error during save: {sqlEx.Message}\n{sqlEx.StackTrace}");
                    return false; // Save failed
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An unexpected error occurred during database save: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debug.WriteLine($"General Error during save: {ex.Message}\n{ex.StackTrace}");
                    return false; // Save failed
                }
            }
        }

        // --- Method to handle navigation back to selectcourse and closing previous forms (from previous discussion) ---
        private void NavigateToSelectCourse(string termSelected) // Pass the selected term to indicate context
        {
            try
            {
                // Find the existing selectcourse form or create a new one
                // Use the constructor that passes the data and the selected term
                // *** IMPORTANT: selectcourse MUST have the constructor: public selectcourse(List<CourseDetails> courses, string term, Form dashboard) ***
                selectcourse initialCourseForm = Application.OpenForms.OfType<selectcourse>().FirstOrDefault();

                if (initialCourseForm != null)
                {
                    // If selectcourse was already open, show it and update its data
                    // You need a method in selectcourse to receive and process this data
                    // Example: initialCourseForm.LoadTermData(this._allCourses, termSelected); // Add this method to selectcourse.cs
                    initialCourseForm.Show();
                }
                else
                {
                    // If selectcourse was closed, create a new instance with the data
                    // Use the constructor that accepts the data and dashboard
                    initialCourseForm = new selectcourse(this._allCourses, termSelected, this.dashboardForm);
                    initialCourseForm.Show();
                }

                // Hide the current form (selectterm)
                this.Hide();

                // Close the chain of previous forms (course_opX, ..., firstpartcourse)
                // Use the previousForm references to traverse back, starting from the form that opened selectterm.
                Form current = this.previousForm; // Start with the form that opened selectterm (course_op9 or the last one)
                while (current != null)
                {
                    Form formToClose = current;
                    // Safely try to get the 'previousForm' property using Reflection
                    var prevFormProperty = current.GetType().GetField("previousForm", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);

                    Form nextPrevious = null;
                    if (prevFormProperty != null)
                    {
                        nextPrevious = prevFormProperty.GetValue(current) as Form;
                    }

                    // Close the current form in the chain (most forms should have a Close method)
                    formToClose.Close();
                    current = nextPrevious; // Move to the form before the current one in the chain
                }

                // Finally, close the current form (selectterm)
                this.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred during navigation: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"Navigation Error: {ex.Message}\n{ex.StackTrace}");
                this.Show(); // Stay on the current form if navigation failed
            }
        }


        // Clear button (button2_Click_1)
        private void button2_Click_1(object sender, EventArgs e)
        {
            Control[] foundComboBox = this.Controls.Find("comboBox1", true);
            if (foundComboBox.Length > 0 && foundComboBox[0] is ComboBox comboBox1Control)
            {
                comboBox1Control.SelectedIndex = -1;
                if (comboBox1Control.DropDownStyle == ComboBoxStyle.DropDown)
                {
                    comboBox1Control.Text = "";
                }
                comboBox1Control.Focus();
            }
            else
            {
                MessageBox.Show("Configuration Error: 'comboBox1' not found on the form.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ComboBox SelectedIndexChanged event handler
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Add logic here if needed
        }

        // --- Removed unused button click event handlers ---
        // private void button1_Click(object sender, EventArgs e) { }
        // private void button2_Click(object sender, EventArgs e) { }
        // private void btnPrelim_Click(object sender, EventArgs e) { }
        // private void btnMidterm_Click(object sender, EventArgs e) { }
        // private void btnFinals_Click(object sender, EventArgs e) { }

    }
}