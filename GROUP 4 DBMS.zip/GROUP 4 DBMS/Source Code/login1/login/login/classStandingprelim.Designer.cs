﻿namespace login
{
    partial class classStandingprelim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            txtRecitationWeight = new TextBox();
            txtRecitationScore10 = new TextBox();
            txtRecitationScore9 = new TextBox();
            txtRecitationScore8 = new TextBox();
            txtRecitationScore7 = new TextBox();
            txtRecitationScore6 = new TextBox();
            txtRecitationScore5 = new TextBox();
            txtQuizScore1 = new TextBox();
            txtQuizScore2 = new TextBox();
            txtQuizScore3 = new TextBox();
            txtQuizScore4 = new TextBox();
            txtQuizScore5 = new TextBox();
            txtQuizScore6 = new TextBox();
            txtQuizScore7 = new TextBox();
            txtQuizScore8 = new TextBox();
            txtQuizScore9 = new TextBox();
            txtQuizScore10 = new TextBox();
            txtAssignmentScore1 = new TextBox();
            txtAssignmentScore2 = new TextBox();
            txtAssignmentScore3 = new TextBox();
            txtAssignmentScore4 = new TextBox();
            txtAssignmentScore5 = new TextBox();
            txtAssignmentScore6 = new TextBox();
            txtAssignmentScore7 = new TextBox();
            txtAssignmentScore8 = new TextBox();
            txtAssignmentScore9 = new TextBox();
            txtAssignmentScore10 = new TextBox();
            txtSeatworkScore1 = new TextBox();
            txtSeatworkScore2 = new TextBox();
            txtSeatworkScore3 = new TextBox();
            txtSeatworkScore4 = new TextBox();
            txtSeatworkScore5 = new TextBox();
            txtSeatworkScore6 = new TextBox();
            txtSeatworkScore7 = new TextBox();
            txtSeatworkScore8 = new TextBox();
            txtSeatworkScore9 = new TextBox();
            txtSeatworkScore10 = new TextBox();
            txtLaboratoryScore1 = new TextBox();
            txtLaboratoryScore2 = new TextBox();
            txtLaboratoryScore3 = new TextBox();
            txtLaboratoryScore4 = new TextBox();
            txtLaboratoryScore5 = new TextBox();
            txtLaboratoryScore6 = new TextBox();
            txtLaboratoryScore7 = new TextBox();
            txtLaboratoryScore8 = new TextBox();
            txtLaboratoryScore9 = new TextBox();
            txtLaboratoryScore10 = new TextBox();
            txtRecitationScore1 = new TextBox();
            txtRecitationScore2 = new TextBox();
            txtRecitationScore3 = new TextBox();
            txtRecitationScore4 = new TextBox();
            txtLaboratoryWeight = new TextBox();
            txtSeatworkWeight = new TextBox();
            txtAssignmentWeight = new TextBox();
            txtQuizWeight = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label12 = new Label();
            label13 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Font = new Font("MS UI Gothic", 12F, FontStyle.Bold);
            button2.Location = new Point(495, 501);
            button2.Name = "button2";
            button2.Size = new Size(89, 41);
            button2.TabIndex = 263;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("MS UI Gothic", 12F, FontStyle.Bold);
            button1.Location = new Point(375, 501);
            button1.Name = "button1";
            button1.Size = new Size(89, 41);
            button1.TabIndex = 262;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtRecitationWeight
            // 
            txtRecitationWeight.Location = new Point(874, 104);
            txtRecitationWeight.Multiline = true;
            txtRecitationWeight.Name = "txtRecitationWeight";
            txtRecitationWeight.Size = new Size(51, 23);
            txtRecitationWeight.TabIndex = 261;
            txtRecitationWeight.TextChanged += txtRecitationWeight_TextChanged;
            // 
            // txtRecitationScore10
            // 
            txtRecitationScore10.Location = new Point(781, 406);
            txtRecitationScore10.Multiline = true;
            txtRecitationScore10.Name = "txtRecitationScore10";
            txtRecitationScore10.Size = new Size(120, 23);
            txtRecitationScore10.TabIndex = 260;
            txtRecitationScore10.TextChanged += txtRecitationScore10_TextChanged;
            // 
            // txtRecitationScore9
            // 
            txtRecitationScore9.Location = new Point(781, 377);
            txtRecitationScore9.Multiline = true;
            txtRecitationScore9.Name = "txtRecitationScore9";
            txtRecitationScore9.Size = new Size(120, 23);
            txtRecitationScore9.TabIndex = 259;
            txtRecitationScore9.TextChanged += txtRecitationScore9_TextChanged;
            // 
            // txtRecitationScore8
            // 
            txtRecitationScore8.Location = new Point(781, 348);
            txtRecitationScore8.Multiline = true;
            txtRecitationScore8.Name = "txtRecitationScore8";
            txtRecitationScore8.Size = new Size(120, 23);
            txtRecitationScore8.TabIndex = 258;
            txtRecitationScore8.TextChanged += txtRecitationScore8_TextChanged;
            // 
            // txtRecitationScore7
            // 
            txtRecitationScore7.Location = new Point(781, 319);
            txtRecitationScore7.Multiline = true;
            txtRecitationScore7.Name = "txtRecitationScore7";
            txtRecitationScore7.Size = new Size(120, 23);
            txtRecitationScore7.TabIndex = 257;
            txtRecitationScore7.TextChanged += txtRecitationScore7_TextChanged;
            // 
            // txtRecitationScore6
            // 
            txtRecitationScore6.Location = new Point(781, 290);
            txtRecitationScore6.Multiline = true;
            txtRecitationScore6.Name = "txtRecitationScore6";
            txtRecitationScore6.Size = new Size(120, 23);
            txtRecitationScore6.TabIndex = 256;
            txtRecitationScore6.TextChanged += txtRecitationScore6_TextChanged;
            // 
            // txtRecitationScore5
            // 
            txtRecitationScore5.Location = new Point(781, 261);
            txtRecitationScore5.Multiline = true;
            txtRecitationScore5.Name = "txtRecitationScore5";
            txtRecitationScore5.Size = new Size(120, 23);
            txtRecitationScore5.TabIndex = 255;
            txtRecitationScore5.TextChanged += txtRecitationScore5_TextChanged;
            // 
            // txtQuizScore1
            // 
            txtQuizScore1.Location = new Point(26, 145);
            txtQuizScore1.Multiline = true;
            txtQuizScore1.Name = "txtQuizScore1";
            txtQuizScore1.Size = new Size(120, 23);
            txtQuizScore1.TabIndex = 211;
            txtQuizScore1.TextChanged += txtQuizScore1_TextChanged;
            // 
            // txtQuizScore2
            // 
            txtQuizScore2.Location = new Point(26, 174);
            txtQuizScore2.Multiline = true;
            txtQuizScore2.Name = "txtQuizScore2";
            txtQuizScore2.Size = new Size(120, 23);
            txtQuizScore2.TabIndex = 212;
            txtQuizScore2.TextChanged += txtQuizScore2_TextChanged;
            // 
            // txtQuizScore3
            // 
            txtQuizScore3.Location = new Point(26, 203);
            txtQuizScore3.Multiline = true;
            txtQuizScore3.Name = "txtQuizScore3";
            txtQuizScore3.Size = new Size(120, 23);
            txtQuizScore3.TabIndex = 213;
            txtQuizScore3.TextChanged += txtQuizScore3_TextChanged;
            // 
            // txtQuizScore4
            // 
            txtQuizScore4.Location = new Point(26, 232);
            txtQuizScore4.Multiline = true;
            txtQuizScore4.Name = "txtQuizScore4";
            txtQuizScore4.Size = new Size(120, 23);
            txtQuizScore4.TabIndex = 214;
            txtQuizScore4.TextChanged += txtQuizScore4_TextChanged;
            // 
            // txtQuizScore5
            // 
            txtQuizScore5.Location = new Point(26, 261);
            txtQuizScore5.Multiline = true;
            txtQuizScore5.Name = "txtQuizScore5";
            txtQuizScore5.Size = new Size(120, 23);
            txtQuizScore5.TabIndex = 215;
            txtQuizScore5.TextChanged += txtQuizScore5_TextChanged;
            // 
            // txtQuizScore6
            // 
            txtQuizScore6.Location = new Point(26, 290);
            txtQuizScore6.Multiline = true;
            txtQuizScore6.Name = "txtQuizScore6";
            txtQuizScore6.Size = new Size(120, 23);
            txtQuizScore6.TabIndex = 216;
            txtQuizScore6.TextChanged += txtQuizScore6_TextChanged;
            // 
            // txtQuizScore7
            // 
            txtQuizScore7.Location = new Point(26, 319);
            txtQuizScore7.Multiline = true;
            txtQuizScore7.Name = "txtQuizScore7";
            txtQuizScore7.Size = new Size(120, 23);
            txtQuizScore7.TabIndex = 217;
            txtQuizScore7.TextChanged += txtQuizScore7_TextChanged;
            // 
            // txtQuizScore8
            // 
            txtQuizScore8.Location = new Point(26, 348);
            txtQuizScore8.Multiline = true;
            txtQuizScore8.Name = "txtQuizScore8";
            txtQuizScore8.Size = new Size(120, 23);
            txtQuizScore8.TabIndex = 218;
            txtQuizScore8.TextChanged += txtQuizScore8_TextChanged;
            // 
            // txtQuizScore9
            // 
            txtQuizScore9.Location = new Point(26, 377);
            txtQuizScore9.Multiline = true;
            txtQuizScore9.Name = "txtQuizScore9";
            txtQuizScore9.Size = new Size(120, 23);
            txtQuizScore9.TabIndex = 219;
            txtQuizScore9.TextChanged += txtQuizScore9_TextChanged;
            // 
            // txtQuizScore10
            // 
            txtQuizScore10.Location = new Point(26, 406);
            txtQuizScore10.Multiline = true;
            txtQuizScore10.Name = "txtQuizScore10";
            txtQuizScore10.Size = new Size(120, 23);
            txtQuizScore10.TabIndex = 220;
            txtQuizScore10.TextChanged += txtQuizScore10_TextChanged;
            // 
            // txtAssignmentScore1
            // 
            txtAssignmentScore1.Location = new Point(211, 145);
            txtAssignmentScore1.Multiline = true;
            txtAssignmentScore1.Name = "txtAssignmentScore1";
            txtAssignmentScore1.Size = new Size(120, 23);
            txtAssignmentScore1.TabIndex = 221;
            txtAssignmentScore1.TextChanged += txtAssignmentScore1_TextChanged;
            // 
            // txtAssignmentScore2
            // 
            txtAssignmentScore2.Location = new Point(211, 174);
            txtAssignmentScore2.Multiline = true;
            txtAssignmentScore2.Name = "txtAssignmentScore2";
            txtAssignmentScore2.Size = new Size(120, 23);
            txtAssignmentScore2.TabIndex = 222;
            txtAssignmentScore2.TextChanged += txtAssignmentScore2_TextChanged;
            // 
            // txtAssignmentScore3
            // 
            txtAssignmentScore3.Location = new Point(211, 203);
            txtAssignmentScore3.Multiline = true;
            txtAssignmentScore3.Name = "txtAssignmentScore3";
            txtAssignmentScore3.Size = new Size(120, 23);
            txtAssignmentScore3.TabIndex = 223;
            txtAssignmentScore3.TextChanged += txtAssignmentScore3_TextChanged;
            // 
            // txtAssignmentScore4
            // 
            txtAssignmentScore4.Location = new Point(211, 232);
            txtAssignmentScore4.Multiline = true;
            txtAssignmentScore4.Name = "txtAssignmentScore4";
            txtAssignmentScore4.Size = new Size(120, 23);
            txtAssignmentScore4.TabIndex = 224;
            txtAssignmentScore4.TextChanged += txtAssignmentScore4_TextChanged;
            // 
            // txtAssignmentScore5
            // 
            txtAssignmentScore5.Location = new Point(211, 261);
            txtAssignmentScore5.Multiline = true;
            txtAssignmentScore5.Name = "txtAssignmentScore5";
            txtAssignmentScore5.Size = new Size(120, 23);
            txtAssignmentScore5.TabIndex = 225;
            txtAssignmentScore5.TextChanged += txtAssignmentScore5_TextChanged;
            // 
            // txtAssignmentScore6
            // 
            txtAssignmentScore6.Location = new Point(211, 290);
            txtAssignmentScore6.Multiline = true;
            txtAssignmentScore6.Name = "txtAssignmentScore6";
            txtAssignmentScore6.Size = new Size(120, 23);
            txtAssignmentScore6.TabIndex = 226;
            txtAssignmentScore6.TextChanged += txtAssignmentScore6_TextChanged;
            // 
            // txtAssignmentScore7
            // 
            txtAssignmentScore7.Location = new Point(211, 319);
            txtAssignmentScore7.Multiline = true;
            txtAssignmentScore7.Name = "txtAssignmentScore7";
            txtAssignmentScore7.Size = new Size(120, 23);
            txtAssignmentScore7.TabIndex = 227;
            txtAssignmentScore7.TextChanged += txtAssignmentScore7_TextChanged;
            // 
            // txtAssignmentScore8
            // 
            txtAssignmentScore8.Location = new Point(211, 348);
            txtAssignmentScore8.Multiline = true;
            txtAssignmentScore8.Name = "txtAssignmentScore8";
            txtAssignmentScore8.Size = new Size(120, 23);
            txtAssignmentScore8.TabIndex = 228;
            txtAssignmentScore8.TextChanged += txtAssignmentScore8_TextChanged;
            // 
            // txtAssignmentScore9
            // 
            txtAssignmentScore9.Location = new Point(211, 377);
            txtAssignmentScore9.Multiline = true;
            txtAssignmentScore9.Name = "txtAssignmentScore9";
            txtAssignmentScore9.Size = new Size(120, 23);
            txtAssignmentScore9.TabIndex = 229;
            txtAssignmentScore9.TextChanged += txtAssignmentScore9_TextChanged;
            // 
            // txtAssignmentScore10
            // 
            txtAssignmentScore10.Location = new Point(211, 406);
            txtAssignmentScore10.Multiline = true;
            txtAssignmentScore10.Name = "txtAssignmentScore10";
            txtAssignmentScore10.Size = new Size(120, 23);
            txtAssignmentScore10.TabIndex = 230;
            txtAssignmentScore10.TextChanged += txtAssignmentScore10_TextChanged;
            // 
            // txtSeatworkScore1
            // 
            txtSeatworkScore1.Location = new Point(396, 145);
            txtSeatworkScore1.Multiline = true;
            txtSeatworkScore1.Name = "txtSeatworkScore1";
            txtSeatworkScore1.Size = new Size(120, 23);
            txtSeatworkScore1.TabIndex = 231;
            txtSeatworkScore1.TextChanged += txtSeatworkScore1_TextChanged;
            // 
            // txtSeatworkScore2
            // 
            txtSeatworkScore2.Location = new Point(396, 174);
            txtSeatworkScore2.Multiline = true;
            txtSeatworkScore2.Name = "txtSeatworkScore2";
            txtSeatworkScore2.Size = new Size(120, 23);
            txtSeatworkScore2.TabIndex = 232;
            txtSeatworkScore2.TextChanged += txtSeatworkScore2_TextChanged;
            // 
            // txtSeatworkScore3
            // 
            txtSeatworkScore3.Location = new Point(396, 203);
            txtSeatworkScore3.Multiline = true;
            txtSeatworkScore3.Name = "txtSeatworkScore3";
            txtSeatworkScore3.Size = new Size(120, 23);
            txtSeatworkScore3.TabIndex = 233;
            txtSeatworkScore3.TextChanged += txtSeatworkScore3_TextChanged;
            // 
            // txtSeatworkScore4
            // 
            txtSeatworkScore4.Location = new Point(396, 232);
            txtSeatworkScore4.Multiline = true;
            txtSeatworkScore4.Name = "txtSeatworkScore4";
            txtSeatworkScore4.Size = new Size(120, 23);
            txtSeatworkScore4.TabIndex = 234;
            txtSeatworkScore4.TextChanged += txtSeatworkScore4_TextChanged;
            // 
            // txtSeatworkScore5
            // 
            txtSeatworkScore5.Location = new Point(396, 261);
            txtSeatworkScore5.Multiline = true;
            txtSeatworkScore5.Name = "txtSeatworkScore5";
            txtSeatworkScore5.Size = new Size(120, 23);
            txtSeatworkScore5.TabIndex = 235;
            txtSeatworkScore5.TextChanged += txtSeatworkScore5_TextChanged;
            // 
            // txtSeatworkScore6
            // 
            txtSeatworkScore6.Location = new Point(396, 290);
            txtSeatworkScore6.Multiline = true;
            txtSeatworkScore6.Name = "txtSeatworkScore6";
            txtSeatworkScore6.Size = new Size(120, 23);
            txtSeatworkScore6.TabIndex = 236;
            txtSeatworkScore6.TextChanged += txtSeatworkScore6_TextChanged;
            // 
            // txtSeatworkScore7
            // 
            txtSeatworkScore7.Location = new Point(396, 319);
            txtSeatworkScore7.Multiline = true;
            txtSeatworkScore7.Name = "txtSeatworkScore7";
            txtSeatworkScore7.Size = new Size(120, 23);
            txtSeatworkScore7.TabIndex = 237;
            txtSeatworkScore7.TextChanged += txtSeatworkScore7_TextChanged;
            // 
            // txtSeatworkScore8
            // 
            txtSeatworkScore8.Location = new Point(396, 348);
            txtSeatworkScore8.Multiline = true;
            txtSeatworkScore8.Name = "txtSeatworkScore8";
            txtSeatworkScore8.Size = new Size(120, 23);
            txtSeatworkScore8.TabIndex = 238;
            txtSeatworkScore8.TextChanged += txtSeatworkScore8_TextChanged;
            // 
            // txtSeatworkScore9
            // 
            txtSeatworkScore9.Location = new Point(396, 377);
            txtSeatworkScore9.Multiline = true;
            txtSeatworkScore9.Name = "txtSeatworkScore9";
            txtSeatworkScore9.Size = new Size(120, 23);
            txtSeatworkScore9.TabIndex = 239;
            txtSeatworkScore9.TextChanged += txtSeatworkScore9_TextChanged;
            // 
            // txtSeatworkScore10
            // 
            txtSeatworkScore10.Location = new Point(396, 406);
            txtSeatworkScore10.Multiline = true;
            txtSeatworkScore10.Name = "txtSeatworkScore10";
            txtSeatworkScore10.Size = new Size(120, 23);
            txtSeatworkScore10.TabIndex = 240;
            txtSeatworkScore10.TextChanged += txtSeatworkScore10_TextChanged;
            // 
            // txtLaboratoryScore1
            // 
            txtLaboratoryScore1.Location = new Point(591, 145);
            txtLaboratoryScore1.Multiline = true;
            txtLaboratoryScore1.Name = "txtLaboratoryScore1";
            txtLaboratoryScore1.Size = new Size(120, 23);
            txtLaboratoryScore1.TabIndex = 241;
            txtLaboratoryScore1.TextChanged += txtLaboratoryScore1_TextChanged;
            // 
            // txtLaboratoryScore2
            // 
            txtLaboratoryScore2.Location = new Point(591, 174);
            txtLaboratoryScore2.Multiline = true;
            txtLaboratoryScore2.Name = "txtLaboratoryScore2";
            txtLaboratoryScore2.Size = new Size(120, 23);
            txtLaboratoryScore2.TabIndex = 242;
            txtLaboratoryScore2.TextChanged += txtLaboratoryScore2_TextChanged;
            // 
            // txtLaboratoryScore3
            // 
            txtLaboratoryScore3.Location = new Point(591, 203);
            txtLaboratoryScore3.Multiline = true;
            txtLaboratoryScore3.Name = "txtLaboratoryScore3";
            txtLaboratoryScore3.Size = new Size(120, 23);
            txtLaboratoryScore3.TabIndex = 243;
            txtLaboratoryScore3.TextChanged += txtLaboratoryScore3_TextChanged;
            // 
            // txtLaboratoryScore4
            // 
            txtLaboratoryScore4.Location = new Point(591, 232);
            txtLaboratoryScore4.Multiline = true;
            txtLaboratoryScore4.Name = "txtLaboratoryScore4";
            txtLaboratoryScore4.Size = new Size(120, 23);
            txtLaboratoryScore4.TabIndex = 244;
            txtLaboratoryScore4.TextChanged += txtLaboratoryScore4_TextChanged;
            // 
            // txtLaboratoryScore5
            // 
            txtLaboratoryScore5.Location = new Point(591, 261);
            txtLaboratoryScore5.Multiline = true;
            txtLaboratoryScore5.Name = "txtLaboratoryScore5";
            txtLaboratoryScore5.Size = new Size(120, 23);
            txtLaboratoryScore5.TabIndex = 245;
            txtLaboratoryScore5.TextChanged += txtLaboratoryScore5_TextChanged;
            // 
            // txtLaboratoryScore6
            // 
            txtLaboratoryScore6.Location = new Point(591, 290);
            txtLaboratoryScore6.Multiline = true;
            txtLaboratoryScore6.Name = "txtLaboratoryScore6";
            txtLaboratoryScore6.Size = new Size(120, 23);
            txtLaboratoryScore6.TabIndex = 246;
            txtLaboratoryScore6.TextChanged += txtLaboratoryScore6_TextChanged;
            // 
            // txtLaboratoryScore7
            // 
            txtLaboratoryScore7.Location = new Point(591, 319);
            txtLaboratoryScore7.Multiline = true;
            txtLaboratoryScore7.Name = "txtLaboratoryScore7";
            txtLaboratoryScore7.Size = new Size(120, 23);
            txtLaboratoryScore7.TabIndex = 247;
            txtLaboratoryScore7.TextChanged += txtLaboratoryScore7_TextChanged;
            // 
            // txtLaboratoryScore8
            // 
            txtLaboratoryScore8.Location = new Point(591, 348);
            txtLaboratoryScore8.Multiline = true;
            txtLaboratoryScore8.Name = "txtLaboratoryScore8";
            txtLaboratoryScore8.Size = new Size(120, 23);
            txtLaboratoryScore8.TabIndex = 248;
            txtLaboratoryScore8.TextChanged += txtLaboratoryScore8_TextChanged;
            // 
            // txtLaboratoryScore9
            // 
            txtLaboratoryScore9.Location = new Point(591, 377);
            txtLaboratoryScore9.Multiline = true;
            txtLaboratoryScore9.Name = "txtLaboratoryScore9";
            txtLaboratoryScore9.Size = new Size(120, 23);
            txtLaboratoryScore9.TabIndex = 249;
            txtLaboratoryScore9.TextChanged += txtLaboratoryScore9_TextChanged;
            // 
            // txtLaboratoryScore10
            // 
            txtLaboratoryScore10.Location = new Point(591, 406);
            txtLaboratoryScore10.Multiline = true;
            txtLaboratoryScore10.Name = "txtLaboratoryScore10";
            txtLaboratoryScore10.Size = new Size(120, 23);
            txtLaboratoryScore10.TabIndex = 250;
            txtLaboratoryScore10.TextChanged += txtLaboratoryScore10_TextChanged;
            // 
            // txtRecitationScore1
            // 
            txtRecitationScore1.Location = new Point(781, 145);
            txtRecitationScore1.Multiline = true;
            txtRecitationScore1.Name = "txtRecitationScore1";
            txtRecitationScore1.Size = new Size(120, 23);
            txtRecitationScore1.TabIndex = 251;
            txtRecitationScore1.TextChanged += txtRecitationScore1_TextChanged;
            // 
            // txtRecitationScore2
            // 
            txtRecitationScore2.Location = new Point(781, 174);
            txtRecitationScore2.Multiline = true;
            txtRecitationScore2.Name = "txtRecitationScore2";
            txtRecitationScore2.Size = new Size(120, 23);
            txtRecitationScore2.TabIndex = 252;
            txtRecitationScore2.TextChanged += txtRecitationScore2_TextChanged;
            // 
            // txtRecitationScore3
            // 
            txtRecitationScore3.Location = new Point(781, 203);
            txtRecitationScore3.Multiline = true;
            txtRecitationScore3.Name = "txtRecitationScore3";
            txtRecitationScore3.Size = new Size(120, 23);
            txtRecitationScore3.TabIndex = 253;
            txtRecitationScore3.TextChanged += txtRecitationScore3_TextChanged;
            // 
            // txtRecitationScore4
            // 
            txtRecitationScore4.Location = new Point(781, 232);
            txtRecitationScore4.Multiline = true;
            txtRecitationScore4.Name = "txtRecitationScore4";
            txtRecitationScore4.Size = new Size(120, 23);
            txtRecitationScore4.TabIndex = 254;
            txtRecitationScore4.TextChanged += txtRecitationScore4_TextChanged;
            // 
            // txtLaboratoryWeight
            // 
            txtLaboratoryWeight.Location = new Point(691, 104);
            txtLaboratoryWeight.Multiline = true;
            txtLaboratoryWeight.Name = "txtLaboratoryWeight";
            txtLaboratoryWeight.Size = new Size(72, 23);
            txtLaboratoryWeight.TabIndex = 210;
            txtLaboratoryWeight.TextChanged += txtLaboratoryWeight_TextChanged;
            // 
            // txtSeatworkWeight
            // 
            txtSeatworkWeight.Location = new Point(483, 104);
            txtSeatworkWeight.Multiline = true;
            txtSeatworkWeight.Name = "txtSeatworkWeight";
            txtSeatworkWeight.Size = new Size(72, 23);
            txtSeatworkWeight.TabIndex = 209;
            txtSeatworkWeight.TextChanged += txtSeatworkWeight_TextChanged;
            // 
            // txtAssignmentWeight
            // 
            txtAssignmentWeight.Location = new Point(317, 104);
            txtAssignmentWeight.Multiline = true;
            txtAssignmentWeight.Name = "txtAssignmentWeight";
            txtAssignmentWeight.Size = new Size(72, 23);
            txtAssignmentWeight.TabIndex = 208;
            txtAssignmentWeight.TextChanged += txtAssignmentWeight_TextChanged;
            // 
            // txtQuizWeight
            // 
            txtQuizWeight.Location = new Point(74, 104);
            txtQuizWeight.Multiline = true;
            txtQuizWeight.Name = "txtQuizWeight";
            txtQuizWeight.Size = new Size(72, 23);
            txtQuizWeight.TabIndex = 207;
            txtQuizWeight.TextChanged += txtQuizWeight_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label9.Location = new Point(781, 109);
            label9.Name = "label9";
            label9.Size = new Size(88, 21);
            label9.TabIndex = 206;
            label9.Text = "Recitation";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.Location = new Point(591, 109);
            label8.Name = "label8";
            label8.Size = new Size(94, 21);
            label8.TabIndex = 205;
            label8.Text = "Laboratory";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.Location = new Point(396, 109);
            label7.Name = "label7";
            label7.Size = new Size(81, 21);
            label7.TabIndex = 204;
            label7.Text = "Seatwork";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.Location = new Point(211, 109);
            label6.Name = "label6";
            label6.Size = new Size(100, 21);
            label6.TabIndex = 203;
            label6.Text = "Assignment";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label12.Location = new Point(26, 109);
            label12.Name = "label12";
            label12.Size = new Size(45, 21);
            label12.TabIndex = 202;
            label12.Text = "Quiz";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(32, 102);
            label13.Name = "label13";
            label13.Size = new Size(0, 27);
            label13.TabIndex = 201;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(211, 66);
            label4.Name = "label4";
            label4.Size = new Size(73, 24);
            label4.TabIndex = 200;
            label4.Text = "label4";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label3.ForeColor = Color.Blue;
            label3.Location = new Point(26, 66);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(191, 24);
            label3.TabIndex = 199;
            label3.Text = "Course Subject: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label2.Location = new Point(26, 42);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(170, 24);
            label2.TabIndex = 198;
            label2.Text = "Class Standing";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label1.Location = new Point(26, 18);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(79, 24);
            label1.TabIndex = 197;
            label1.Text = "Prelim";
            // 
            // classStandingprelim
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.th__1___4___1_;
            ClientSize = new Size(937, 569);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtRecitationWeight);
            Controls.Add(txtRecitationScore10);
            Controls.Add(txtRecitationScore9);
            Controls.Add(txtRecitationScore8);
            Controls.Add(txtRecitationScore7);
            Controls.Add(txtRecitationScore6);
            Controls.Add(txtRecitationScore5);
            Controls.Add(txtQuizScore1);
            Controls.Add(txtQuizScore2);
            Controls.Add(txtQuizScore3);
            Controls.Add(txtQuizScore4);
            Controls.Add(txtQuizScore5);
            Controls.Add(txtQuizScore6);
            Controls.Add(txtQuizScore7);
            Controls.Add(txtQuizScore8);
            Controls.Add(txtQuizScore9);
            Controls.Add(txtQuizScore10);
            Controls.Add(txtAssignmentScore1);
            Controls.Add(txtAssignmentScore2);
            Controls.Add(txtAssignmentScore3);
            Controls.Add(txtAssignmentScore4);
            Controls.Add(txtAssignmentScore5);
            Controls.Add(txtAssignmentScore6);
            Controls.Add(txtAssignmentScore7);
            Controls.Add(txtAssignmentScore8);
            Controls.Add(txtAssignmentScore9);
            Controls.Add(txtAssignmentScore10);
            Controls.Add(txtSeatworkScore1);
            Controls.Add(txtSeatworkScore2);
            Controls.Add(txtSeatworkScore3);
            Controls.Add(txtSeatworkScore4);
            Controls.Add(txtSeatworkScore5);
            Controls.Add(txtSeatworkScore6);
            Controls.Add(txtSeatworkScore7);
            Controls.Add(txtSeatworkScore8);
            Controls.Add(txtSeatworkScore9);
            Controls.Add(txtSeatworkScore10);
            Controls.Add(txtLaboratoryScore1);
            Controls.Add(txtLaboratoryScore2);
            Controls.Add(txtLaboratoryScore3);
            Controls.Add(txtLaboratoryScore4);
            Controls.Add(txtLaboratoryScore5);
            Controls.Add(txtLaboratoryScore6);
            Controls.Add(txtLaboratoryScore7);
            Controls.Add(txtLaboratoryScore8);
            Controls.Add(txtLaboratoryScore9);
            Controls.Add(txtLaboratoryScore10);
            Controls.Add(txtRecitationScore1);
            Controls.Add(txtRecitationScore2);
            Controls.Add(txtRecitationScore3);
            Controls.Add(txtRecitationScore4);
            Controls.Add(txtLaboratoryWeight);
            Controls.Add(txtSeatworkWeight);
            Controls.Add(txtAssignmentWeight);
            Controls.Add(txtQuizWeight);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "classStandingprelim";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "classStandingprelim";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox txtRecitationWeight;
        private TextBox txtRecitationScore10;
        private TextBox txtRecitationScore9;
        private TextBox txtRecitationScore8;
        private TextBox txtRecitationScore7;
        private TextBox txtRecitationScore6;
        private TextBox txtRecitationScore5;
        private TextBox txtQuizScore1;
        private TextBox txtQuizScore2;
        private TextBox txtQuizScore3;
        private TextBox txtQuizScore4;
        private TextBox txtQuizScore5;
        private TextBox txtQuizScore6;
        private TextBox txtQuizScore7;
        private TextBox txtQuizScore8;
        private TextBox txtQuizScore9;
        private TextBox txtQuizScore10;
        private TextBox txtAssignmentScore1;
        private TextBox txtAssignmentScore2;
        private TextBox txtAssignmentScore3;
        private TextBox txtAssignmentScore4;
        private TextBox txtAssignmentScore5;
        private TextBox txtAssignmentScore6;
        private TextBox txtAssignmentScore7;
        private TextBox txtAssignmentScore8;
        private TextBox txtAssignmentScore9;
        private TextBox txtAssignmentScore10;
        private TextBox txtSeatworkScore1;
        private TextBox txtSeatworkScore2;
        private TextBox txtSeatworkScore3;
        private TextBox txtSeatworkScore4;
        private TextBox txtSeatworkScore5;
        private TextBox txtSeatworkScore6;
        private TextBox txtSeatworkScore7;
        private TextBox txtSeatworkScore8;
        private TextBox txtSeatworkScore9;
        private TextBox txtSeatworkScore10;
        private TextBox txtLaboratoryScore1;
        private TextBox txtLaboratoryScore2;
        private TextBox txtLaboratoryScore3;
        private TextBox txtLaboratoryScore4;
        private TextBox txtLaboratoryScore5;
        private TextBox txtLaboratoryScore6;
        private TextBox txtLaboratoryScore7;
        private TextBox txtLaboratoryScore8;
        private TextBox txtLaboratoryScore9;
        private TextBox txtLaboratoryScore10;
        private TextBox txtRecitationScore1;
        private TextBox txtRecitationScore2;
        private TextBox txtRecitationScore3;
        private TextBox txtRecitationScore4;
        private TextBox txtLaboratoryWeight;
        private TextBox txtSeatworkWeight;
        private TextBox txtAssignmentWeight;
        private TextBox txtQuizWeight;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label12;
        private Label label13;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}