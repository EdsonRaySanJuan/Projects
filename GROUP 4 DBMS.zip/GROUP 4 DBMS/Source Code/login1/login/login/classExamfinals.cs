﻿// classExamfinals.cs - For Finals Exam data entry and final navigation to Dashboard

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // For Debug.WriteLine

// Assuming CourseDetails class is defined in the 'login' namespace and is accessible.
// You might need to define CourseDetails if you haven't already provided it.
/*
namespace login
{
    public class CourseDetails
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Semester { get; set; }
        public string SchoolYear { get; set; }
        // Add properties for grades as needed, e.g.:
        // public double PrelimCS { get; set; }
        // public double PrelimExam { get; set; }
        // public double MidtermCS { get; set; }
        // public double MidtermExam { get; set; }
        // public double FinalsCS { get; set; }
        // public double FinalsExam { get; set; }
        // public double FinalGrade { get; set; }
        // public int AcademicPeriodId { get; set; } // Example for data saving
    }
}
*/

namespace login
{
    public partial class classExamfinals : Form
    {
        private CourseDetails _selectedCourse;
        private string _currentGradingTerm; // This will be "Finals"
        private Form _selectCourseFormRef;  // May not be strictly needed for final navigation to dashboard, but good for consistency
        private Form _dashboardFormRef;

        // Parameterless constructor (for the designer)
        public classExamfinals()
        {
            InitializeComponent();
            Debug.WriteLine("classExamfinals: Parameterless constructor called.");
            UpdateFinalsExamDisplay(null, "Finals");
        }

        // Parameterized constructor - This will be called by classStandingfinals
        public classExamfinals(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboardForm)
        {
            InitializeComponent();
            _selectedCourse = course;
            _currentGradingTerm = gradingTerm; // Should receive "Finals"
            _selectCourseFormRef = selectCourseForm;
            _dashboardFormRef = dashboardForm;

            Debug.WriteLine($"classExamfinals: Constructor called. Course: {course?.Code}, Term: {gradingTerm}");
            UpdateFinalsExamDisplay(course, gradingTerm);
        }

        private void UpdateFinalsExamDisplay(CourseDetails course, string term)
        {
            string formTitle;
            string courseSubjectText = "Course Subject: N/A";
            string termDisplayText = $"Term: {term ?? "N/A"}"; // Use term passed to method or default

            if (course != null)
            {
                formTitle = $"{term} Exam - {course.Name}";
                courseSubjectText = $"Course Subject: {course.Name} ({course.Code})";
            }
            else
            {
                formTitle = $"{term ?? "Exam"} Exam";
            }

            this.Text = formTitle;

            // Assuming label4 is intended for the course subject
            Control courseSubjectLabel = this.Controls.Find("label4", true).FirstOrDefault(); // Adjust "label4" if needed
            if (courseSubjectLabel is Label subjectLbl)
            {
                subjectLbl.Text = courseSubjectText;
            }
            else { Debug.WriteLine("classExamfinals Warning: Control 'label4' for course display not found."); }


            // Assuming label1 is for the Term display (consistent with other forms)
            Control termLabel = this.Controls.Find("label1", true).FirstOrDefault(); // Adjust "label1" if needed
            if (termLabel is Label lbl1)
            {
                lbl1.Text = termDisplayText;
            }
            else { Debug.WriteLine("classExamfinals Warning: Control 'label1' for Term not found."); }


            // Update other labels to reflect "Finals" if they exist and are generic
            // Control csGradeDescLabel = this.Controls.Find("lblCSGradeDescription", true).FirstOrDefault();
            // if(csGradeDescLabel is Label csDesc) csDesc.Text = $"Finals CS Grade"; // Or whatever the text should be

            // Control desiredGradeDescLabel = this.Controls.Find("lblDesiredGradeDescription", true).FirstOrDefault();
            // if(desiredGradeDescLabel is Label dgDesc) dgDesc.Text = $"Enter your desired {term} grade:";
        }

        private void classExamfinals_Load(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExamfinals: Form loaded for {_currentGradingTerm}.");
            // Update display on load just in case parameters weren't fully ready in constructor
            UpdateFinalsExamDisplay(_selectedCourse, _currentGradingTerm);

            if (_selectedCourse == null && !(this.DesignMode))
            {
                MessageBox.Show(this, "Course information is missing for Finals Exam. Please go back.", "Data Missing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Debug.WriteLine("classExamfinals Warning: Form loaded without selected course data.");
                // Assuming button1 is submit
                // Control submitButton = this.Controls.Find("button1", true).FirstOrDefault();
                // if (submitButton != null) submitButton.Enabled = false;
            }
            // You might want to pre-fill txtQuiz (Finals CS Grade) if that data is available
            // from _selectedCourse or another source, or if it's passed additionally.
        }

        // finals cs grade textbox (Assuming your TextBox is named txtQuiz on this form too)
        private void txtQuiz_TextChanged(object sender, EventArgs e)
        {
            // Logic for when "Finals CS Grade" (if that's what this TextBox is for) changes
            Debug.WriteLine("classExamfinals: txtQuiz_TextChanged fired.");
            // Add any real-time processing or validation logic here if needed
        }

        // enter your desired finals grade textbox (Assuming your TextBox is named textBox1 on this form)
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Logic for when "desired finals grade" text changes
            Debug.WriteLine("classExamfinals: textBox1_TextChanged fired.");
            // Add any real-time processing or validation logic here if needed
        }

        // submit btn (assuming button1 is the name in your designer)
        private void button1_Click(object sender, EventArgs e)
        {
            // ... (Validation and saving logic) ...

            MessageBox.Show(this, $"{_currentGradingTerm} Exam data has been processed (simulated). Sequence complete. Returning to Dashboard.", "Submission Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // 2. This is the end of the sequence for this course, navigate to the Dashboard.
            // >>> START of the block you provided (approx line 201)
            try
            {
                this.Hide(); // Hide the current Finals Exam form

                // Navigate to the Dashboard (which is expected to be a long-lived, non-modal form)
                if (_dashboardFormRef != null && !_dashboardFormRef.IsDisposed)
                {
                    _dashboardFormRef.Show(); // Show the Dashboard
                    Debug.WriteLine("classExamfinals: Navigating to Dashboard.");
                }
                else
                {
                    Debug.WriteLine("classExamfinals: Dashboard form reference is missing or disposed. Cannot navigate. Exiting application as a fallback.");
                    MessageBox.Show(this, "The Dashboard cannot be loaded. Exiting application.", "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit(); // Emergency exit if dashboard is lost
                }

                // This form has completed the sequence for this course and should close.
                this.DialogResult = DialogResult.OK; // Signal successful completion to the calling form (classStandingfinals)
                this.Close(); // Close this Finals Exam form

            }
            catch (Exception ex)
            // >>> END of the block you provided (approx line 231)
            {
                MessageBox.Show(this, "Error during navigation after Finals Exam submission: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"classExamfinals: Error post-submit navigation - {ex.Message}\n{ex.StackTrace}");

                // Ensure form closes even if dashboard navigation fails.
                this.DialogResult = DialogResult.Abort; // Indicate an issue
                if (!this.IsDisposed) this.Close();
            }
        }

        // clear btn (assuming button2 is your clear button)
        private void button2_Click(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExamfinals: Clear button clicked for {_currentGradingTerm} Exam.");
            // Add logic to clear input fields on this form
            // Example:
            /*
            Control txtFinalsCSControl = this.Controls.Find("txtQuiz", true).FirstOrDefault(); // Or your actual TextBox name
            if (txtFinalsCSControl is TextBox txtQ) { txtQ.Clear(); }

            Control txtDesiredExamControl = this.Controls.Find("textBox1", true).FirstOrDefault(); // Or your actual TextBox name
            if (txtDesiredExamControl is TextBox txt1) { txt1.Clear(); }
            */
        }

        // label for course (label4 based on other forms)
        private void label4_Click(object sender, EventArgs e)
        {
            // Any logic for clicking the course label? Unlikely needed.
        }

        // --- Helper method for getting double from control (Suggested) ---
        // You can uncomment and use this or integrate its logic directly.
        /*
        private double GetDoubleFromControl(Control control, string fieldName)
        {
            if (control == null)
            {
                Debug.WriteLine($"Warning: Control for {fieldName} is null or not found.");
                MessageBox.Show(this, $"Internal Error: Input control for {fieldName} not found.", "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return double.NaN; // Indicates an error/failure to get a valid number
            }
            if (control is TextBox textBox)
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                     // Decide if empty input is 0 or invalid NaN. For exam scores, 0 is often valid.
                     // If input is mandatory, return NaN and trigger error.
                     return 0; // Assuming blank means 0
                }
                if (double.TryParse(textBox.Text.Trim(), out double value))
                {
                    // Basic check, detailed range validation should happen after getting all values
                    return value;
                }
                else
                {
                    MessageBox.Show(this, $"Invalid input for {fieldName}: '{textBox.Text}'. Please enter a valid number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox.Focus();
                    return double.NaN; // Indicates parsing failed
                }
            }
            else
            {
                Debug.WriteLine($"Warning: Control for {fieldName} is not a TextBox.");
                 MessageBox.Show(this, $"Internal Error: Expected input control for {fieldName} to be a text box.", "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return double.NaN; // Indicates incorrect control type
            }
        }
        */
    }
}