﻿// CalculateRequiredMidtermExamForm.cs
using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // For SQL Server interaction
using System.Diagnostics;       // For Debug.WriteLine
using System.Text;              // For StringBuilder

namespace login // Assuming the namespace is 'login' based on other files
{
    public partial class CalculateRequiredMidtermExamForm : Form
    {
        private CourseDetails _selectedCourse;
        private Form _previousForm;
        private Form _dashboardForm;

        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        private decimal _fetchedPrelimGrade = -1m;
        private decimal _fetchedMidtermClassStanding = -1m;

        // UI Control Name Constants
        private const string DesiredGradeInputTextBoxName = "txtDesiredOverallMidtermGrade";
        private const string PrelimGradeDisplayLabelName = "lblDisplayPrelimGrade";
        private const string MidtermCSDisplayLabelName = "lblDisplayMidtermCS";
        private const string CalculateButtonName = "btnCalculateRequiredExam";
        // private const string ResultLabelName = "lblRequiredExamScore"; // No longer primarily used for result display
        private const string CourseNameLabelName = "lblCourseName";
        private const string CourseCodeLabelName = "lblCourseCode";
        private const string AcademicPeriodLabelName = "lblAcademicPeriod";
        private const string BackButtonName = "btnBack";

        public CalculateRequiredMidtermExamForm(CourseDetails course, Form previousForm, Form dashboardForm)
        {
            InitializeComponent();
            _selectedCourse = course;
            _previousForm = previousForm;
            _dashboardForm = dashboardForm;
            this.Load += CalculateRequiredMidtermExamForm_Load;
        }

        public CalculateRequiredMidtermExamForm()
        {
            InitializeComponent();
            Debug.WriteLine("CalculateRequiredMidtermExamForm: Parameterless constructor called. Functionality might be limited.");
            var btnCalc = FindControlRecursive(this, CalculateButtonName);
            if (btnCalc != null) btnCalc.Enabled = false;
            var txtDesired = FindControlRecursive(this, DesiredGradeInputTextBoxName);
            if (txtDesired != null) txtDesired.Enabled = false;
        }

        private void CalculateRequiredMidtermExamForm_Load(object sender, EventArgs e)
        {
            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0)
            {
                MessageBox.Show(this, "Course details are missing or invalid. Cannot proceed.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DisableFormControls();
                return;
            }
            UpdateFormDisplay();
            LoadPrerequisiteGrades();

            // Clear any previous result from a label if it exists (optional, as we now use MessageBox)
            var lblResult = FindControlRecursive(this, "lblRequiredExamScore"); // Using literal string if ResultLabelName constant is removed
            if (lblResult is Label resultLabel)
            {
                resultLabel.Text = "Required Midterm Exam Score: -";
            }
        }

        private void UpdateFormDisplay()
        {
            var lblCourseNameCtrl = FindControlRecursive(this, CourseNameLabelName) as Label;
            if (lblCourseNameCtrl != null) lblCourseNameCtrl.Text = $"Course: {_selectedCourse.Name}";

            var lblCourseCodeCtrl = FindControlRecursive(this, CourseCodeLabelName) as Label;
            if (lblCourseCodeCtrl != null) lblCourseCodeCtrl.Text = $"Code: {_selectedCourse.Code}";

            var lblAcadPeriodCtrl = FindControlRecursive(this, AcademicPeriodLabelName) as Label;
            if (lblAcadPeriodCtrl != null && _selectedCourse != null)
            {
                string schoolYear = _selectedCourse.SchoolYear ?? "N/A";
                string semester = _selectedCourse.Semester ?? "N/A";
                lblAcadPeriodCtrl.Text = $"Academic Period: {semester} ({schoolYear})";
            }
            this.Text = $"Required Midterm Exam Calculator - {_selectedCourse.Name}";
        }

        private void DisableFormControls()
        {
            var txtDesiredGrade = FindControlRecursive(this, DesiredGradeInputTextBoxName) as TextBox;
            if (txtDesiredGrade != null) txtDesiredGrade.Enabled = false;

            var btnCalculate = FindControlRecursive(this, CalculateButtonName) as Button;
            if (btnCalculate != null) btnCalculate.Enabled = false;

            var lblPrelimGrade = FindControlRecursive(this, PrelimGradeDisplayLabelName) as Label;
            if (lblPrelimGrade != null) lblPrelimGrade.Text = "Prelim Grade: Error";

            var lblMidtermCS = FindControlRecursive(this, MidtermCSDisplayLabelName) as Label;
            if (lblMidtermCS != null) lblMidtermCS.Text = "Midterm CS: Error";
        }

        private void LoadPrerequisiteGrades()
        {
            bool prelimSuccess = FetchPrelimGrade();
            bool midtermCSSuccess = FetchMidtermClassStanding();

            var btnCalculate = FindControlRecursive(this, CalculateButtonName) as Button;
            var txtDesiredGrade = FindControlRecursive(this, DesiredGradeInputTextBoxName) as TextBox;

            if (prelimSuccess && midtermCSSuccess)
            {
                if (btnCalculate != null) btnCalculate.Enabled = true;
                if (txtDesiredGrade != null)
                {
                    txtDesiredGrade.Enabled = true;
                    txtDesiredGrade.Focus();
                }
            }
            else
            {
                MessageBox.Show(this, "Could not load all necessary prerequisite grades (Prelim Grade and/or Midterm Class Standing). Please ensure these are entered in the system. Calculation is disabled.", "Data Missing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (btnCalculate != null) btnCalculate.Enabled = false;
                if (txtDesiredGrade != null) txtDesiredGrade.Enabled = false;
            }
        }

        private bool FetchPrelimGrade()
        {
            var lblDisplay = FindControlRecursive(this, PrelimGradeDisplayLabelName) as Label;
            if (lblDisplay == null) { Debug.WriteLine($"Error: Label control '{PrelimGradeDisplayLabelName}' not found."); return false; }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT ExamScore, TotalClassStandingRaw FROM dbo.TermGrades WHERE CourseID = @AcademicPeriodId AND TermName = 'Prelim'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                decimal prelimExamScore = reader["ExamScore"] != DBNull.Value ? Convert.ToDecimal(reader["ExamScore"]) : -1m;
                                decimal prelimCSraw = reader["TotalClassStandingRaw"] != DBNull.Value ? Convert.ToDecimal(reader["TotalClassStandingRaw"]) : -1m;

                                if (prelimExamScore >= 0 && prelimCSraw >= 0)
                                {
                                    _fetchedPrelimGrade = (prelimExamScore + prelimCSraw) / 2;
                                    lblDisplay.Text = $"Prelim Grade (Avg): {_fetchedPrelimGrade:F2}";
                                    Debug.WriteLine($"Fetched Prelim Grade: {_fetchedPrelimGrade}");
                                    return true;
                                }
                                else { /* ... error handling as before ... */ }
                            }
                            else { /* ... error handling as before ... */ }
                        }
                    }
                    catch (Exception ex) { /* ... error handling as before ... */ Debug.WriteLine($"Error fetching Prelim Grade: {ex.Message}"); _fetchedPrelimGrade = -1m; return false; } // Simplified for brevity
                }
            }
            // Fallback for brevity, ensure original error handling paths set lblDisplay.Text and return false
            lblDisplay.Text = "Prelim Grade: Error/Missing";
            _fetchedPrelimGrade = -1m;
            return false;
        }

        private bool FetchMidtermClassStanding()
        {
            var lblDisplay = FindControlRecursive(this, MidtermCSDisplayLabelName) as Label;
            if (lblDisplay == null) { Debug.WriteLine($"Error: Label control '{MidtermCSDisplayLabelName}' not found."); return false; }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT TotalClassStandingRaw FROM dbo.TermGrades WHERE CourseID = @AcademicPeriodId AND TermName = 'Midterm'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                    try
                    {
                        con.Open();
                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            _fetchedMidtermClassStanding = Convert.ToDecimal(result);
                            lblDisplay.Text = $"Midterm Class Standing: {_fetchedMidtermClassStanding:F2}";
                            return true;
                        }
                        else { /* ... error handling as before ... */ }
                    }
                    catch (Exception ex) { /* ... error handling as before ... */ Debug.WriteLine($"Error fetching Midterm CS: {ex.Message}"); _fetchedMidtermClassStanding = -1m; return false; } // Simplified for brevity
                }
            }
            // Fallback for brevity
            lblDisplay.Text = "Midterm CS: Error/Missing";
            _fetchedMidtermClassStanding = -1m;
            return false;
        }


        private void btnCalculateRequiredExam_Click(object sender, EventArgs e)
        {
            var txtDesiredGrade = FindControlRecursive(this, DesiredGradeInputTextBoxName) as TextBox;
            // var lblResult = FindControlRecursive(this, ResultLabelName) as Label; // No longer needed to update label

            if (txtDesiredGrade == null) // Simplified check as lblResult is no longer primary
            {
                MessageBox.Show(this, "UI element for desired grade input is missing. Please contact support.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(txtDesiredGrade.Text, out decimal desiredOverallMidtermGrade) || desiredOverallMidtermGrade < 0 || desiredOverallMidtermGrade > 100)
            {
                MessageBox.Show(this, "Please enter a valid Desired Overall Midterm Grade (0-100).", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDesiredGrade.Focus();
                txtDesiredGrade.SelectAll();
                return;
            }

            if (_fetchedPrelimGrade < 0 || _fetchedMidtermClassStanding < 0)
            {
                MessageBox.Show(this, "Cannot calculate: Prelim Grade or Midterm Class Standing data is missing or invalid. Please ensure they are entered and try reloading this calculator.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal requiredExamScore = (3 * desiredOverallMidtermGrade) - _fetchedPrelimGrade - _fetchedMidtermClassStanding;

            // *** IMPLEMENTED CHANGE: Display result in MessageBox ***
            StringBuilder resultMessage = new StringBuilder();
            resultMessage.AppendLine("--- Midterm Grade Target Calculation ---");
            if (_selectedCourse != null)
            {
                resultMessage.AppendLine($"Course: {_selectedCourse.Code} - {_selectedCourse.Name}");
            }
            resultMessage.AppendLine($"Fetched Prelim Grade (Avg): {_fetchedPrelimGrade:F2}%");
            resultMessage.AppendLine($"Fetched Midterm Class Standing (Raw %): {_fetchedMidtermClassStanding:F2}%");
            resultMessage.AppendLine($"Desired Overall Midterm Grade: {desiredOverallMidtermGrade:F2}%");
            resultMessage.AppendLine("-------------------------------------------");
            resultMessage.AppendLine($"To achieve your Desired Overall Midterm Grade of {desiredOverallMidtermGrade:F2}%,");
            resultMessage.AppendLine($"you need a Midterm Exam Score of approximately: {requiredExamScore:F2}%");

            if (requiredExamScore > 100)
            {
                resultMessage.AppendLine("\n(Note: Required score is > 100. This might be unachievable.)");
                decimal maxPossibleGrade = (_fetchedPrelimGrade / 3) + (_fetchedMidtermClassStanding / 3) + (100m / 3);
                resultMessage.AppendLine($"With 100% on the Midterm Exam, your maximum possible Overall Midterm Grade would be approximately: {maxPossibleGrade:F2}%.");
            }
            else if (requiredExamScore < 0)
            {
                resultMessage.AppendLine($"\n(Note: Required score is < 0. You've likely already achieved or surpassed this desired grade with current Prelim and Midterm CS.)");
                decimal currentGradeContribution = (_fetchedPrelimGrade / 3) + (_fetchedMidtermClassStanding / 3); // This is not the grade with 0 exam.
                decimal gradeWithZeroExam = (_fetchedPrelimGrade / 3) + (_fetchedMidtermClassStanding / 3) + (0m / 3);
                resultMessage.AppendLine($"Even with 0% on the Midterm Exam, your Overall Midterm Grade would be approximately: {gradeWithZeroExam:F2}%.");
            }

            MessageBox.Show(this, resultMessage.ToString(), "Midterm Grade Requirement Calculation", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Optionally, clear the result label if it exists from a previous design
            var lblResultOnForm = FindControlRecursive(this, "lblRequiredExamScore");
            if (lblResultOnForm is Label resultLabel)
            {
                resultLabel.Text = "Required Midterm Exam Score: (See MessageBox)";
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (_previousForm != null && !_previousForm.IsDisposed)
            {
                _previousForm.Show();
            }
            else if (_dashboardForm != null && !_dashboardForm.IsDisposed)
            {
                _dashboardForm.Show();
            }
            this.Close();
        }

        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (string.Equals(root.Name, name, StringComparison.OrdinalIgnoreCase)) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }
        // widnow display
        private void CalculateRequiredMidtermExamForm_Load_1(object sender, EventArgs e)
        {

        }
    }

    // Ensure CourseDetails class is defined
    /*
    public class CourseDetails
    {
        public int AcademicPeriodId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string SchoolYear { get; set; }
        public string Semester { get; set; }
    }
    */



}