﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // Required for SQL Server interaction

namespace login
{
    public partial class student_op : Form
    {
        // Define the connection string for your SQL Server database
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // Field to hold the reference to the previous form (the form that opened this one)
        private Form previousForm;

        // Field to hold the studentID for the current operation
        private int currentStudentID; // Field to store the student ID

        // Enum to define the form's operational mode
        public enum Mode { Add, Edit }
        private Mode formMode; // Field to store the current mode

        public student_op(int studentId, Form callingForm, Mode mode)
        {
            InitializeComponent();
            this.currentStudentID = studentId;
            this.previousForm = callingForm;
            this.formMode = mode;

            this.Load += Student_op_Load;
            this.FormClosing += Student_op_FormClosing;
        }

        public student_op()
        {
            InitializeComponent();
            this.Load += Student_op_Load;
            this.FormClosing += Student_op_FormClosing;
        }

        private void Student_op_Load(object sender, EventArgs e)
        {
            txtName.Focus();

            if (formMode == Mode.Add)
            {
                this.Text = "Add Student Details";
                button1.Text = "Submit";
            }
            else // formMode == Mode.Edit
            {
                this.Text = $"Edit Student Details (ID: {currentStudentID})";
                button1.Text = "Update";
                // We load details from student_details, which is linked to studentID
                LoadStudentDetails(currentStudentID);
            }
        }

        private void LoadStudentDetails(int studentIdToLoad)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // This query should join student and student_details if name is in student_details
                // Or simply select from student_details if that's where 'student_name' etc. are.
                // Based on your screenshot image_1d7910.png, student_name is in student_details.
                string query = "SELECT student_name, email, program, year_level FROM dbo.student_details WHERE studentID = @StudentID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentIdToLoad);
                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtName.Text = reader["student_name"]?.ToString() ?? "";
                                txtEmail.Text = reader["email"]?.ToString() ?? "";
                                txtProgram.Text = reader["program"]?.ToString() ?? "";
                                txtYearLevel.Text = reader["year_level"]?.ToString() ?? "";
                            }
                            else
                            {
                                // This form shows student_details. If no details for a studentID, it's an issue.
                                MessageBox.Show($"Student details for ID {studentIdToLoad} not found. The student might exist but have no details recorded, or the ID is incorrect.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading student details: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) // Submit / Update Button
        {
            string studentName = txtName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string program = txtProgram.Text.Trim();
            string yearLevel = txtYearLevel.Text.Trim();

            if (string.IsNullOrWhiteSpace(studentName) || string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(program) || string.IsNullOrWhiteSpace(yearLevel))
            {
                MessageBox.Show("Please fill in all required fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (string.IsNullOrWhiteSpace(studentName)) txtName.Focus();
                else if (string.IsNullOrWhiteSpace(email)) txtEmail.Focus();
                else if (string.IsNullOrWhiteSpace(program)) txtProgram.Focus();
                else txtYearLevel.Focus();
                return;
            }

            string sqlQueryToExecute;
            string successMessage;
            string errorMessage;

            // Operations on student_details table
            if (formMode == Mode.Add)
            {
                // Adding new student_details assumes currentStudentID from dbo.student exists and doesn't have details yet
                sqlQueryToExecute = "INSERT INTO dbo.student_details (studentID, student_name, email, program, year_level) " +
                                    "VALUES (@studentID, @studentName, @email, @program, @yearLevel)";
                successMessage = "Student details added successfully!";
                errorMessage = "Failed to add student details.";
            }
            else // Mode.Edit
            {
                sqlQueryToExecute = "UPDATE dbo.student_details SET student_name = @studentName, email = @email, " +
                                    "program = @program, year_level = @yearLevel " +
                                    "WHERE studentID = @studentID";
                successMessage = "Student details updated successfully!";
                errorMessage = "Failed to update student details.";
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQueryToExecute, con))
                {
                    cmd.Parameters.AddWithValue("@studentID", currentStudentID); // This is the studentID from the main student table
                    cmd.Parameters.AddWithValue("@studentName", studentName);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@program", program);
                    cmd.Parameters.AddWithValue("@yearLevel", yearLevel);

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(successMessage, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            NavigateToPreviousForm(true);
                        }
                        else
                        {
                            if (formMode == Mode.Edit)
                                MessageBox.Show($"Student details for ID {currentStudentID} not found for update. No record was updated.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            else // Add mode
                                MessageBox.Show(errorMessage + " No rows affected. This could be due to the studentID not existing in the parent 'student' table or details for this studentID already exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (SqlException ex)
                    {
                        HandleSqlException(ex);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            txtName.Clear();
            txtEmail.Clear();
            txtProgram.Clear();
            txtYearLevel.Clear();
            txtName.Focus();
        }

        private void button3_Click(object sender, EventArgs e) // Back Button
        {
            NavigateToPreviousForm(false);
        }

        private void Student_op_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (formMode == Mode.Edit && currentStudentID > 0)
                {
                    DialogResult result = MessageBox.Show(
                        $"Are you sure you want to delete ALL records for student ID {currentStudentID}? This includes student login, details, academic periods, and related courses. This action cannot be undone.",
                        "Confirm Full Deletion",
                        MessageBoxButtons.YesNoCancel,
                        MessageBoxIcon.Warning,
                        MessageBoxDefaultButton.Button3);

                    if (result == DialogResult.Yes)
                    {
                        if (DeleteStudentRelatedData(currentStudentID))
                        {
                            MessageBox.Show($"All data for student ID {currentStudentID} has been deleted.", "Deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            e.Cancel = true;
                            NavigateToPreviousForm(true);
                        }
                        else
                        {
                            // Specific error messages already shown by DeleteStudentRelatedData or HandleSqlException
                            e.Cancel = true;
                        }
                    }
                    else if (result == DialogResult.No)
                    {
                        MessageBox.Show("Data not deleted.", "Operation Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        e.Cancel = true;
                        NavigateToPreviousForm(false);
                    }
                    else // result == DialogResult.Cancel
                    {
                        e.Cancel = true;
                    }
                }
                else
                {
                    if (this.Visible)
                    {
                        e.Cancel = true;
                        NavigateToPreviousForm(false);
                    }
                }
            }
        }

        private bool DeleteStudentRelatedData(int studentIdToDelete)
        {
            string academicPeriodsPkColumn = "AcademicPeriodID"; // Primary Key of AcademicPeriods
            string coursesFkToAcademicPeriods = "AcademicPeriodID"; // FK in Courses that points to AcademicPeriods.AcademicPeriodID
            string academicPeriodsFkToStudent = "studentID"; // FK in AcademicPeriods that points to student.studentID
            string studentDetailsFkToStudent = "studentID"; // FK in student_details that points to student.studentID
            string studentPkColumn = "studentID"; // Primary Key of the main student table

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        // Step 1: Delete from dbo.Courses (child of AcademicPeriods)
                        // This query deletes Courses records where the 'coursesFkToAcademicPeriods'
                        // (e.g., AcademicPeriodID in Courses) matches any 'academicPeriodsPkColumn'
                        // (e.g., AcademicPeriodID in AcademicPeriods) that belongs to the studentIdToDelete.
                        string queryDeleteCourses =
                            $"DELETE FROM dbo.Courses WHERE {coursesFkToAcademicPeriods} IN " +
                            $"(SELECT {academicPeriodsPkColumn} FROM dbo.AcademicPeriods WHERE {academicPeriodsFkToStudent} = @StudentID)";
                        using (SqlCommand cmdCourses = new SqlCommand(queryDeleteCourses, con, transaction))
                        {
                            cmdCourses.Parameters.AddWithValue("@StudentID", studentIdToDelete);
                            cmdCourses.ExecuteNonQuery();
                            // It's okay if no courses were linked to these academic periods.
                        }

                        // Step 2: Delete from dbo.AcademicPeriods (child of student)
                        string queryDeleteAcademicPeriods = $"DELETE FROM dbo.AcademicPeriods WHERE {academicPeriodsFkToStudent} = @StudentID";
                        using (SqlCommand cmdAcademicPeriods = new SqlCommand(queryDeleteAcademicPeriods, con, transaction))
                        {
                            cmdAcademicPeriods.Parameters.AddWithValue("@StudentID", studentIdToDelete);
                            cmdAcademicPeriods.ExecuteNonQuery();
                        }

                        // Step 3: Delete from dbo.student_details (child of student)
                        string queryDeleteStudentDetails = $"DELETE FROM dbo.student_details WHERE {studentDetailsFkToStudent} = @StudentID";
                        using (SqlCommand cmdStudentDetails = new SqlCommand(queryDeleteStudentDetails, con, transaction))
                        {
                            cmdStudentDetails.Parameters.AddWithValue("@StudentID", studentIdToDelete);
                            cmdStudentDetails.ExecuteNonQuery();
                        }

                        // --- Temporarily comment out TermGrades deletion ---
                        // We need to resolve how TermGrades links to studentID first
                        // If TermGrades.studentID is now populated and has an FK to dbo.student:
                        // string queryDeleteTermGrades = "DELETE FROM dbo.TermGrades WHERE studentID = @StudentID";
                        // using (SqlCommand cmdTermGrades = new SqlCommand(queryDeleteTermGrades, con, transaction))
                        // {
                        //    cmdTermGrades.Parameters.AddWithValue("@StudentID", studentIdToDelete);
                        //    cmdTermGrades.ExecuteNonQuery();
                        // }
                        // --- End of TermGrades temporary comment ---

                        // Step 4: Delete from dbo.student (the main parent table)
                        string queryDeleteStudent = $"DELETE FROM dbo.student WHERE {studentPkColumn} = @StudentID";
                        using (SqlCommand cmdStudent = new SqlCommand(queryDeleteStudent, con, transaction))
                        {
                            cmdStudent.Parameters.AddWithValue("@StudentID", studentIdToDelete);
                            int rowsAffected = cmdStudent.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                transaction.Commit();
                                return true; // Successfully deleted the main student record
                            }
                            else
                            {
                                // This means the studentID was not found in the main student table, which is unexpected if we got this far.
                                transaction.Rollback();
                                MessageBox.Show($"Student ID {studentIdToDelete} not found in the main 'student' table. Deletion process aborted and rolled back.", "Critical Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return false;
                            }
                        }
                    }
                    catch (SqlException ex)
                    {
                        try { transaction.Rollback(); } catch { /* ignored */ }
                        // The HandleSqlException method will provide a more user-friendly message
                        HandleSqlException(ex); // Call your existing handler
                        return false;
                    }
                    catch (Exception ex)
                    {
                        try { transaction.Rollback(); } catch { /* ignored */ }
                        MessageBox.Show("An unexpected error occurred during deletion: " + ex.Message, "Deletion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }

        private void NavigateToPreviousForm(bool dataChanged)
        {
            this.Hide();
            if (previousForm != null)
            {
                previousForm.Show();
            }
        }

        private void HandleSqlException(SqlException ex)
        {
            string errorMessage = "A database error occurred: " + ex.Message + "\nError Number: " + ex.Number;

            if (ex.Number == 2627 && formMode == Mode.Add) // PK violation
            {
                errorMessage = $"Error: Details for Student ID {currentStudentID} already exist in student_details. Cannot add new details. Please use the 'Edit' option or check the ID.";
            }
            else if (ex.Number == 547) // FK violation
            {
                if (formMode == Mode.Add)
                {
                    errorMessage = $"Database Error (FK Violation): Student ID {currentStudentID} might not exist in the main student table (dbo.student), or another reference is missing. Details cannot be saved. Error: {ex.Message}";
                }
                else // Could also be an FK issue during DELETE
                {
                    // The error message from SQL Server (ex.Message) is usually quite descriptive for FK violations during DELETE.
                    errorMessage = $"Database Error (FK Violation - Error {ex.Number}): Could not complete operation.\n{ex.Message}\n\nThis often means there's related data in another table that needs to be deleted first or the delete rule (ON DELETE) prevents it.";
                }
            }
            else if (ex.Number == 207) // Invalid column name
            {
                errorMessage = $"Database Error (Invalid Column Name - Error {ex.Number}): One of the column names used in the SQL query is incorrect or does not exist in the table.\nPlease verify your C# code against the database schema.\nDetails: {ex.Message}";
            }

            MessageBox.Show(errorMessage, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Empty TextChanged event handlers & label click
        private void txtName_TextChanged(object sender, EventArgs e) { }
        private void txtEmail_TextChanged(object sender, EventArgs e) { }
        private void txtProgram_TextChanged(object sender, EventArgs e) { }
        private void txtYearLevel_TextChanged(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
    }
}