﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // Required for database interaction

namespace login
{
    // --- This form is now responsible for collecting Goal input and SAVING it ---
    public partial class goals_op : Form
    {
        // Define the connection string for your SQL Server database
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // Field to hold the studentID for the current goal operation
        private int currentStudentID; // Field to store the student ID

        // Field to hold the reference to the previous form (the form that opened this one)
        private Form previousForm;

        // --- IMPORTANT ---
        // Modified constructor that accepts the student ID AND the calling form
        // You must pass the student ID and the calling form to this form when opening it.
        public goals_op(int studentId, Form callingForm) // Added Form callingForm parameter
        {
            InitializeComponent();
            this.currentStudentID = studentId; // Store the passed-in student ID
            this.previousForm = callingForm;   // Store the reference to the calling form

            // Optional: Display the student ID somewhere on the form for context
            // Label lblStudentIdDisplay = this.Controls.Find("lblStudentIdDisplay", true).FirstOrDefault() as Label;
            // if (lblStudentIdDisplay != null)
            // {
            //     lblStudentIdDisplay.Text = $"Adding Goal for Student ID: {currentStudentID}";
            // }
        }

        // Keep the parameterless constructor if it's needed elsewhere (e.g., by the designer)
        // If this form is only ever opened with a student ID and calling form, you could potentially remove this or make it private.
        public goals_op()
        {
            InitializeComponent();
            // If this constructor is used, currentStudentID will be 0 and previousForm will be null.
            // You must ensure a valid student ID is set and handle the case where there's no previous form for navigation.
        }

        // --- Event Handlers ---

        // Handler for Title textbox text changed (textBox4)
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // Add validation or other logic that should happen as the user types the title
        }

        // Handler for Date textbox text changed (textBox2)
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Add validation or other logic that should happen as the user types the date
        }

        // Handler for Description textbox text changed (textBox1)
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Add validation or other logic that should happen as the user types the description
        }

        // Handler for Submit button click (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            // --- Input Validation ---
            string title = textBox4.Text.Trim();
            string dateText = textBox2.Text.Trim();
            string description = textBox1.Text.Trim();
            DateTime dueDate;

            // Check if currentStudentID is valid before proceeding
            if (currentStudentID <= 0) // Assuming student IDs are positive integers
            {
                MessageBox.Show("Student ID is not set. Cannot save goal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // Validate Title
            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Please enter a goal title.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox4.Focus();
                return;
            }

            // Validate Date format and if it's a valid date
            if (string.IsNullOrEmpty(dateText))
            {
                MessageBox.Show("Please enter a due date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return;
            }

            if (!DateTime.TryParse(dateText, out dueDate))
            {
                MessageBox.Show("Please enter a valid date format for the due date (e.g., MM/DD/YYYY).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return;
            }

            // Past date validation (removed in previous step, keeping it that way)
            /*
            if (dueDate < DateTime.Today)
            {
                 MessageBox.Show("Due date cannot be in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 textBox2.Focus();
                 return;
            }
            */


            // --- Database Saving Logic ---

            // IMPORTANT: Ensure your dbo.achievements table has the columns:
            // studentID (INT, NOT NULL, Foreign Key to dbo.student)
            // Title (NVARCHAR, NOT NULL)
            // DueDate (DATE or DATETIME)
            // Description (NVARCHAR(MAX))
            // And likely a Primary Key like AchievementID (INT IDENTITY).

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // INSERT query targeting dbo.achievements and using its columns
                string insertQuery = "INSERT INTO dbo.achievements (studentID, Title, DueDate, Description) " +
                                     "VALUES (@studentID, @Title, @DueDate, @Description)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    // Add parameters to the command
                    cmd.Parameters.AddWithValue("@studentID", currentStudentID); // Use the stored student ID
                    cmd.Parameters.AddWithValue("@Title", title);
                    cmd.Parameters.AddWithValue("@DueDate", dueDate.Date); // Saving only the date part
                    cmd.Parameters.AddWithValue("@Description", description);

                    try
                    {
                        con.Open(); // Open the database connection
                        int rowsAffected = cmd.ExecuteNonQuery(); // Execute the INSERT command

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Goal saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // --- NAVIGATION: Go back to the previous form (Dashboard) ---
                            this.Hide(); // Hide the current form
                            if (previousForm != null)
                            {
                                previousForm.Show(); // Show the previous form (Dashboard)
                                // Optional: In the Dashboard, refresh the list of goals if displayed
                                // if (previousForm is dashboard dash)
                                // {
                                //      dash.LoadAndDisplayStudentGoals(this.currentStudentID); // Assuming dashboard has a method for this
                                // }
                            }
                            else
                            {
                                // Handle the case where there's no previous form for navigation
                                MessageBox.Show("Cannot go back. The previous form reference was not set.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                this.Close(); // Close this form if we can't go back
                            }

                            // Clear fields after successful save and before navigation
                            ClearFormFields(); // Call clear before navigating away

                            // If you want the form to close instead of just hiding and showing the previous:
                            // this.Close(); // Uncomment this line instead of Hide() and Show() block above


                        }
                        else
                        {
                            // 0 rows affected is unexpected for a successful INSERT
                            MessageBox.Show("Failed to save goal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (SqlException ex)
                    {
                        // Handle specific SQL errors
                        if (ex.Number == 547) // Foreign key constraint violation (studentID doesn't exist in dbo.student)
                        {
                            MessageBox.Show($"Database Error: Student ID {currentStudentID} does not exist in the main student table. Goal cannot be saved.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (ex.Number == 207) // Invalid column name (Database schema mismatch)
                        {
                            MessageBox.Show($"Database Error: Invalid column name in achievements table query. Details: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show("A database error occurred: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle any other unexpected errors
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                } // SqlCommand is disposed here
            } // SqlConnection is disposed here
        }

        // Handler for Clear button click (button2)
        private void button2_Click(object sender, EventArgs e)
        {
            ClearFormFields();
        }

        // Helper method to clear the form fields
        private void ClearFormFields()
        {
            textBox4.Clear(); // Clear Title
            textBox2.Clear(); // Clear Date
            textBox1.Clear(); // Clear Description
            textBox4.Focus(); // Set focus back to the first field
        }

        // --- Removed Event Mechanism ---
        // The GoalSubmitted event and GoalSubmittedEventArgs class are removed
        // from this file as the form now handles saving directly.
        // If other parts of your application still need these definitions
        // for other purposes, they should be defined elsewhere (e.g., in a common file).

        // Removed: public event EventHandler<GoalSubmittedEventArgs> GoalSubmitted;
        // Removed: GoalSubmitted?.Invoke(this, new GoalSubmittedEventArgs(newGoal));
        // Removed: public class Goal { ... } // If not used elsewhere
        // Removed: public class GoalSubmittedEventArgs : EventArgs { ... } // If not used elsewhere

        // Note: The Goal class might still be useful for passing data within this method before saving.
        // If the Goal class is only used *within* button1_Click to structure the data before saving,
        // you could potentially define it inside the method or remove the class definition entirely
        // and use individual variables, but keeping it as a class is fine for organization.
    }

    // If the Goal and GoalSubmittedEventArgs classes are used by the Dashboard (GoalsForm_GoalSubmitted handler)
    // and you removed them from the goals_op.cs file, you need to define them in a shared location
    // that both files can access, or define them within the Dashboard.cs file itself.
    // Example of defining them in Dashboard.cs (if not defined elsewhere):
    // public class Goal { ... }
    // public class GoalSubmittedEventArgs : EventArgs { ... }

}