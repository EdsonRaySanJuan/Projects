﻿// classStandingprelim.cs - For Prelim Class Standing calculations
// MODIFIED to save data to dbo.TermGrades on EDSON-LAPTOP
// CORRECTED to use AcademicPeriodId from CourseDetails as the key for TermGrades

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data; // Required for SqlDbType
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // ****** ENSURE THIS IS PRESENT for SQL Server interaction ******
using System.Diagnostics; // Added for Debug.WriteLine

// Your CourseDetails class from CourseDetails.cs
// namespace login
// {
//     public class CourseDetails
//     {
//         public string SchoolYear { get; set; }
//         public string Semester { get; set; }
//         public int CourseNumber { get; set; }
//         public string Code { get; set; }
//         public string Name { get; set; }
//         public int Units { get; set; }
//         public int AcademicPeriodId { get; set; } // This will be used as the CourseID equivalent
//     }
// }

namespace login
{
    public partial class classStandingprelim : Form
    {
        private CourseDetails _selectedCourse;
        private string _gradingTerm;
        private Form _selectCourseForm;
        private Form _dashboardForm;

        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        const int MAX_INPUT_ROWS_PER_CATEGORY = 10;
        private Dictionary<string, double> categoryRawAverages = new Dictionary<string, double>();

        public classStandingprelim(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard)
        {
            InitializeComponent();
            _selectedCourse = course;
            _gradingTerm = gradingTerm;
            _selectCourseForm = selectCourseForm;
            _dashboardForm = dashboard;

            UpdateFormDisplay();
            Debug.WriteLine($"classStandingprelim: Constructor called. Course: {course?.Code}, Term: {gradingTerm}, AcademicPeriodId: {course?.AcademicPeriodId}");
            LoadExistingClassStandingData();
        }

        public classStandingprelim()
        {
            InitializeComponent();
            _selectedCourse = null;
            _gradingTerm = "Prelim";
            _selectCourseForm = null;
            _dashboardForm = null;
            this.Load += (s, e) => HandleParameterlessConstructorContext();
            UpdateFormDisplay();
            Debug.WriteLine("classStandingprelim: Parameterless constructor called.");
        }

        private void HandleParameterlessConstructorContext()
        {
            if (_selectedCourse == null && !(this.DesignMode))
            {
                MessageBox.Show(this, "Warning: Prelim Class Standing form initialized without required course data. Please ensure a course is selected.", "Initialization Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Debug.WriteLine("classStandingprelim Warning: Initialized without expected course data.");
                Control submitButton = FindControlRecursive(this, "button1");
                if (submitButton != null) submitButton.Enabled = false;
            }
        }

        private void UpdateFormDisplay()
        {
            string formTitle;
            string courseDisplayText = "Course N/A";
            string termDisplayText = $"Term: {_gradingTerm}";
            string acadPeriodDisplayText = "Academic Period: N/A";

            if (_selectedCourse != null)
            {
                formTitle = $"{_gradingTerm} Class Standing - {_selectedCourse.Name} ({_selectedCourse.Code})";
                courseDisplayText = $"{_selectedCourse.Name} ({_selectedCourse.Code})";
                acadPeriodDisplayText = $"Academic Period: {_selectedCourse.Semester} ({_selectedCourse.SchoolYear})";
            }
            else
            {
                formTitle = $"{_gradingTerm} Class Standing";
            }

            this.Text = formTitle;
            Control lblTermCtrl = FindControlRecursive(this, "label1");
            if (lblTermCtrl is Label termLabel) { termLabel.Text = termDisplayText; }
            else { Debug.WriteLine("classStandingprelim Warning: Control 'label1' for Term not found."); }

            Control lblCourseCtrl = FindControlRecursive(this, "label4");
            if (lblCourseCtrl is Label courseLabel) { courseLabel.Text = courseDisplayText; }
            else { Debug.WriteLine("classStandingprelim Warning: Control 'label4' for Course Subject not found."); }

            Control lblAcadPeriodCtrl = FindControlRecursive(this, "lblAcademicPeriod");
            if (lblAcadPeriodCtrl is Label acadLabel) { acadLabel.Text = acadPeriodDisplayText; }
            else { Debug.WriteLine("classStandingprelim Warning: Control 'lblAcademicPeriod' for Academic Period not found."); }
        }

        private void LoadExistingClassStandingData()
        {
            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0 || string.IsNullOrEmpty(_gradingTerm))
            {
                Debug.WriteLine($"LoadExistingClassStandingData: Cannot load, essential data missing (Course, AcademicPeriodId: {_selectedCourse?.AcademicPeriodId}, or GradingTerm).");
                return;
            }
            if (_gradingTerm != "Prelim")
            {
                Debug.WriteLine($"LoadExistingClassStandingData: Current term is {_gradingTerm}, not Prelim. Skipping load for this form's specific logic.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Assuming CourseID in TermGrades maps to AcademicPeriodId from CourseDetails
                string query = @"SELECT QuizScore, AssignmentScore, SeatworkScore, LaboratoryScore, RecitationScore
                                 FROM dbo.TermGrades WHERE CourseID = @AcademicPeriodId AND TermName = @TermName";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                    cmd.Parameters.AddWithValue("@TermName", _gradingTerm);

                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                LoadScoreToTextBox(FindControlRecursive(this, "txtQuizScore1") as TextBox, reader["QuizScore"]);
                                LoadScoreToTextBox(FindControlRecursive(this, "txtAssignmentScore1") as TextBox, reader["AssignmentScore"]);
                                LoadScoreToTextBox(FindControlRecursive(this, "txtSeatworkScore1") as TextBox, reader["SeatworkScore"]);
                                LoadScoreToTextBox(FindControlRecursive(this, "txtLaboratoryScore1") as TextBox, reader["LaboratoryScore"]);
                                LoadScoreToTextBox(FindControlRecursive(this, "txtRecitationScore1") as TextBox, reader["RecitationScore"]);
                                Debug.WriteLine($"Existing {_gradingTerm} class standing data loaded for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}.");

                                double tempCS = CalculateOverallClassStanding();
                                if (!double.IsNaN(tempCS))
                                {
                                    Control resultCtrl = FindControlRecursive(this, "txtClassStandingResult");
                                    if (resultCtrl is TextBox txtResult) txtResult.Text = tempCS.ToString("F2") + "%";
                                    else if (resultCtrl is Label lblResult) lblResult.Text = $"Calculated Class Standing: {tempCS:F2}%";
                                }
                            }
                            else
                            {
                                Debug.WriteLine($"No existing {_gradingTerm} data found for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}, Term: {_gradingTerm}.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, $"Error loading existing {_gradingTerm} data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Debug.WriteLine($"Error loading existing {_gradingTerm} data: " + ex.ToString());
                    }
                }
            }
        }

        private void LoadScoreToTextBox(TextBox tb, object dbValue)
        {
            if (tb != null)
            {
                tb.Text = dbValue != DBNull.Value && dbValue != null ? Convert.ToDecimal(dbValue).ToString("F2") : string.Empty;
            }
        }

        private double GetDoubleFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null) { Debug.WriteLine($"Warning: Textbox for {fieldName} is null."); return double.NaN; }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }
            if (double.TryParse(textBox.Text.Trim(), out double value))
            {
                if (value < 0 || value > 100)
                {
                    MessageBox.Show(this, $"Value for {fieldName} ('{value}') must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox.Focus(); return double.NaN;
                }
                return value;
            }
            else
            {
                MessageBox.Show(this, $"Invalid input for {fieldName}: '{textBox.Text}'. Please enter a valid number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus(); return double.NaN;
            }
        }

        private double ProcessCategory(string categoryName)
        {
            if (!categoryRawAverages.ContainsKey(categoryName))
            {
                categoryRawAverages[categoryName] = 0;
            }

            List<double> itemScoresAsPercentages = new List<double>();
            for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
            {
                Control scoreControl = FindControlRecursive(this, $"txt{categoryName}Score{i}");
                if (scoreControl == null) { if (i == 1) Debug.WriteLine($"Info: No input control for {categoryName} item 1 (txt{categoryName}Score1)."); break; }
                TextBox scoreTextBox = scoreControl as TextBox;
                if (scoreTextBox == null) { Debug.WriteLine($"Warning: Control txt{categoryName}Score{i} not TextBox."); continue; }
                if (string.IsNullOrWhiteSpace(scoreTextBox.Text)) continue;

                double scoreAsPercentage = GetDoubleFromTextBox(scoreTextBox, $"{categoryName} Score {i}");
                if (double.IsNaN(scoreAsPercentage)) { return double.NaN; }
                itemScoresAsPercentages.Add(scoreAsPercentage);
            }

            double overallAverage = (itemScoresAsPercentages.Count > 0) ? itemScoresAsPercentages.Average() : 0;
            categoryRawAverages[categoryName] = overallAverage;

            Control finalPercentageControl = FindControlRecursive(this, $"txt{categoryName}FinalPercentage");
            if (finalPercentageControl is TextBox txtFinal) { txtFinal.Text = overallAverage.ToString("F2") + "%"; }
            else if (finalPercentageControl is Label lblFinal) { lblFinal.Text = overallAverage.ToString("F2") + "%"; }

            double weightPercentage = 0;
            TextBox weightTextBox = FindControlRecursive(this, $"txt{categoryName}Weight") as TextBox;
            if (weightTextBox != null && !string.IsNullOrWhiteSpace(weightTextBox.Text))
            {
                weightPercentage = GetDoubleFromTextBox(weightTextBox, $"{categoryName} Weight");
                if (double.IsNaN(weightPercentage)) { return double.NaN; }
            }

            double weightedContribution = overallAverage * (weightPercentage / 100.0);
            Control weightedContributionControl = FindControlRecursive(this, $"txt{categoryName}WeightedContribution");
            if (weightedContributionControl is TextBox txtContrib) { txtContrib.Text = weightedContribution.ToString("F2"); }
            else if (weightedContributionControl is Label lblContrib) { lblContrib.Text = weightedContribution.ToString("F2"); }

            return weightedContribution;
        }

        private double CalculateOverallClassStanding()
        {
            double totalClassStanding = 0;
            double totalWeightSum = 0;
            bool calculationFailed = false;
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };

            categoryRawAverages.Clear();

            foreach (string category in categories)
            {
                double categoryContribution = ProcessCategory(category);
                if (double.IsNaN(categoryContribution)) { calculationFailed = true; break; }
                totalClassStanding += categoryContribution;

                TextBox weightBox = FindControlRecursive(this, $"txt{category}Weight") as TextBox;
                if (weightBox != null && !string.IsNullOrWhiteSpace(weightBox.Text))
                {
                    double weightValue = GetDoubleFromTextBox(weightBox, $"{category} Weight (for sum check)");
                    if (double.IsNaN(weightValue)) { calculationFailed = true; break; }
                    totalWeightSum += weightValue;
                }
            }

            if (calculationFailed)
            {
                Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Overall calculation aborted.");
                return double.NaN;
            }

            bool anyWeightActuallyEntered = categories.Any(cat =>
            {
                TextBox wb = FindControlRecursive(this, $"txt{cat}Weight") as TextBox;
                return wb != null && !string.IsNullOrWhiteSpace(wb.Text) && GetDoubleFromTextBox(wb, $"{cat} Weight Check") > 0;
            });

            if (anyWeightActuallyEntered && Math.Abs(totalWeightSum - 100.0) > 0.01)
            {
                MessageBox.Show(this, $"Total weights must sum to 100%. Current sum: {totalWeightSum:F2}%", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return double.NaN;
            }
            Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Final CS: {totalClassStanding:F2}%");
            return totalClassStanding;
        }

        private void button1_Click(object sender, EventArgs e) // Submit Button
        {
            Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Submit button clicked.");
            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0 || string.IsNullOrEmpty(_gradingTerm))
            {
                MessageBox.Show(this, $"Cannot save. Course details (AcademicPeriodId: {_selectedCourse?.AcademicPeriodId}) or term are missing.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (_gradingTerm != "Prelim")
            {
                MessageBox.Show(this, $"This form is for Prelim term only. Current: '{_gradingTerm}'. Data not saved.", "Term Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double totalClassStandingRaw = CalculateOverallClassStanding();

            if (double.IsNaN(totalClassStandingRaw))
            {
                Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Aborting submit due to NaN calculation result.");
                return;
            }

            Control classStandingResultControl = FindControlRecursive(this, "txtClassStandingResult");
            if (classStandingResultControl is TextBox txtResultCtrl) { txtResultCtrl.Text = totalClassStandingRaw.ToString("F2") + "%"; }
            else if (classStandingResultControl is Label lblResultCtrl) { lblResultCtrl.Text = $"Calculated {_gradingTerm} CS: {totalClassStandingRaw:F2}%"; }


            decimal weightedClassStandingForTerm = (decimal)totalClassStandingRaw * 0.50m;

            decimal? dbQuizScore = categoryRawAverages.TryGetValue("Quiz", out double qAvg) ? (decimal)qAvg : (decimal?)null;
            decimal? dbAssignmentScore = categoryRawAverages.TryGetValue("Assignment", out double aAvg) ? (decimal)aAvg : (decimal?)null;
            decimal? dbSeatworkScore = categoryRawAverages.TryGetValue("Seatwork", out double sAvg) ? (decimal)sAvg : (decimal?)null;
            decimal? dbLaboratoryScore = categoryRawAverages.TryGetValue("Laboratory", out double lAvg) ? (decimal)lAvg : (decimal?)null;
            decimal? dbRecitationScore = categoryRawAverages.TryGetValue("Recitation", out double rAvg) ? (decimal)rAvg : (decimal?)null;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    int? existingTermGradeID = null;
                    // Assuming CourseID in TermGrades table corresponds to AcademicPeriodId
                    string checkQuery = "SELECT TermGradeID FROM dbo.TermGrades WHERE CourseID = @AcademicPeriodId AND TermName = @TermName";

                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, con))
                    {
                        checkCmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                        checkCmd.Parameters.AddWithValue("@TermName", _gradingTerm);
                        object result = checkCmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            existingTermGradeID = Convert.ToInt32(result);
                        }
                    }

                    bool isUpdate = existingTermGradeID.HasValue;
                    string sql;

                    if (isUpdate)
                    {
                        sql = @"UPDATE dbo.TermGrades SET
                                    QuizScore = @QuizScore, AssignmentScore = @AssignmentScore, SeatworkScore = @SeatworkScore,
                                    LaboratoryScore = @LaboratoryScore, RecitationScore = @RecitationScore,
                                    TotalClassStandingRaw = @TotalClassStandingRaw, WeightedClassStanding = @WeightedClassStanding
                                WHERE TermGradeID = @TermGradeID_ForUpdate";
                        Debug.WriteLine($"Updating TermGrades for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}, Term: {_gradingTerm}, ID: {existingTermGradeID.Value}");
                    }
                    else
                    {
                        // CourseID in TermGrades will store AcademicPeriodId
                        sql = @"INSERT INTO dbo.TermGrades
                                    (CourseID, TermName, QuizScore, AssignmentScore, SeatworkScore, LaboratoryScore, RecitationScore,
                                     TotalClassStandingRaw, WeightedClassStanding, ExamScore, PreviousTermGradeContribution, CalculatedTermGrade)
                                VALUES
                                    (@AcademicPeriodId, @TermName, @QuizScore, @AssignmentScore, @SeatworkScore, @LaboratoryScore, @RecitationScore,
                                     @TotalClassStandingRaw, @WeightedClassStanding, NULL, NULL, NULL)";
                        Debug.WriteLine($"Inserting new TermGrades for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}, Term: {_gradingTerm}");
                    }

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        // Use @AcademicPeriodId for the CourseID column in TermGrades
                        cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                        cmd.Parameters.AddWithValue("@TermName", _gradingTerm);

                        if (isUpdate)
                        {
                            cmd.Parameters.AddWithValue("@TermGradeID_ForUpdate", existingTermGradeID.Value);
                        }

                        AddDecimalParameter(cmd, "@QuizScore", dbQuizScore);
                        AddDecimalParameter(cmd, "@AssignmentScore", dbAssignmentScore);
                        AddDecimalParameter(cmd, "@SeatworkScore", dbSeatworkScore);
                        AddDecimalParameter(cmd, "@LaboratoryScore", dbLaboratoryScore);
                        AddDecimalParameter(cmd, "@RecitationScore", dbRecitationScore);

                        cmd.Parameters.AddWithValue("@TotalClassStandingRaw", (decimal)totalClassStandingRaw);
                        cmd.Parameters.AddWithValue("@WeightedClassStanding", weightedClassStandingForTerm);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show(this, $"{_gradingTerm} Class Standing components saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show(this, $"Database error: " + sqlEx.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debug.WriteLine($"DB Save Error ({_gradingTerm}): " + sqlEx.ToString());
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debug.WriteLine($"General Save Error ({_gradingTerm}): " + ex.ToString());
                    return;
                }
            }

            DialogResult proceedToExamEntry = MessageBox.Show(this,
                $"{_gradingTerm} Class Standing saved. Proceed to Exam Grade Entry?",
                "Next Step", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            if (proceedToExamEntry == DialogResult.OK)
            {
                Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Proceeding to Exam Entry.");
                try
                {
                    this.Hide();
                    using (classExamprelim examEntryForm = new classExamprelim(
                        _selectedCourse, _gradingTerm, _selectCourseForm, _dashboardForm))
                    {
                        examEntryForm.ShowDialog(this);
                    }
                    Debug.WriteLine($"classStandingprelim ({_gradingTerm}): examEntryForm closed. This form will now close.");
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"Error opening Exam form: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debug.WriteLine($"Error opening Exam form - {ex.Message}\n{ex.StackTrace}");
                    this.DialogResult = DialogResult.Abort;
                    if (!this.IsDisposed) { this.Show(); } else { this.Close(); }
                }
            }
            else
            {
                Debug.WriteLine($"classStandingprelim ({_gradingTerm}): User chose NOT to proceed.");
                this.DialogResult = DialogResult.Cancel;
            }
        }

        private void AddDecimalParameter(SqlCommand cmd, string paramName, decimal? value)
        {
            SqlParameter param = new SqlParameter(paramName, SqlDbType.Decimal);
            param.Precision = 5;
            param.Scale = 2;
            param.Value = value.HasValue ? (object)value.Value : DBNull.Value;
            cmd.Parameters.Add(param);
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Clear button clicked.");
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };
            foreach (string category in categories)
            {
                for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
                {
                    if (FindControlRecursive(this, $"txt{category}Score{i}") is TextBox scoreTextBox) { scoreTextBox.Clear(); }
                }
                if (FindControlRecursive(this, $"txt{category}Weight") is TextBox weightTextBox) { weightTextBox.Clear(); }
                if (FindControlRecursive(this, $"txt{category}FinalPercentage") is TextBox txtFinal) { txtFinal.Clear(); }
                else if (FindControlRecursive(this, $"txt{category}FinalPercentage") is Label lblFinal) { lblFinal.Text = ""; }
                if (FindControlRecursive(this, $"txt{category}WeightedContribution") is TextBox txtContrib) { txtContrib.Clear(); }
                else if (FindControlRecursive(this, $"txt{category}WeightedContribution") is Label lblContrib) { lblContrib.Text = ""; }
            }
            if (FindControlRecursive(this, "txtClassStandingResult") is TextBox txtCsResult) { txtCsResult.Clear(); }
            else if (FindControlRecursive(this, "txtClassStandingResult") is Label lblCsResult) { lblCsResult.Text = "Calculated Class Standing:"; }

            categoryRawAverages.Clear();
            FindControlRecursive(this, "txtQuizScore1")?.Focus();
        }

        private void button3_Click(object sender, EventArgs e) // Back Button
        {
            Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Back button clicked.");
            this.DialogResult = DialogResult.Cancel;
            this.Hide();
            if (_selectCourseForm != null && !_selectCourseForm.IsDisposed) { _selectCourseForm.Show(); }
            else if (_dashboardForm != null && !_dashboardForm.IsDisposed) { _dashboardForm.Show(); }
            this.Close();
        }

        private void classStandingprelim_Load(object sender, EventArgs e)
        {
            Debug.WriteLine($"classStandingprelim ({_gradingTerm}): Form_Load event.");
            if (_selectedCourse == null && !(this.DesignMode))
            {
                Debug.WriteLine("classStandingprelim (Load Event): Form loaded without course data. Disabling submit.");
                Control submitButton = FindControlRecursive(this, "button1");
                if (submitButton != null) submitButton.Enabled = false;
            }
        }

        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }

        // --- Empty TextChanged Event Handlers ---
        private void txtQuizWeight_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentWeight_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkWeight_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryWeight_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationWeight_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore1_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore2_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore3_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore4_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore5_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore6_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore7_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore8_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore9_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore10_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore1_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore2_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore3_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore4_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore5_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore6_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore7_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore8_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore9_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore10_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore1_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore2_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore3_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore4_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore5_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore6_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore7_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore8_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore9_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore10_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore1_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore2_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore3_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore4_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore5_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore6_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore7_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore8_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore9_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore10_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore1_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore2_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore3_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore4_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore5_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore6_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore7_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore8_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore9_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore10_TextChanged(object sender, EventArgs e) { }
    }
}