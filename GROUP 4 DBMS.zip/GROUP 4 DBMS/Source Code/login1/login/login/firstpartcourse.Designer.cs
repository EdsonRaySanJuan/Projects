﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace login
{
    // Make sure your class inherits from Form if it's a Windows Form
    public partial class firstpartcourse : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            comboBox1 = new ComboBox();
            label8 = new Label();
            label2 = new Label();
            comboBox2 = new ComboBox();
            label3 = new Label();
            textBox1 = new TextBox();
            button2 = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(49, 54);
            label1.Name = "label1";
            label1.Size = new Size(193, 27);
            label1.TabIndex = 33;
            label1.Text = "Course Details";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(49, 148);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(185, 23);
            comboBox1.TabIndex = 34;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.Location = new Point(49, 124);
            label8.Name = "label8";
            label8.Size = new Size(149, 21);
            label8.TabIndex = 43;
            label8.Text = "Select School Year";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.Location = new Point(49, 189);
            label2.Name = "label2";
            label2.Size = new Size(130, 21);
            label2.TabIndex = 45;
            label2.Text = "Select Semester";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(49, 213);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(185, 23);
            comboBox2.TabIndex = 44;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.Location = new Point(49, 252);
            label3.Name = "label3";
            label3.Size = new Size(193, 21);
            label3.TabIndex = 47;
            label3.Text = "Enter Number of Course";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(49, 276);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(185, 23);
            textBox1.TabIndex = 48;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(166, 319);
            button2.Name = "button2";
            button2.Size = new Size(88, 47);
            button2.TabIndex = 51;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(38, 319);
            button1.Name = "button1";
            button1.Size = new Size(88, 47);
            button1.TabIndex = 50;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // firstpartcourse
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.th__1___4___1_;
            ClientSize = new Size(289, 399);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(comboBox2);
            Controls.Add(label8);
            Controls.Add(comboBox1);
            Controls.Add(label1);
            Name = "firstpartcourse";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "firstpartcourse";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox comboBox1;
        private Label label8;
        private Label label2;
        private ComboBox comboBox2;
        private Label label3;
        private TextBox textBox1;
        private Button button2;
        private Button button1;

        // --- Add these missing event handler methods ---

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Your code for when the selected index of comboBox1 changes goes here
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Your code for when the selected index of comboBox2 changes goes here
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Your code for when the text in textBox1 changes goes here
        }

        
    }
}