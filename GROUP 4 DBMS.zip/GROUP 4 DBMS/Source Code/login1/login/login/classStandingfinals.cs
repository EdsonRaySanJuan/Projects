﻿// classStandingfinals.cs - Final Version with ALL TextChanged and specified Click handlers

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // Added for Debug.WriteLine

namespace login
{
    public partial class classStandingfinals : Form
    {
        // Fields to store received data and form references
        private CourseDetails _selectedCourse;
        private string _gradingTerm;     // Should be "Finals" for this specific form
        private Form _selectCourseForm;
        private Form _dashboardForm;

        const int MAX_INPUT_ROWS_PER_CATEGORY = 10;

        // Parameterized constructor
        public classStandingfinals(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard)
        {
            InitializeComponent();
            _selectedCourse = course;
            _gradingTerm = gradingTerm; // Expecting "Finals"
            _selectCourseForm = selectCourseForm;
            _dashboardForm = dashboard;

            UpdateFormDisplay();
            Debug.WriteLine($"classStandingfinals: Constructor called. Course: {course?.Code}, Grading Term: {gradingTerm}.");
        }

        // Parameterless constructor
        public classStandingfinals()
        {
            InitializeComponent();
            _selectedCourse = null;
            _gradingTerm = "Finals"; // Default for this specific form
            _selectCourseForm = null;
            _dashboardForm = null;
            this.Load += (s, e) => HandleParameterlessConstructorContext();
            UpdateFormDisplay();
            Debug.WriteLine("classStandingfinals: Parameterless constructor called.");
        }

        private void HandleParameterlessConstructorContext()
        {
            if (_selectedCourse == null && !(this.DesignMode))
            {
                MessageBox.Show(this, "Warning: Finals Class Standing form initialized without required course data. Please ensure a course is selected.", "Initialization Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Debug.WriteLine("Warning: classStandingfinals initialized without expected course data.");
                Control submitButton = this.Controls.Find("button1_Click_1", true).FirstOrDefault() ?? this.Controls.Find("button1", true).FirstOrDefault();
                if (submitButton != null) submitButton.Enabled = false;
            }
        }

        private void UpdateFormDisplay()
        {
            string formTitle;
            string courseDisplayText = "Course N/A";
            string termDisplayText = $"Term: {_gradingTerm}";

            if (_selectedCourse != null)
            {
                formTitle = $"{_gradingTerm} Class Standing - {_selectedCourse.Name} ({_selectedCourse.Code})";
                courseDisplayText = $"{_selectedCourse.Name} ({_selectedCourse.Code})";
            }
            else
            {
                formTitle = $"{_gradingTerm} Class Standing";
            }

            this.Text = formTitle;

            Control lblCourseControl = this.Controls.Find("label4", true).FirstOrDefault();
            if (lblCourseControl is Label courseLabel)
            {
                courseLabel.Text = courseDisplayText;
            }
            else { Debug.WriteLine("classStandingfinals Warning: Control 'label4' for Course Subject display not found."); }

            Control lblTermControl = this.Controls.Find("label1", true).FirstOrDefault();
            if (lblTermControl is Label termLabel)
            {
                termLabel.Text = termDisplayText;
            }
            else { Debug.WriteLine("classStandingfinals Warning: Control 'label1' for Term display not found."); }
        }

        // --- Calculation Logic (Identical to other classStanding forms) ---
        private double GetDoubleFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null) { Debug.WriteLine($"Warning: Textbox for {fieldName} is null."); return 0; }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }
            if (double.TryParse(textBox.Text.Trim(), out double value)) { return value; }
            else { MessageBox.Show(this, $"Invalid input for {fieldName}: '{textBox.Text}'. Please enter a valid number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error); textBox.Focus(); return double.NaN; }
        }

        private double ProcessCategory(string categoryName)
        {
            List<double> itemScoresAsPercentages = new List<double>();
            for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
            {
                Control scoreControl = this.Controls.Find($"txt{categoryName}Score{i}", true).FirstOrDefault();
                if (scoreControl == null)
                {
                    if (i == 1) { Debug.WriteLine($"Info: No input controls for {categoryName} (e.g., txt{categoryName}Score1)."); }
                    else { Debug.WriteLine($"Info: No more score controls for {categoryName} from item {i}."); }
                    break;
                }
                TextBox scoreTextBox = scoreControl as TextBox;
                if (scoreTextBox == null) { Debug.WriteLine($"Warning: Control txt{categoryName}Score{i} not TextBox."); continue; }
                if (string.IsNullOrWhiteSpace(scoreTextBox.Text)) { Debug.WriteLine($"Info: Skipping empty input for {categoryName} item {i}."); continue; }

                double scoreAsPercentage = GetDoubleFromTextBox(scoreTextBox, $"{categoryName} Score {i}");
                if (double.IsNaN(scoreAsPercentage)) { return double.NaN; }
                if (scoreAsPercentage < 0 || scoreAsPercentage > 100)
                { MessageBox.Show(this, $"Score for {categoryName} item {i} must be 0-100.", "Input Error"); scoreTextBox.Focus(); return double.NaN; }
                itemScoresAsPercentages.Add(scoreAsPercentage);
            }
            double overallAverage = (itemScoresAsPercentages.Count > 0) ? itemScoresAsPercentages.Average() : 0;
            if (this.Controls.Find($"txt{categoryName}FinalPercentage", true).FirstOrDefault() is TextBox txtFinal) { txtFinal.Text = overallAverage.ToString("F2") + "%"; }

            double weightPercentage = 0;
            if (this.Controls.Find($"txt{categoryName}Weight", true).FirstOrDefault() is TextBox weightTextBox && !string.IsNullOrWhiteSpace(weightTextBox.Text))
            {
                weightPercentage = GetDoubleFromTextBox(weightTextBox, $"{categoryName} Weight");
                if (double.IsNaN(weightPercentage) || weightPercentage < 0 || weightPercentage > 100)
                { MessageBox.Show(this, $"Weight for {categoryName} must be 0-100.", "Input Error"); weightTextBox.Focus(); return double.NaN; }
            }
            double weightedContribution = overallAverage * (weightPercentage / 100.0);
            if (this.Controls.Find($"txt{categoryName}WeightedContribution", true).FirstOrDefault() is TextBox txtContrib) { txtContrib.Text = weightedContribution.ToString("F2"); }
            return weightedContribution;
        }

        private double CalculateOverallClassStanding()
        {
            double totalClassStanding = 0;
            double totalWeightSum = 0;
            bool calculationFailed = false;
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };
            Debug.WriteLine($"classStandingfinals ({_gradingTerm}): Starting CalculateOverallClassStanding...");
            foreach (string category in categories)
            {
                double categoryContribution = ProcessCategory(category);
                if (double.IsNaN(categoryContribution)) { calculationFailed = true; break; }
                totalClassStanding += categoryContribution;
                if (this.Controls.Find($"txt{category}Weight", true).FirstOrDefault() is TextBox weightBox && !string.IsNullOrWhiteSpace(weightBox.Text))
                {
                    if (double.TryParse(weightBox.Text, out double weight)) totalWeightSum += weight; else { calculationFailed = true; break; }
                }
            }
            if (calculationFailed) { Debug.WriteLine($"classStandingfinals ({_gradingTerm}): Calculation aborted."); return double.NaN; }

            bool anyWeightActuallyEntered = categories.Any(cat => (this.Controls.Find($"txt{cat}Weight", true).FirstOrDefault() as TextBox)?.Text.Length > 0);
            if (anyWeightActuallyEntered && Math.Abs(totalWeightSum - 100.0) > 0.01)
            {
                MessageBox.Show(this, $"Total weights ({totalWeightSum:F2}%) should sum to 100%.", "Weight Sum Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            Debug.WriteLine($"classStandingfinals ({_gradingTerm}): Final CS: {totalClassStanding:F2}%");
            return totalClassStanding;
        }
        // --- End of Calculation Logic ---

        // Submit/Calculate Button for Finals CS
        // Assuming it's named button1_Click_1 based on your classStandingmidterm.cs
        private void button1_Click_1(object sender, EventArgs e)
        {
            Debug.WriteLine($"classStandingfinals: Submit button (button1_Click_1) for {_gradingTerm} clicked.");
            if (_selectedCourse == null)
            {
                MessageBox.Show(this, "Cannot calculate Finals class standing. Course details are missing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double calculatedClassStanding = CalculateOverallClassStanding();
            Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();

            if (!double.IsNaN(calculatedClassStanding))
            {
                string resultText = $"Finals Class Standing: {calculatedClassStanding:F2}%";
                if (classStandingResultControl is TextBox txtResult) { txtResult.Text = calculatedClassStanding.ToString("F2") + "%"; }
                else if (classStandingResultControl is Label lblResult) { lblResult.Text = resultText; }
                else { MessageBox.Show(this, resultText, "Finals Result", MessageBoxButtons.OK, MessageBoxIcon.Information); }

                Debug.WriteLine($"Finals Class Standing: {calculatedClassStanding:F2}% for course {_selectedCourse.Code} ({_selectedCourse.Name}) Term: {_gradingTerm}");

                DialogResult proceedToFinalsExam = MessageBox.Show(this,
                    "Finals Class Standing calculation complete. Proceed to Finals Exam Entry?",
                    "Next Step", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (proceedToFinalsExam == DialogResult.Yes)
                {
                    Debug.WriteLine("classStandingfinals: User chose to proceed to Finals Exam Entry.");
                    try
                    {
                        this.Hide();
                        // ASSUMPTION: You will create classExamfinals.cs
                        // And it has a constructor: public classExamfinals(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboardForm)
                        using (classExamfinals finalsExamForm = new classExamfinals(
                            _selectedCourse,
                            "Finals",
                            _selectCourseForm,
                            _dashboardForm
                            ))
                        {
                            finalsExamForm.ShowDialog(this);
                        }
                        Debug.WriteLine("classStandingfinals: Finals Exam form closed. Navigating to dashboard.");
                        if (_dashboardForm != null && !_dashboardForm.IsDisposed)
                        {
                            _dashboardForm.Show();
                        }
                        else
                        {
                            Debug.WriteLine("classStandingfinals Error: Dashboard form is null/disposed.");
                            Application.Exit();
                        }
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error opening Finals Exam Entry form: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Debug.WriteLine($"classStandingfinals: Error opening Finals Exam form - {ex.Message}\n{ex.StackTrace}");
                        if (!this.IsDisposed) { this.Show(); }
                    }
                }
            }
        }

        // Clear Button for Finals CS
        // Assuming it's named button2_Click_1
        private void button2_Click_1(object sender, EventArgs e)
        {
            Debug.WriteLine("classStandingfinals: Clear Inputs button (button2_Click_1) clicked.");
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };
            foreach (string category in categories)
            {
                for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
                {
                    if (this.Controls.Find($"txt{category}Score{i}", true).FirstOrDefault() is TextBox scoreTextBox) { scoreTextBox.Clear(); }
                }
                if (this.Controls.Find($"txt{category}Weight", true).FirstOrDefault() is TextBox weightTextBox) { weightTextBox.Clear(); }
                if (this.Controls.Find($"txt{category}FinalPercentage", true).FirstOrDefault() is TextBox txtFinal) { txtFinal.Clear(); }
                else if (this.Controls.Find($"txt{category}FinalPercentage", true).FirstOrDefault() is Label lblFinal) { lblFinal.Text = ""; }
                if (this.Controls.Find($"txt{category}WeightedContribution", true).FirstOrDefault() is TextBox txtContrib) { txtContrib.Clear(); }
                else if (this.Controls.Find($"txt{category}WeightedContribution", true).FirstOrDefault() is Label lblContrib) { lblContrib.Text = ""; }
            }
            if (this.Controls.Find("txtClassStandingResult", true).FirstOrDefault() is TextBox txtCsResult) { txtCsResult.Clear(); }
            else if (this.Controls.Find("txtClassStandingResult", true).FirstOrDefault() is Label lblCsResult) { lblCsResult.Text = "Finals Class Standing:"; }
            this.Controls.Find("txtQuizScore1", true).FirstOrDefault()?.Focus();
        }

        // Back button
        // Assuming it's named button3
        private void button3_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("classStandingfinals: Back button (button3) clicked.");
            this.Hide();
            if (_selectCourseForm != null && !_selectCourseForm.IsDisposed)
            { _selectCourseForm.Show(); }
            else if (_dashboardForm != null && !_dashboardForm.IsDisposed)
            { _dashboardForm.Show(); }
            else { MessageBox.Show(this, "Cannot navigate back. Previous form references missing.", "Navigation Error"); this.Close(); }
        }

        private void classStandingfinals_Load(object sender, EventArgs e)
        {
            Debug.WriteLine("classStandingfinals form loaded.");
            UpdateFormDisplay();
            if (_selectedCourse == null && !(this.DesignMode))
            {
                Debug.WriteLine("classStandingfinals: Form loaded without selected course data.");
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e) { }

        // --- Included TextChanged Event Handlers ---
        // quiz weight percentage
        private void txtQuizWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtAssignmentWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtSeatworkWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtLaboratoryWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtRecitationWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }

        // quiz score textboxes 1-10
        private void txtQuizScore1_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtQuizScore2_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtQuizScore3_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore4_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore5_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore6_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore7_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore8_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore9_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore10_TextChanged(object sender, EventArgs e) { }

        private void txtAssignmentScore1_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore2_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore3_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore4_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore5_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore6_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore7_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore8_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore9_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore10_TextChanged(object sender, EventArgs e) { }

        private void txtSeatworkScore1_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore2_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore3_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore4_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore5_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore6_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore7_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore8_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore9_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore10_TextChanged(object sender, EventArgs e) { }

        private void txtLaboratoryScore1_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore2_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore3_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore4_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore5_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore6_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore7_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore8_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore9_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore10_TextChanged(object sender, EventArgs e) { }

        private void txtRecitationScore1_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore2_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore3_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore4_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore5_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore6_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore7_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore8_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore9_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore10_TextChanged(object sender, EventArgs e) { }
        // --- End of Included TextChanged Event Handlers ---

        // Event handlers for label clicks from your original classStandingmidterm.cs
        private void label1_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { } // This seems to be for the Course Subject Label

        // This was label4_Click_1 from your classStandingmidterm code.
        // If this is wired to a different label or the same label4 for a different purpose, keep it.
        // If label4's click should do something, the logic goes here.
        private void label4_Click_1(object sender, EventArgs e)
        {
            // If you want clicking on label4 (Course Subject) to do something:
            // if (_selectedCourse != null)
            // {
            //    MessageBox.Show($"You clicked on course: {_selectedCourse.Name}", "Course Clicked");
            // }
        }
    }
}