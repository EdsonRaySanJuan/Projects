﻿using System;
using System.Collections.Generic; // Added for List
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Make sure you are using the correct SQL Client namespace if needed in this form
// using System.Data.SqlClient;
// using Microsoft.Data.SqlClient;

namespace login
{
    // CourseDetails class is defined in a shared file/namespace
    // Ensure this class definition is accessible.
    // *** IMPORTANT: Ensure CourseDetails class has the AcademicPeriodId property ***
    /*
    public class CourseDetails
    {
        // ... (Existing properties) ...
        public int AcademicPeriodId { get; set; } // Make sure this property is added
    }
    */

    public partial class course_op : Form
    {
        // ... (Your existing field declarations) ...
        private string schoolYear;
        private string semester;
        private int totalCourses;
        private int currentCourseNumber; // Should be 1 for this form
        internal Form previousForm;     // Reference back to firstpartcourse
        private Form dashboardForm;
        private List<CourseDetails> enteredCourses; // List to hold course details

        // *** NEW: Field to store the Academic Period ID ***
        private int academicPeriodId;


        // --- Modified Constructors ---

        // Constructor updated to accept the academicPeriodId (8 arguments)
        public course_op(string year, string sem, int totalNumCourses, int currentCourseNum, Form callingForm, Form dashboard, List<CourseDetails> collectedDataSoFar, int academicPeriodId) // *** Added academicPeriodId parameter ***
        {
            InitializeComponent();
            // Store all the received data
            this.schoolYear = year;
            this.semester = sem;
            this.totalCourses = totalNumCourses;
            this.currentCourseNumber = currentCourseNum;
            this.previousForm = callingForm;
            this.dashboardForm = dashboard;
            this.enteredCourses = collectedDataSoFar;
            this.academicPeriodId = academicPeriodId; // *** Store the received ID ***

            this.Load += course_op_Load;
        }

        // Keep the parameterless constructor (if needed)
        public course_op()
        {
            InitializeComponent();
            this.Load += course_op_Load;
            this.enteredCourses = new List<CourseDetails>(); // Initialize list
            this.Load += (s, e) =>
            {
                // Handle case if opened directly - data fields will be null/0/default
                if (totalCourses == 0 || dashboardForm == null || enteredCourses == null || academicPeriodId == 0)
                {
                    MessageBox.Show("This form was opened directly and is not fully initialized with Academic Period ID.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // Disable key controls if data is missing
                    Control[] foundControls = this.Controls.Find("button1", true);
                    if (foundControls.Length > 0 && foundControls[0] is Button btn1) btn1.Enabled = false;
                    foundControls = this.Controls.Find("button2", true);
                    if (foundControls.Length > 0 && foundControls[0] is Button btn2) btn2.Enabled = false;
                }
            };
        }

        // --- Form Load and Initialization ---
        private void course_op_Load(object sender, EventArgs e)
        {
            // Ensure the form was initialized correctly, including the Academic Period ID
            if (totalCourses < 1 || currentCourseNumber != 1 || dashboardForm == null || enteredCourses == null || academicPeriodId == 0) // *** Added check for academicPeriodId ***
            {
                MessageBox.Show("This form was initialized incorrectly. Expected Course 1. Missing required data or Academic Period ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Control[] foundBtn1 = this.Controls.Find("button1", true);
                if (foundBtn1.Length > 0 && foundBtn1[0] is Button btn1) btn1.Enabled = false;
                Control[] foundBtn2 = this.Controls.Find("button2", true);
                if (foundBtn2.Length > 0 && foundBtn2[0] is Button btn2) btn2.Enabled = false;
                return; // Exit Load if invalid state
            }

            // Update a label to show "Course 1 of N" (assuming lblCourseNumber)
            Control[] foundLabels = this.Controls.Find("lblCourseNumber", true);
            if (foundLabels.Length > 0 && foundLabels[0] is Label lblCourseNumber)
            {
                lblCourseNumber.Text = $"Course {currentCourseNumber} of {totalCourses}";
            }

            // Change button text based on if this is the LAST course entry form for the given N
            Control[] foundBtnSubmit = this.Controls.Find("button1", true);
            if (foundBtnSubmit.Length > 0 && foundBtnSubmit[0] is Button btnSubmit)
            {
                if (currentCourseNumber == totalCourses) // If N=1, submit
                {
                    btnSubmit.Text = "Submit"; // Change to Submit
                }
                else // currentCourseNumber < totalCourses - If N > 1, move to course_op1
                {
                    btnSubmit.Text = "Next"; // Keep as Next
                }
            }


            // Set initial focus
            Control[] foundTextBox1 = this.Controls.Find("textBox1", true);
            if (foundTextBox1.Length > 0 && foundTextBox1[0] is TextBox tb1)
            {
                tb1.Focus();
            }
        }

        // --- Textbox Changed Events (Keep your existing empty methods) ---
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }


        // --- Modified Button Click Event ---
        private void button1_Click(object sender, EventArgs e)
        {
            // Ensure the form was initialized correctly (keep your existing check)
            if (totalCourses < 1 || currentCourseNumber != 1 || dashboardForm == null || enteredCourses == null || academicPeriodId == 0) // *** Added check for academicPeriodId ***
            {
                MessageBox.Show("This form is in an unexpected state for Course 1 processing. Missing required data or Academic Period ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // --- Get and Validate Course 1 Data (Keep your existing validation) ---
            string courseCode = "";
            string courseName = "";
            string unitsText = "";

            Control[] foundTextBox1 = this.Controls.Find("textBox1", true);
            if (foundTextBox1.Length > 0 && foundTextBox1[0] is TextBox textBox1Control) courseCode = textBox1Control.Text.Trim();
            else { MessageBox.Show("Configuration Error: 'textBox1' not found.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

            Control[] foundTextBox2 = this.Controls.Find("textBox2", true);
            if (foundTextBox2.Length > 0 && foundTextBox2[0] is TextBox textBox2Control) courseName = textBox2Control.Text.Trim();
            else { MessageBox.Show("Configuration Error: 'textBox2' not found.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

            Control[] foundTextBox4 = this.Controls.Find("textBox4", true);
            if (foundTextBox4.Length > 0 && foundTextBox4[0] is TextBox textBox4Control) unitsText = textBox4Control.Text.Trim();
            else { MessageBox.Show("Configuration Error: 'textBox4' not found.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }


            int units;
            if (string.IsNullOrWhiteSpace(courseCode) || string.IsNullOrWhiteSpace(courseName) || string.IsNullOrWhiteSpace(unitsText))
            {
                MessageBox.Show($"Please fill in all fields for Course {currentCourseNumber}.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (string.IsNullOrWhiteSpace(courseCode) && foundTextBox1.Length > 0) foundTextBox1[0].Focus();
                else if (string.IsNullOrWhiteSpace(courseName) && foundTextBox2.Length > 0) foundTextBox2[0].Focus();
                else if (string.IsNullOrWhiteSpace(unitsText) && foundTextBox4.Length > 0) foundTextBox4[0].Focus();
                return;
            }
            if (!int.TryParse(unitsText, out units) || units <= 0)
            {
                MessageBox.Show($"Please enter a valid positive number for Units for Course {currentCourseNumber}.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (foundTextBox4.Length > 0) foundTextBox4[0].Focus();
                return;
            }

            // --- Save Course 1 Data (Modified to include AcademicPeriodId) ---
            CourseDetails course1Details = new CourseDetails
            {
                Code = courseCode,
                Name = courseName,
                Units = units,
                SchoolYear = this.schoolYear,
                Semester = this.semester,
                CourseNumber = this.currentCourseNumber, // This will be 1
                AcademicPeriodId = this.academicPeriodId // *** NEW: Assign the received ID ***
            };
            this.enteredCourses.Add(course1Details); // Add Course 1 details to the list


            // --- Determine Next Step (Submit or Open next form) ---
            if (currentCourseNumber == totalCourses) // If N=1, this is the LAST course entry
            {
                // --- INTEGRATED SELECT TERM FORM LOGIC ---
                // The navigation and saving logic for N=1 (and other N values
                // when the last course form is reached) is handled in selectterm.cs now.

                MessageBox.Show($"All {totalCourses} course entered successfully! Please select the term for grading.", "Course Entry Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);

                try
                {
                    // Create an instance of your selectterm form.
                    // Pass the collected course data AND THIS FORM AND THE DASHBOARD.
                    // *** IMPORTANT: Ensure selectterm has the constructor: public selectterm(List<CourseDetails> courses, Form callingForm, Form dashboard) ***
                    selectterm termForm = new selectterm(this.enteredCourses, this, this.dashboardForm);

                    termForm.Show(); // Show the select term form

                    // Hide the current course form (course_op)
                    this.Hide();

                    // The closing of the previous forms (including firstpartcourse)
                    // is now handled in the selectterm.cs NavigateToSelectCourse method.

                    // We will close the current form (course_op) after selectterm finishes.
                    // Or you can close it here if you prefer, but closing the chain from selectterm is cleaner.
                    // this.Close(); // Option 1: Close course_op here
                }
                catch (MissingMethodException mmEx)
                {
                    MessageBox.Show("Configuration Error: The 'selectterm' form does not have the required constructor (List<CourseDetails>, Form, Form).\nPlease add this constructor to selectterm.cs.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on the current form if navigation failed
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening Select Term form: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on the current form if navigation failed
                }
            }
            else // currentCourseNumber < totalCourses - Move to the next course form (course_op1)
            {
                // --- Your existing code to move to course_op1 (MODIFIED TO PASS academicPeriodId) ---
                int nextCourseNumber = currentCourseNumber + 1; // Should be 2

                try
                {
                    // Open the next form in the chain, which is course_op1
                    // Ensure course_op1 has the correct constructor signature (now with academicPeriodId) and passes the list.
                    course_op1 nextForm = new course_op1(
                        schoolYear,
                        semester,
                        totalCourses,
                        nextCourseNumber, // Pass the NEXT course number (2)
                        this,             // Pass THIS form (course_op) as the previous form for course_op1
                        dashboardForm,    // Pass the dashboard reference
                        this.enteredCourses, // PASSING THE LIST
                        this.academicPeriodId // *** NEW: Pass the Academic Period ID ***
                    );

                    nextForm.Show(); // Show course_op1
                    this.Hide();     // Hide course_op
                }
                catch (MissingMethodException mmEx)
                {
                    MessageBox.Show("Configuration Error: The 'course_op1' form does not have the required constructor (string, string, int, int, Form, Form, List<CourseDetails>, int).\nPlease add this constructor to course_op1.cs.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on current form if navigation failed
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error navigating to next course entry: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on current form if navigation failed
                }
            }
        }

        // --- Clear button (button2) - Keep your existing code ---
        private void button2_Click(object sender, EventArgs e)
        {
            Control[] foundTextBox1 = this.Controls.Find("textBox1", true);
            if (foundTextBox1.Length > 0 && foundTextBox1[0] is TextBox tb1) tb1.Clear();

            Control[] foundTextBox2 = this.Controls.Find("textBox2", true);
            if (foundTextBox2.Length > 0 && foundTextBox2[0] is TextBox tb2) tb2.Clear();

            Control[] foundTextBox4 = this.Controls.Find("textBox4", true);
            if (foundTextBox4.Length > 0 && foundTextBox4[0] is TextBox tb4) tb4.Clear();

            if (foundTextBox1.Length > 0) foundTextBox1[0].Focus();
        }

        // --- Back button (button3) - Keep your existing code ---
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (previousForm != null)
            {
                previousForm.Show();
            }
            else
            {
                MessageBox.Show("Cannot go back from Course 1.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
            }
        }

        private void course_op_Load_1(object sender, EventArgs e)
        {
            
        }
    }
}