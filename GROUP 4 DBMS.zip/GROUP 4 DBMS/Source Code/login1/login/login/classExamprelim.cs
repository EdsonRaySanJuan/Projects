﻿// classExamprelim.cs
// Rewritten to:
// - Use EDSON-LAPTOP server with 'ssms' user.
// - Use AcademicPeriodId for database queries, mapping to TermGrades.CourseID.
// - Fetch and display TotalClassStandingRaw from dbo.TermGrades into txtPCSG.
// - Retain the desired grade calculation logic.
// - Retain the original navigation flow.
// - CORRECTED: Call to classStandingmidterm constructor.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // For SQL Server interaction
using System.Diagnostics;     // For Debug.WriteLine

namespace login
{
    // Assuming CourseDetails class is defined in this namespace and has AcademicPeriodId, Name, Code:
    // public class CourseDetails {
    //     public int AcademicPeriodId { get; set; }
    //     public string Name { get; set; }
    //     public string Code { get; set; }
    //     public string Semester { get; set; } // Added for completeness from other examples
    //     public string SchoolYear { get; set; } // Added for completeness
    //     /* other properties */
    // }

    // Assuming the calling form (classStanding or classStandingprelim)
    // has an accessible _selectCourseForm field/property for navigation.

    public partial class classExamprelim : Form
    {
        private CourseDetails _selectedCourse;
        private string _gradingTerm; // This will be "Prelim"
        private Form _callingForm;
        private Form _dashboardForm;
        private Form _selectCourseForm; // Added to store the reference passed for navigation

        // Corrected Connection String for EDSON-LAPTOP
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";
        private decimal _totalClassStandingRawFromDB = 0m; // Stores fetched raw CS

        // Constants for control names (as provided in your example)
        private const string PrelimCSGradeDisplayTextBoxName = "txtPCSG";
        private const string DesiredGradeInputTextBoxName = "txtPEG";
        private const string CourseSubjectLabelName = "label4"; // For Course Name and Code
        private const string TermInfoLabelName = "label1"; // For Term and "Exam Calculation"
        private const string AcademicPeriodLabelName = "lblAcademicPeriod"; // Specific for SchoolYear/Semester
        private const string SubmitButtonName = "button1";
        // Assuming button2 is Clear and button3 is Back, if they exist on your form.
        // private const string ClearButtonName = "button2";
        // private const string BackButtonName = "button3";


        public classExamprelim(CourseDetails course, string gradingTerm, Form callingForm, Form dashboardForm)
        {
            InitializeComponent();
            _selectedCourse = course;
            _gradingTerm = gradingTerm;
            _callingForm = callingForm; // This is the form that opened classExamprelim
            _dashboardForm = dashboardForm;

            // Store the selectCourseForm reference if the callingForm provides it.
            // This requires the callingForm (e.g., classStandingprelim) to pass its _selectCourseForm reference.
            // The constructor of classExamprelim in "classExamprelim_cs_fixed" took selectCourseForm directly.
            // Your provided "prelim exam1.txt" took "callingForm". We need to bridge this.
            // For now, we'll assume _callingForm might be the _selectCourseForm or can provide it.
            // This part of the logic for `originalSelectCourseForm` in button1_Click will need careful review
            // based on how `_callingForm` is structured and what it passes.
            // If `classStandingprelim` is `_callingForm`, it should pass its `_selectCourseForm` instance.
            // Let's assume `callingForm` itself might be the `_selectCourseForm` or a form that can provide it.
            // For now, to align with the constructor in `classExamprelim_cs_fixed` that was used to call `classStandingmidterm`,
            // we'll assume `callingForm` can act as or provide the `_selectCourseForm` reference.
            // A more robust way is to have a dedicated parameter for `selectCourseForm` if it's always needed.
            if (callingForm is classStandingprelim prelimForm)
            {
                // If classStandingprelim has a public/internal property to get its _selectCourseForm
                // _selectCourseForm = prelimForm.GetSelectCourseForm(); // Example
                // For now, let's assume the callingForm itself might be what's needed or the dashboard is a fallback.
                // This assignment makes `_selectCourseForm` usable by the navigation logic later.
                _selectCourseForm = callingForm; // Or a more specific reference if available from callingForm
            }
            else
            {
                _selectCourseForm = callingForm; // Fallback
            }


            if (_gradingTerm != "Prelim")
            {
                MessageBox.Show($"This form is specifically designed for 'Prelim' term calculations. Received term: '{_gradingTerm}'.", "Term Mismatch Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            this.Load += classExamprelim_Load;
        }

        public classExamprelim()
        {
            InitializeComponent();
            this.Load += (s, e) => {
                if (_selectedCourse == null && !this.DesignMode)
                {
                    MessageBox.Show("Exam calculation form opened without required course details. Please select a course first.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Control submitButton = FindControlRecursive(this, SubmitButtonName);
                    if (submitButton != null) submitButton.Enabled = false;
                    Control desiredGradeInput = FindControlRecursive(this, DesiredGradeInputTextBoxName);
                    if (desiredGradeInput != null) desiredGradeInput.Enabled = false;
                    Control csDisplay = FindControlRecursive(this, PrelimCSGradeDisplayTextBoxName);
                    if (csDisplay is TextBox txtCS) { txtCS.Text = "Error"; txtCS.ReadOnly = true; }
                }
                else
                {
                    DisplayCourseAndTermInfo(); // Update display even in designer or if data is somehow present
                }
            };
        }

        private void classExamprelim_Load(object sender, EventArgs e)
        {
            if (_selectedCourse != null && _selectedCourse.AcademicPeriodId > 0)
            {
                DisplayCourseAndTermInfo();
                LoadAndDisplayCSGrade();

                TextBox desiredGradeInput = FindControlRecursive(this, DesiredGradeInputTextBoxName) as TextBox;
                desiredGradeInput?.Focus();
            }
            else
            {
                MessageBox.Show("Critical error: Course details are missing or invalid (AcademicPeriodId is 0 or less) upon loading the Prelim Exam Calculation form.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Control submitButton = FindControlRecursive(this, SubmitButtonName);
                if (submitButton != null) submitButton.Enabled = false;
                Control csDisplay = FindControlRecursive(this, PrelimCSGradeDisplayTextBoxName);
                if (csDisplay is TextBox txtCS) { txtCS.Text = "Data Error"; txtCS.ReadOnly = true; }
                Control desiredGradeInput = FindControlRecursive(this, DesiredGradeInputTextBoxName);
                if (desiredGradeInput != null) desiredGradeInput.Enabled = false;
            }
        }

        private void DisplayCourseAndTermInfo()
        {
            // Term Info Label (e.g., label1)
            Control termLabelCtrl = FindControlRecursive(this, TermInfoLabelName);
            if (termLabelCtrl is Label lblTerm)
            {
                lblTerm.Text = $"{_gradingTerm ?? "Prelim"} Exam Calculation";
            }
            else
            {
                this.Text = $"{_gradingTerm ?? "Prelim"} Exam Calculation";
                Debug.WriteLine($"Warning: Label control '{TermInfoLabelName}' not found for term display.");
            }

            // Course Subject Label (e.g., label4)
            Control courseLabelCtrl = FindControlRecursive(this, CourseSubjectLabelName);
            if (courseLabelCtrl is Label lblCourse && _selectedCourse != null)
            {
                lblCourse.Text = $"Course: {_selectedCourse.Name} ({_selectedCourse.Code})";
            }
            else if (_selectedCourse == null) { Debug.WriteLine($"Warning: _selectedCourse is null in DisplayCourseAndTermInfo."); }
            else { Debug.WriteLine($"Warning: Label control '{CourseSubjectLabelName}' not found for course display."); }

            // Academic Period Label (e.g., lblAcademicPeriod)
            Control acadPeriodLabelCtrl = FindControlRecursive(this, AcademicPeriodLabelName);
            if (acadPeriodLabelCtrl is Label lblAcadPeriod && _selectedCourse != null)
            {
                // Assuming CourseDetails has Semester and SchoolYear properties
                // If not, you'll need to add them to your CourseDetails class
                // string semester = _selectedCourse.GetType().GetProperty("Semester")?.GetValue(_selectedCourse, null)?.ToString() ?? "N/A";
                // string schoolYear = _selectedCourse.GetType().GetProperty("SchoolYear")?.GetValue(_selectedCourse, null)?.ToString() ?? "N/A";
                // lblAcadPeriod.Text = $"Academic Period: {semester} ({schoolYear})";
                lblAcadPeriod.Text = $"Academic Period ID: {_selectedCourse.AcademicPeriodId}"; // Fallback if Semester/SchoolYear not directly available
            }
            else if (_selectedCourse == null) { Debug.WriteLine($"Warning: _selectedCourse is null, cannot display Academic Period."); }
            else { Debug.WriteLine($"Warning: Label control '{AcademicPeriodLabelName}' not found for Academic Period display."); }
        }

        private void LoadAndDisplayCSGrade()
        {
            TextBox txtCSGradeDisplay = FindControlRecursive(this, PrelimCSGradeDisplayTextBoxName) as TextBox;
            Control submitButton = FindControlRecursive(this, SubmitButtonName);

            if (txtCSGradeDisplay == null)
            {
                MessageBox.Show($"Configuration Error: TextBox '{PrelimCSGradeDisplayTextBoxName}' to display Class Standing grade not found. Please check the form design.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (submitButton != null) submitButton.Enabled = false;
                return;
            }
            txtCSGradeDisplay.ReadOnly = true;

            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0)
            {
                MessageBox.Show("Cannot load Class Standing grade. Invalid or missing course information (AcademicPeriodId).", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCSGradeDisplay.Text = "Error";
                if (submitButton != null) submitButton.Enabled = false;
                return;
            }

            bool success = false;
            _totalClassStandingRawFromDB = 0m;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT TotalClassStandingRaw FROM dbo.TermGrades WHERE CourseID = @AcademicPeriodId AND TermName = @TermName";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                    cmd.Parameters.AddWithValue("@TermName", _gradingTerm);

                    try
                    {
                        con.Open();
                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            _totalClassStandingRawFromDB = Convert.ToDecimal(result);
                            success = true;
                            Debug.WriteLine($"Successfully fetched TotalClassStandingRaw: {_totalClassStandingRawFromDB:F2}% for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}, Term: {_gradingTerm}");
                        }
                        else
                        {
                            Debug.WriteLine($"No TotalClassStandingRaw found (or it was NULL) in TermGrades for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}, Term: {_gradingTerm}. Assuming 0% for calculation.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching Prelim Class Standing grade from database: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtCSGradeDisplay.Text = "DB Error";
                        if (submitButton != null) submitButton.Enabled = false;
                        Debug.WriteLine($"Database error in LoadAndDisplayCSGrade: {ex.ToString()}");
                        return;
                    }
                }
            }

            if (success)
            {
                txtCSGradeDisplay.Text = _totalClassStandingRawFromDB.ToString("F2") + "%";
            }
            else
            {
                txtCSGradeDisplay.Text = "N/A";
                MessageBox.Show("Could not find previously saved Prelim Class Standing data for this course and term. Please ensure Class Standing was submitted. For calculation purposes, Class Standing will be assumed as 0%.", "Data Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (submitButton != null) submitButton.Enabled = true;
        }

        private void txtPCSG_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtPEG_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0)
            {
                MessageBox.Show("Course information is missing or invalid (AcademicPeriodId). Cannot perform calculation.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (_gradingTerm != "Prelim")
            {
                MessageBox.Show("This calculation logic is specifically for the Prelim term.", "Term Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            TextBox txtDesiredGrade = FindControlRecursive(this, DesiredGradeInputTextBoxName) as TextBox;
            if (txtDesiredGrade == null)
            {
                MessageBox.Show($"Configuration Error: TextBox '{DesiredGradeInputTextBoxName}' for desired grade input not found.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(txtDesiredGrade.Text, out decimal desiredFinalPrelimGrade) || desiredFinalPrelimGrade < 0 || desiredFinalPrelimGrade > 100)
            {
                MessageBox.Show("Please enter a valid Desired Final Prelim Grade (numeric value between 0 and 100).", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDesiredGrade.Focus();
                txtDesiredGrade.SelectAll();
                return;
            }

            decimal requiredPrelimExamScore = (2 * desiredFinalPrelimGrade) - _totalClassStandingRawFromDB;

            StringBuilder resultMessage = new StringBuilder();
            resultMessage.AppendLine($"--- Prelim Grade Target Calculation ---");
            resultMessage.AppendLine($"Course: {_selectedCourse.Code} - {_selectedCourse.Name}");
            resultMessage.AppendLine($"Term: {_gradingTerm}");
            resultMessage.AppendLine($"Your Current Prelim Class Standing (Raw %): {_totalClassStandingRawFromDB:F2}%");
            resultMessage.AppendLine($"Desired Final Prelim Grade: {desiredFinalPrelimGrade:F2}%");
            resultMessage.AppendLine("-------------------------------------------");

            if (requiredPrelimExamScore < 0)
            {
                decimal gradeWithZeroExam = 0.5m * _totalClassStandingRawFromDB;
                resultMessage.AppendLine($"To achieve {desiredFinalPrelimGrade:F2}%, the calculation suggests a required exam score of {requiredPrelimExamScore:F2}%.");
                resultMessage.AppendLine("This is impossible as an exam score cannot be negative.");
                resultMessage.AppendLine($"Even with 0% on the exam, your Prelim Grade would be approximately: {gradeWithZeroExam:F2}%.");
                if (desiredFinalPrelimGrade <= gradeWithZeroExam && desiredFinalPrelimGrade >= 0)
                {
                    resultMessage.AppendLine($"Your desired grade of {desiredFinalPrelimGrade:F2}% is achievable even if your exam score is 0% or slightly above.");
                }
            }
            else if (requiredPrelimExamScore > 100)
            {
                resultMessage.AppendLine($"To achieve {desiredFinalPrelimGrade:F2}%, the calculation suggests a required exam score of {requiredPrelimExamScore:F2}%.");
                resultMessage.AppendLine("This is impossible as an exam score cannot exceed 100%.");
                decimal maxPossibleGrade = (0.5m * _totalClassStandingRawFromDB) + (0.5m * 100.0m);
                resultMessage.AppendLine($"With 100% on the exam, your maximum possible Prelim Grade is approximately: {maxPossibleGrade:F2}%.");
            }
            else
            {
                resultMessage.AppendLine($"To achieve a Final Prelim Grade of {desiredFinalPrelimGrade:F2}%,");
                resultMessage.AppendLine($"you need a Prelim Exam Score of approximately: {requiredPrelimExamScore:F2}%");
            }
            MessageBox.Show(resultMessage.ToString(), "Prelim Grade Requirement Calculation", MessageBoxButtons.OK, MessageBoxIcon.Information);

            DialogResult proceedToMidterm = MessageBox.Show("Calculation displayed. Do you want to proceed to Midterm grading for this course now?",
                                                             "Proceed to Midterm?",
                                                             MessageBoxButtons.YesNo,
                                                             MessageBoxIcon.Question);

            if (proceedToMidterm == DialogResult.Yes)
            {
                // The 'originalSelectCourseForm' to pass to classStandingmidterm.
                // This should be the actual 'Select Course' form instance.
                // Your original code had complex logic to retrieve this.
                // For the fix, we need a reliable way to get this.
                // Assuming _selectCourseForm (set in constructor or otherwise available) holds the correct reference.
                // If _selectCourseForm was not properly initialized from _callingForm, _dashboardForm is a fallback.
                Form formToPassAsSelectCourse = _selectCourseForm ?? _dashboardForm;

                if (formToPassAsSelectCourse == null)
                {
                    MessageBox.Show("Critical Error: Cannot determine the correct 'Select Course' context to proceed to Midterm. Dashboard reference is also missing.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }


                try
                {
                    Debug.WriteLine("Navigating to classStandingmidterm form.");
                    // ** THIS IS THE CORRECTED CALL **
                    // classStandingmidterm now takes 3 arguments: CourseDetails, selectCourseForm, dashboardForm
                    classStandingmidterm midtermCSForm = new classStandingmidterm(
                        _selectedCourse,
                        formToPassAsSelectCourse, // Pass the determined Select Course form reference
                        _dashboardForm            // Pass the dashboard form reference
                    );
                    midtermCSForm.Show();
                    this.Hide();
                    // _callingForm?.Close(); // Optional: Close the form that opened this one
                    // this.Close(); // Optional: Close this form if its role is fully complete
                }
                catch (Exception navEx)
                {
                    MessageBox.Show("Error navigating to Midterm Class Standing form: " + navEx.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debug.WriteLine($"Error opening classStandingmidterm: {navEx.ToString()}");
                    this.Show();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TextBox desiredGradeInput = FindControlRecursive(this, DesiredGradeInputTextBoxName) as TextBox;
            desiredGradeInput?.Clear();
            desiredGradeInput?.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            _callingForm?.Show();
            this.Close();
        }

        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }

        private void txtQuiz_TextChanged(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExamprelim ({_gradingTerm}): txtPCSG (Prelim CS Grade) text changed. Current value: {((TextBox)sender).Text}");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExamprelim ({_gradingTerm}): txtPEG (Desired Prelim Grade) text changed. Current value: {((TextBox)sender).Text}");
        }
        private void label4_Click(object sender, EventArgs e) { }
    }
}
