﻿// firstpartcourse.cs
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace login
{
    public partial class firstpartcourse : Form
    {
        private Form dashboardFormInstance;
        private string currentStudentID; // Assuming studentID is passed to this form

        private string collectedSchoolYear;
        private string collectedSemester;
        private int collectedTotalCourses;
        private int generatedAcademicPeriodId; // ID generated when saving AcademicPeriod

        // MODIFIED: Using the connection string you provided
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // --- Constructors ---

        // Constructor updated to accept studentID and dashboard reference
        public firstpartcourse(string studentID, Form dashboard)
        {
            InitializeComponent();
            this.currentStudentID = studentID; // Store the passed studentID
            this.dashboardFormInstance = dashboard; // Store the dashboard reference
            this.Load += Firstpartcourse_Load;
        }

        // Parameterless constructor (for designer)
        public firstpartcourse()
        {
            InitializeComponent();
            this.Load += Firstpartcourse_Load;
            // Add Load event handler for parameterless context if needed
            this.Load += (s, e) => HandleParameterlessConstructorContext();
        }

        private void HandleParameterlessConstructorContext()
        {
            // This checks if required parameters (studentID, dashboard) were NOT passed via a proper constructor
            if (dashboardFormInstance == null || string.IsNullOrEmpty(currentStudentID))
            {
                Debug.WriteLine("Warning: firstpartcourse form initialized without dashboard reference or studentID.");
                MessageBox.Show("Application was not started correctly. Missing student or dashboard info.", "Startup Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Optionally disable controls or close the form if it's in an invalid state
                EnableFormControls(false); // Example: Disable input/buttons
            }
        }

        // Helper to enable/disable controls (assuming button1 is Submit, button2 is Clear)
        private void EnableFormControls(bool enable)
        {
            Control[] foundBtn1 = this.Controls.Find("button1", true);
            if (foundBtn1.Length > 0 && foundBtn1[0] is Button btn1) btn1.Enabled = enable;
            Control[] foundBtn2 = this.Controls.Find("button2", true);
            if (foundBtn2.Length > 0 && foundBtn2[0] is Button btn2) btn2.Enabled = enable;
            // Add other controls like textboxes, comboboxes, numericupdown if needed
        }

        // Helper to find controls recursively (from your code)
        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }


        private void Firstpartcourse_Load(object sender, EventArgs e)
        {
            HandleParameterlessConstructorContext(); // Perform checks on load

            // Assumed control names: "comboBox1" (SchoolYear), "comboBox2" (Semester),
            // "numericUpDownNumCourses" or "textBox1" (NumCourses) - Check your designer file.

            if (FindControlRecursive(this, "comboBox1") is ComboBox cbSchoolYear)
            {
                cbSchoolYear.Items.Clear();
                cbSchoolYear.Items.Add("2023-2024");
                cbSchoolYear.Items.Add("2024-2025");
                cbSchoolYear.Items.Add("2025-2026");
                // Optional: set default selected index if needed
                // cbSchoolYear.SelectedIndex = 0;
            }
            else { Debug.WriteLine("Warning: Control 'comboBox1' for School Year not found."); }

            if (FindControlRecursive(this, "comboBox2") is ComboBox cbSemester)
            {
                cbSemester.Items.Clear();
                cbSemester.Items.Add("1st Semester");
                cbSemester.Items.Add("2nd Semester");
                cbSemester.Items.Add("Summer");
                // Optional: set default selected index if needed
                // cbSemester.SelectedIndex = 0;
            }
            else { Debug.WriteLine("Warning: Control 'comboBox2' for Semester not found."); }

            Control numCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBox1");
            if (numCoursesControl is NumericUpDown numCourses)
            {
                numCourses.Minimum = 1;
                numCourses.Maximum = 10; // Adjust max if you have more forms
                numCourses.Value = 1;
            }
            else if (numCoursesControl is TextBox txtNumCourses)
            {
                txtNumCourses.Text = "1";
            }
            else { Debug.WriteLine("Warning: Control for Number of Courses ('numericUpDownNumCourses' or 'textBox1') not found."); }


            // Set initial focus
            Control initialFocusControl = FindControlRecursive(this, "comboBox1") ?? FindControlRecursive(this, "textBoxSchoolYear");
            if (initialFocusControl != null)
            {
                initialFocusControl.Focus();
            }
        }

        // submit button (button1) click handler
        private void button1_Click(object sender, EventArgs e)
        {
            string schoolYearInput = "";
            string semesterInput = "";
            int numberOfCoursesInput = 0;

            // Get input from UI controls (using your FindControlRecursive or direct naming)
            // Assuming comboBox1 for SchoolYear, comboBox2 for Semester, numericUpDownNumCourses for Number of Courses
            // You might need to adjust control names if they are different (e.g., from the FindControlRecursive examples)

            Control syControl = FindControlRecursive(this, "comboBox1"); // Or your actual School Year control name
            if (syControl is ComboBox cbSchoolYear && cbSchoolYear.SelectedItem != null)
            {
                schoolYearInput = cbSchoolYear.SelectedItem.ToString();
            }
            else if (syControl is TextBox txtSchoolYear) // If you use TextBox instead
            {
                schoolYearInput = txtSchoolYear.Text.Trim();
            }
            else
            {
                MessageBox.Show("Please select a School Year.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                syControl?.Focus();
                return;
            }

            Control semControl = FindControlRecursive(this, "comboBox2"); // Or your actual Semester control name
            if (semControl is ComboBox cbSemester && cbSemester.SelectedItem != null)
            {
                semesterInput = cbSemester.SelectedItem.ToString();
            }
            else if (semControl is TextBox txtSemester) // If you use TextBox instead
            {
                semesterInput = txtSemester.Text.Trim();
            }
            else
            {
                MessageBox.Show("Please select a Semester.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                semControl?.Focus();
                return;
            }

            // Get Number of Courses (this will be used IF it's a NEW academic period)
            Control numCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBox1");
            if (numCoursesControl is NumericUpDown numCourses)
            {
                numberOfCoursesInput = (int)numCourses.Value;
            }
            else if (numCoursesControl is TextBox txtNumCourses)
            {
                if (!int.TryParse(txtNumCourses.Text.Trim(), out numberOfCoursesInput))
                {
                    MessageBox.Show("Please enter a valid number for Courses.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNumCourses.Focus(); return;
                }
            }
            else
            {
                MessageBox.Show("Number of Courses control not found.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate StudentID and Dashboard reference
            if (string.IsNullOrWhiteSpace(this.currentStudentID))
            {
                MessageBox.Show("Student information is missing. Cannot proceed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!int.TryParse(this.currentStudentID, out int studentIdInt))
            {
                MessageBox.Show("Invalid Student ID format. Expected an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (dashboardFormInstance == null)
            {
                MessageBox.Show("Dashboard reference missing. Cannot proceed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // --- NEW LOGIC: Check for existing Academic Period ---
            int existingAcademicPeriodId = 0;
            int existingNumberOfCourses = 0;
            bool academicPeriodFound = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string checkQuery = @"
            SELECT AcademicPeriodID, NumberOfCourses
            FROM dbo.AcademicPeriods
            WHERE studentID = @StudentID
              AND SchoolYear = @SchoolYear
              AND Semester = @Semester;";

                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@StudentID", studentIdInt);
                    checkCmd.Parameters.AddWithValue("@SchoolYear", schoolYearInput);
                    checkCmd.Parameters.AddWithValue("@Semester", semesterInput);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = checkCmd.ExecuteReader())
                        {
                            if (reader.Read()) // If a record is found
                            {
                                academicPeriodFound = true;
                                existingAcademicPeriodId = reader.GetInt32(0); // AcademicPeriodID
                                existingNumberOfCourses = reader.GetInt32(1); // NumberOfCourses
                            }
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Debug.WriteLine($"SQL Error checking for existing Academic Period: {sqlEx.Message}");
                        MessageBox.Show("Database error while checking for existing academic period: " + sqlEx.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"General Error checking for existing Academic Period: {ex.Message}");
                        MessageBox.Show("An error occurred while checking for existing academic period: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                } // SqlCommand disposed here
            } // SqlConnection disposed here


            // --- Conditional Logic based on whether the Academic Period was found ---
            if (academicPeriodFound)
            {
                // --- SCENARIO 1: Academic Period ALREADY EXISTS ---
                MessageBox.Show($"An academic period for {schoolYearInput} - {semesterInput} already exists with {existingNumberOfCourses} course(s) registered.\n" +
                                $"You will now be taken to manage or view these courses.",
                                "Existing Academic Period", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Decision: What to do with numberOfCoursesInput from the UI if it's different from existingNumberOfCourses?
                // Option 1.A: Update if different and if allowed.
                if (numberOfCoursesInput != existingNumberOfCourses)
                {
                    // Optional: Ask user if they want to update the total number of courses
                    DialogResult dr = MessageBox.Show($"The existing period has {existingNumberOfCourses} courses. You entered {numberOfCoursesInput}. Do you want to update the total number of courses for this period to {numberOfCoursesInput}?",
                                                        "Update Course Count?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        using (SqlConnection updateConnection = new SqlConnection(connectionString))
                        {
                            string updateQuery = "UPDATE dbo.AcademicPeriods SET NumberOfCourses = @NewNumberOfCourses WHERE AcademicPeriodID = @AcademicPeriodID";
                            using (SqlCommand updateCmd = new SqlCommand(updateQuery, updateConnection))
                            {
                                updateCmd.Parameters.AddWithValue("@NewNumberOfCourses", numberOfCoursesInput);
                                updateCmd.Parameters.AddWithValue("@AcademicPeriodID", existingAcademicPeriodId);
                                try
                                {
                                    updateConnection.Open();
                                    updateCmd.ExecuteNonQuery();
                                    Debug.WriteLine($"Updated NumberOfCourses for AcademicPeriodID {existingAcademicPeriodId} to {numberOfCoursesInput}.");
                                    existingNumberOfCourses = numberOfCoursesInput; // Update local variable for consistency
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Failed to update the number of courses: " + ex.Message, "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    // Decide if you want to proceed or return
                                }
                            }
                        }
                    }
                    // If user says No, we proceed with existingNumberOfCourses for any further logic (though selectcourse doesn't directly use it)
                }


                // Navigate to selectcourse.cs to display/manage existing courses
                // First, fetch the courses for this existingAcademicPeriodId
                List<CourseDetails> coursesForPeriod = new List<CourseDetails>();
                using (SqlConnection courseConnection = new SqlConnection(connectionString))
                {
                    // Assuming your Courses table matches the fields in CourseDetails
                    // and includes AcademicPeriodID, CourseCode, CourseName, Units, SchoolYear, Semester, CourseNumber
                    string fetchCoursesQuery = @"
                SELECT CourseCode, CourseName, Units, SchoolYear, Semester, CourseNumber, AcademicPeriodID
                FROM dbo.Courses
                WHERE AcademicPeriodID = @AcademicPeriodID
                ORDER BY CourseNumber;";
                    using (SqlCommand fetchCmd = new SqlCommand(fetchCoursesQuery, courseConnection))
                    {
                        fetchCmd.Parameters.AddWithValue("@AcademicPeriodID", existingAcademicPeriodId);
                        try
                        {
                            courseConnection.Open();
                            using (SqlDataReader courseReader = fetchCmd.ExecuteReader())
                            {
                                while (courseReader.Read())
                                {
                                    coursesForPeriod.Add(new CourseDetails
                                    {
                                        Code = courseReader["CourseCode"].ToString(),
                                        Name = courseReader["CourseName"].ToString(),
                                        Units = Convert.ToInt32(courseReader["Units"]), // Or Decimal if your Units are decimal
                                        SchoolYear = courseReader["SchoolYear"].ToString(),
                                        Semester = courseReader["Semester"].ToString(),
                                        CourseNumber = Convert.ToInt32(courseReader["CourseNumber"]),
                                        AcademicPeriodId = Convert.ToInt32(courseReader["AcademicPeriodID"])
                                    });
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Failed to load existing courses for this period: " + ex.Message, "Error Loading Courses", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return; // Or handle differently
                        }
                    }
                }

                // Navigate to selectcourse form, passing the loaded courses and a default/relevant term
                // For now, let's assume we default to "Prelim" or allow selectcourse to handle term selection if needed
                // OR, if your selectterm was supposed to be used only for NEW entries, the logic to select a term for existing courses might be different.
                // For now, this matches the constructor selectcourse(List<CourseDetails> courses, string term, Form dashboard)
                // We need a 'term' to pass. If courses exist, maybe query distinct terms? Or default.
                // Let's default to "Prelim" for now if showing existing. Or maybe an empty string if selectcourse handles it.
                string termToPass = "Prelim"; // Placeholder - you might want a more sophisticated way to pick this
                if (coursesForPeriod.Count > 0)
                {
                    // Potentially get the term from the first loaded course if consistent, or a default
                    // termToPass = coursesForPeriod[0].Term; // If CourseDetails had a Term property from dbo.Courses
                }


                selectcourse scForm = new selectcourse(coursesForPeriod, termToPass, this.dashboardFormInstance);
                scForm.Show();
                this.Hide();
            }
            else
            {
                // --- SCENARIO 2: Academic Period is NEW ---
                // Validate Number of Courses for new entry
                if (numberOfCoursesInput < 1 || numberOfCoursesInput > 10) // Max 10 due to course_op0-9 forms
                {
                    MessageBox.Show("Number of courses must be between 1 and 10.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    numCoursesControl?.Focus();
                    return;
                }

                // Proceed with saving the new Academic Period (original logic from your firstpartcourse.cs)
                int newGeneratedAcademicPeriodId = 0;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string insertAcademicPeriodQuery = @"
                INSERT INTO dbo.AcademicPeriods (studentID, SchoolYear, Semester, NumberOfCourses)
                VALUES (@StudentID, @SchoolYear, @Semester, @NumberOfCourses);
                SELECT SCOPE_IDENTITY();";

                    using (SqlCommand command = new SqlCommand(insertAcademicPeriodQuery, connection))
                    {
                        command.Parameters.AddWithValue("@StudentID", studentIdInt);
                        command.Parameters.AddWithValue("@SchoolYear", schoolYearInput);
                        command.Parameters.AddWithValue("@Semester", semesterInput);
                        command.Parameters.AddWithValue("@NumberOfCourses", numberOfCoursesInput);

                        try
                        {
                            connection.Open();
                            object result = command.ExecuteScalar();
                            if (result != null && int.TryParse(result.ToString(), out newGeneratedAcademicPeriodId))
                            {
                                Debug.WriteLine($"New Academic Period saved. ID: {newGeneratedAcademicPeriodId}");
                                // Store collected data in fields if needed by StartCourseEntrySequence directly
                                this.collectedSchoolYear = schoolYearInput;
                                this.collectedSemester = semesterInput;
                                this.collectedTotalCourses = numberOfCoursesInput;
                                this.generatedAcademicPeriodId = newGeneratedAcademicPeriodId; // Store the new ID

                                StartCourseEntrySequence(); // This method should use this.generatedAcademicPeriodId etc.
                            }
                            else
                            {
                                MessageBox.Show("Failed to retrieve Academic Period ID after saving.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (SqlException sqlEx)
                        {
                            // The UNIQUE constraint UQ_Student_SchoolYear_Semester should prevent this if implemented correctly,
                            // but good to have a catch block.
                            if (sqlEx.Number == 2627) // Unique key violation
                            {
                                MessageBox.Show("This academic period (School Year and Semester) already exists for this student. Please check your input or use the existing period.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                Debug.WriteLine($"SQL Error saving new Academic Period: {sqlEx.Message}");
                                MessageBox.Show("Database error saving new Academic Period: " + sqlEx.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"General Error saving new Academic Period: {ex.Message}");
                            MessageBox.Show("An unexpected error occurred while saving the new academic period: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
        // --- CORRECTED: Method to start the course entry sequence (always starts with course_op) ---
        private void StartCourseEntrySequence()
        {
            // Ensure we have the necessary info to start
            if (string.IsNullOrWhiteSpace(this.collectedSchoolYear) || string.IsNullOrWhiteSpace(this.collectedSemester) || this.collectedTotalCourses < 1 || this.generatedAcademicPeriodId == 0 || this.dashboardFormInstance == null)
            {
                MessageBox.Show("Missing academic period details. Cannot start course entry.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Always start with the form for the first course (course_op)
            Form firstCourseForm = null;
            int firstCourseNumber = 1; // Always start collecting data from Course 1
            List<CourseDetails> collectedCourses = new List<CourseDetails>(); // Start with a new empty list

            try
            {
                // Instantiate the first course entry form (course_op)
                // Pass all necessary data, including the generated AcademicPeriodId
                firstCourseForm = new course_op(
                    this.collectedSchoolYear,
                    this.collectedSemester,
                    this.collectedTotalCourses, // Total courses for the entire period
                    firstCourseNumber,         // The current course number (1)
                    this,                      // Pass THIS form (firstpartcourse) as the previous form
                    this.dashboardFormInstance,
                    collectedCourses,          // Pass the NEWLY CREATED EMPTY LIST
                    this.generatedAcademicPeriodId // Pass the generated Academic Period ID
                );

                if (firstCourseForm != null)
                {
                    firstCourseForm.Show(); // Show the form for the first course
                    this.Hide();           // Hide the current form (firstpartcourse)
                }
                else
                {
                    MessageBox.Show("Failed to create the first course entry form.", "Error");
                }
            }
            catch (MissingMethodException mmEx)
            {
                // This catch block helps diagnose if course_op's constructor is missing or incorrect.
                MessageBox.Show($"Configuration Error: The 'course_op' form does not have the required constructor.\nPlease ensure course_op.cs has the public constructor: public course_op(string, string, int, int, Form, Form, List<CourseDetails>, int).\nDetails: {mmEx.Message}", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"MissingMethodException: {mmEx.Message}\n{mmEx.StackTrace}");
                this.Show(); // Stay on current form if navigation failed
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error starting course entry sequence: " + ex.Message, "Error");
                Debug.WriteLine($"General Error starting sequence: {ex.Message}\n{ex.StackTrace}");
                this.Show(); // Stay on current form if navigation failed
            }
        }


        // clear button (button2) click handler
        private void button2_Click(object sender, EventArgs e)
        {
            // Clear input fields
            if (FindControlRecursive(this, "comboBox1") is ComboBox cbSchoolYear) cbSchoolYear.SelectedIndex = -1;
            if (FindControlRecursive(this, "textBoxSchoolYear") is TextBox txtSchoolYear) txtSchoolYear.Clear();
            if (FindControlRecursive(this, "comboBox2") is ComboBox cbSemester) cbSemester.SelectedIndex = -1;
            if (FindControlRecursive(this, "textBoxSemester") is TextBox txtSemester) txtSemester.Clear();
            Control numCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBox1");
            if (numCoursesControl is NumericUpDown numCourses) numCourses.Value = numCourses.Minimum > 0 ? numCourses.Minimum : 1;
            if (numCoursesControl is TextBox txtNumCourses) txtNumCourses.Text = "1";
            // Set focus back to the first input control
            Control initialFocusControl = FindControlRecursive(this, "comboBox1") ?? FindControlRecursive(this, "textBoxSchoolYear");
            if (initialFocusControl != null)
            {
                initialFocusControl.Focus();
            }
        }

        // back button (button3) click handler
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (dashboardFormInstance != null)
            {
                dashboardFormInstance.Show(); // Navigate back to the Dashboard
            }
            else
            {
                // Fallback if dashboard reference is lost
                MessageBox.Show("Returning to Login.", "Navigation");
                frmLogin loginForm = new frmLogin(); // Assuming frmLogin is your login form
                loginForm.Show();
                this.Close(); // Close the current form
            }
        }

        private void firstpartcourse_Load_1(object sender, EventArgs e)
        {

        }

        // If you have other event handlers defined in your designer, make sure they are here.
        // Example: private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { ... }
        // Example: private void textBox1_TextChanged(object sender, EventArgs e) { ... }
        // Remove any duplicate or unused event handlers.
    }
}