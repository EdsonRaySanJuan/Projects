﻿// classExammidterm.cs
// MODIFIED to:
// - Load Midterm Class Standing (TotalClassStandingRaw) from DB.
// - Display fetched CS in a read-only TextBox named txtCLSR.
// - Accept Actual Midterm Exam Score via textBox1.
// - Calculate final Midterm Grade.
// - Save Actual Midterm Exam Score and Calculated Midterm Grade to DB.
// - Navigate to classStandingfinals on successful submission.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // For SQL Server interaction
using System.Diagnostics;     // For Debug.WriteLine

namespace login
{
    public partial class classExammidterm : Form
    {
        // Made _selectedCourse nullable to allow for the parameterless constructor
        private CourseDetails? _selectedCourse;
        private string _currentGradingTerm; // Will be "Midterm"
        private Form? _selectCourseFormRef; // Made nullable
        private Form? _dashboardFormRef; // Made nullable

        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";
        private decimal _midtermClassStandingRawFromDB = 0m; // Stores fetched raw Midterm CS

        // Constants for control names to ensure consistency
        private const string MidtermCSDisplayTextBoxName = "txtCLSR";      // For displaying fetched Midterm CS (ReadOnly)
        private const string ActualExamScoreInputTextBoxName = "textBox1"; // For user to input Actual Midterm Exam Score
        private const string CourseSubjectLabelName = "label4";
        private const string TermInfoLabelName = "label1";
        private const string SubmitButtonName = "button1";
        private const string ClearButtonName = "button2";
        // No back button specified for this form in mt cs.txt, so not adding one.

        public classExammidterm()
        {
            InitializeComponent();
            Debug.WriteLine("classExammidterm: Parameterless constructor called.");

            // Initialize nullable fields in the parameterless constructor
            _selectedCourse = null;
            _currentGradingTerm = "Midterm"; // Default or placeholder term
            _selectCourseFormRef = null;
            _dashboardFormRef = null;

            // Default display or disable functionality if no course is loaded
            // Use _currentGradingTerm which is now initialized
            UpdateExamFormDisplay(_selectedCourse, _currentGradingTerm);

            Control submitButton = FindControlRecursive(this, SubmitButtonName);
            if (submitButton != null) submitButton.Enabled = false;
            Control actualExamScoreInput = FindControlRecursive(this, ActualExamScoreInputTextBoxName);
            if (actualExamScoreInput != null) actualExamScoreInput.Enabled = false;
            Control csDisplay = FindControlRecursive(this, MidtermCSDisplayTextBoxName);
            if (csDisplay is TextBox txtCs) { txtCs.Text = "Error"; txtCs.ReadOnly = true; }
        }

        public classExammidterm(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboardForm)
        {
            InitializeComponent();
            _selectedCourse = course;
            _currentGradingTerm = gradingTerm; // Should receive "Midterm"
            _selectCourseFormRef = selectCourseForm;
            _dashboardFormRef = dashboardForm;

            Debug.WriteLine($"classExammidterm: Constructor called. Course: {course?.Code}, Term: {gradingTerm}");
            this.Load += classExammidterm_Load; // Attach load event handler
        }

        private void classExammidterm_Load(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExammidterm: Form loaded for {_currentGradingTerm}.");
            // Check if _selectedCourse is not null before accessing its properties
            if (_selectedCourse != null && _selectedCourse.AcademicPeriodId > 0 && _currentGradingTerm == "Midterm")
            {
                UpdateExamFormDisplay(_selectedCourse, _currentGradingTerm);
                LoadAndDisplayMidtermCS(); // Fetch and display Midterm CS

                TextBox actualExamScoreInput = FindControlRecursive(this, ActualExamScoreInputTextBoxName) as TextBox;
                actualExamScoreInput?.Focus();
            }
            else
            {
                string errorMessage = "Critical error: Course details are missing, invalid (AcademicPeriodId is 0 or less), or term is not 'Midterm' upon loading the Midterm Exam form.";
                if (_currentGradingTerm != "Midterm") errorMessage += $" Expected 'Midterm', got '{_currentGradingTerm}'.";
                MessageBox.Show(this, errorMessage, "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                // Add null check for _selectedCourse before accessing properties in Debug.WriteLine
                Debug.WriteLine($"classExammidterm Error: {errorMessage}. Course: {_selectedCourse?.Code ?? "N/A"}, AcadPeriodId: {_selectedCourse?.AcademicPeriodId ?? 0}, Term: {_currentGradingTerm}");

                Control submitButton = FindControlRecursive(this, SubmitButtonName);
                if (submitButton != null) submitButton.Enabled = false;
                Control csDisplay = FindControlRecursive(this, MidtermCSDisplayTextBoxName);
                if (csDisplay is TextBox txtCs) { txtCs.Text = "Data Error"; txtCs.ReadOnly = true; }
                Control actualExamInput = FindControlRecursive(this, ActualExamScoreInputTextBoxName);
                if (actualExamInput != null) actualExamInput.Enabled = false;
            }
        }

        private void UpdateExamFormDisplay(CourseDetails? course, string term) // Made course nullable
        {
            string formTitle;
            string courseSubjectText = "Course Subject: N/A";
            string termDisplayText = $"Term: {term ?? "N/A"}";

            if (course != null)
            {
                formTitle = $"{term} Exam - {course.Name}";
                courseSubjectText = $"Course Subject: {course.Name} ({course.Code})";
            }
            else
            {
                formTitle = $"{term ?? "Exam"} Exam";
            }

            this.Text = formTitle;

            Control courseLabelCtrl = FindControlRecursive(this, CourseSubjectLabelName);
            if (courseLabelCtrl is Label lblCourse) { lblCourse.Text = courseSubjectText; }
            else { Debug.WriteLine($"classExammidterm Warning: Label control '{CourseSubjectLabelName}' not found."); }

            Control termLabelCtrl = FindControlRecursive(this, TermInfoLabelName);
            if (termLabelCtrl is Label lblTerm) { lblTerm.Text = termDisplayText; }
            else { Debug.WriteLine($"classExammidterm Warning: Label control '{TermInfoLabelName}' not found."); }
        }

        private void LoadAndDisplayMidtermCS()
        {
            TextBox txtCSDisplay = FindControlRecursive(this, MidtermCSDisplayTextBoxName) as TextBox;
            Control submitButton = FindControlRecursive(this, SubmitButtonName);

            if (txtCSDisplay == null)
            {
                MessageBox.Show(this, $"Configuration Error: TextBox '{MidtermCSDisplayTextBoxName}' to display Midterm Class Standing not found. Please check the form design.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (submitButton != null) submitButton.Enabled = false;
                return;
            }
            txtCSDisplay.ReadOnly = true; // Ensure user cannot edit this fetched value

            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0) // Should have been caught in Load event
            {
                MessageBox.Show(this, "Cannot load Midterm Class Standing. Invalid or missing course information.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCSDisplay.Text = "Error";
                if (submitButton != null) submitButton.Enabled = false;
                return;
            }

            bool success = false;
            _midtermClassStandingRawFromDB = 0m; // Reset before fetching

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Query to get TotalClassStandingRaw for Midterm.
                string query = "SELECT TotalClassStandingRaw FROM dbo.TermGrades WHERE CourseID = @AcademicPeriodId AND TermName = @TermName";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                    cmd.Parameters.AddWithValue("@TermName", _currentGradingTerm); // This should be "Midterm"

                    try
                    {
                        con.Open();
                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            _midtermClassStandingRawFromDB = Convert.ToDecimal(result);
                            success = true;
                            Debug.WriteLine($"Successfully fetched Midterm TotalClassStandingRaw: {_midtermClassStandingRawFromDB:F2}% for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}");
                        }
                        else
                        {
                            Debug.WriteLine($"No Midterm TotalClassStandingRaw found for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}. Assuming 0%.");
                            // success remains false, _midtermClassStandingRawFromDB remains 0m
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error fetching Midterm Class Standing from database: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtCSDisplay.Text = "DB Error";
                        if (submitButton != null) submitButton.Enabled = false;
                        Debug.WriteLine($"Database error in LoadAndDisplayMidtermCS: {ex.ToString()}");
                        return; // Critical error
                    }
                }
            }

            if (success)
            {
                txtCSDisplay.Text = _midtermClassStandingRawFromDB.ToString("F2") + "%";
            }
            else
            {
                txtCSDisplay.Text = "N/A"; // Or "0.00%"
                MessageBox.Show(this, "Could not find previously saved Midterm Class Standing data for this course. Please ensure Midterm Class Standing was submitted. For calculation purposes, Class Standing will be assumed as 0%.", "Data Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (submitButton != null) submitButton.Enabled = true; // Enable submit even if CS is 0 or N/A
        }

        // TextChanged event for the TextBox where "Actual Midterm Exam Score" is entered (textBox1)
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExammidterm: Actual Midterm Exam Score TextBox ('{ActualExamScoreInputTextBoxName}') changed.");
            // Add any real-time processing or validation logic here if needed
        }

        // Submit button (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExammidterm: Submit button clicked for {_currentGradingTerm} Exam.");
            if (_selectedCourse == null || _selectedCourse.AcademicPeriodId <= 0)
            {
                MessageBox.Show(this, "Cannot submit Midterm exam data. Course information is missing or invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (_currentGradingTerm != "Midterm")
            {
                MessageBox.Show(this, "This form is for Midterm exam data submission only.", "Term Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            TextBox txtActualExamScore = FindControlRecursive(this, ActualExamScoreInputTextBoxName) as TextBox;
            if (txtActualExamScore == null)
            {
                MessageBox.Show(this, $"Configuration Error: TextBox '{ActualExamScoreInputTextBoxName}' for Actual Midterm Exam Score input not found.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(txtActualExamScore.Text, out decimal actualMidtermExamScore) || actualMidtermExamScore < 0 || actualMidtermExamScore > 100)
            {
                MessageBox.Show(this, "Please enter a valid Actual Midterm Exam Score (numeric value between 0 and 100).", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtActualExamScore.Focus();
                txtActualExamScore.SelectAll();
                return;
            }

            // Calculate Final Midterm Grade
            // FinalMidtermGrade = (MidtermCS_Raw * 0.5) + (MidtermExamScore * 0.5)
            decimal calculatedMidtermGrade = (_midtermClassStandingRawFromDB * 0.5m) + (actualMidtermExamScore * 0.5m);

            bool saveSuccess = false;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"UPDATE dbo.TermGrades
                                 SET ExamScore = @ExamScore,
                                     CalculatedTermGrade = @CalculatedTermGrade
                                 WHERE CourseID = @AcademicPeriodId AND TermName = @TermName";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@ExamScore", actualMidtermExamScore);
                    cmd.Parameters.AddWithValue("@CalculatedTermGrade", calculatedMidtermGrade);
                    cmd.Parameters.AddWithValue("@AcademicPeriodId", _selectedCourse.AcademicPeriodId);
                    cmd.Parameters.AddWithValue("@TermName", _currentGradingTerm);

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            saveSuccess = true;
                            Debug.WriteLine($"Successfully saved Midterm Exam Score ({actualMidtermExamScore}%) and Calculated Midterm Grade ({calculatedMidtermGrade}%) for AcademicPeriodId: {_selectedCourse.AcademicPeriodId}");

                            // *** MODIFIED MessageBox FORMAT STARTS HERE ***
                            StringBuilder successMessage = new StringBuilder();
                            successMessage.AppendLine("--- Midterm Grade Submission Successful ---");
                            if (_selectedCourse != null)
                            {
                                successMessage.AppendLine($"Course: {_selectedCourse.Code} - {_selectedCourse.Name}");
                            }
                            successMessage.AppendLine($"Term: {_currentGradingTerm}");
                            successMessage.AppendLine("-------------------------------------------");
                            successMessage.AppendLine($"Midterm Class Standing (Fetched): {_midtermClassStandingRawFromDB:F2}%");
                            successMessage.AppendLine($"Actual Midterm Exam Score (Submitted): {actualMidtermExamScore:F2}%");
                            successMessage.AppendLine($"Calculated Final Midterm Grade: {calculatedMidtermGrade:F2}%");
                            successMessage.AppendLine("-------------------------------------------");
                            successMessage.AppendLine("\nData saved successfully.");
                            successMessage.AppendLine("Proceeding to Finals Class Standing entry.");

                            MessageBox.Show(this, successMessage.ToString(), "Submission Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // *** MODIFIED MessageBox FORMAT ENDS HERE ***
                        }
                        else
                        {
                            MessageBox.Show(this, "Could not find the Midterm record to update with exam scores. Please ensure Midterm Class Standing was submitted first.", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Debug.WriteLine($"Failed to update Midterm Exam Score. No record found for AcademicPeriodId: {_selectedCourse.AcademicPeriodId} and Term: {_currentGradingTerm}");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error saving Midterm exam data to database: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Debug.WriteLine($"Database error in button1_Click (save exam): {ex.ToString()}");
                        return;
                    }
                }
            }

            if (!saveSuccess) return;

            // Navigate to classStandingfinals (This part remains unchanged)
            try
            {
                this.Hide();
                classStandingfinals finalsStandingForm = new classStandingfinals(
                    _selectedCourse,
                    "Finals", // Assuming "Finals" is the correct term string for the next form
                    _selectCourseFormRef,
                    _dashboardFormRef
                );

                using (finalsStandingForm)
                {
                    DialogResult finalsStandingResult = finalsStandingForm.ShowDialog(this);
                    Debug.WriteLine($"classExammidterm ({_currentGradingTerm}): finalsStandingForm closed with DialogResult: {finalsStandingResult}");
                }

                Debug.WriteLine($"classExammidterm ({_currentGradingTerm}): Processing complete. Closing this form.");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error navigating to Finals Class Standing: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"classExammidterm: Error navigating to classStandingfinals - {ex.Message}\n{ex.StackTrace}");
                this.DialogResult = DialogResult.Abort;
                if (!this.IsDisposed)
                {
                    this.Show();
                }
            }
        }

        // Clear button (button2)
        private void button2_Click(object sender, EventArgs e)
        {
            Debug.WriteLine($"classExammidterm: Clear button clicked for {_currentGradingTerm} Exam.");
            TextBox txtActualExamScore = FindControlRecursive(this, ActualExamScoreInputTextBoxName) as TextBox;
            txtActualExamScore?.Clear();
            txtActualExamScore?.Focus();
        }

        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (string.Equals(root.Name, name, StringComparison.OrdinalIgnoreCase)) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }


        
        // stores the midterm class standing value
        private void txtCLSR_TextChanged(object sender, EventArgs e)
        {

        }

        // Add this if it's missing from your .Designer.cs or if you are not using a designer
        // private void InitializeComponent()
        // {
        //     this.SuspendLayout();
        //     // Manually add controls here if not using a designer
        //     // Example:
        //     // this.label1 = new System.Windows.Forms.Label();
        //     // this.label1.Name = "label1";
        //     // this.Controls.Add(this.label1);
        //     // this.txtCLSR = new System.Windows.Forms.TextBox(); // For Midterm CS Display
        //     // this.txtCLSR.Name = "txtCLSR";
        //     // this.Controls.Add(this.txtCLSR);
        //     // this.textBox1 = new System.Windows.Forms.TextBox(); // For Actual Exam Score Input
        //     // this.textBox1.Name = "textBox1";
        //     // this.Controls.Add(this.textBox1);
        //     // this.button1 = new System.Windows.Forms.Button(); // Submit
        //     // this.button1.Name = "button1";
        //     // this.button1.Click += new System.EventHandler(this.button1_Click);
        //     // this.Controls.Add(this.button1);
        //     this.Name = "classExammidterm";
        //     this.Text = "Midterm Exam";
        //     // this.Load += new System.EventHandler(this.classExammidterm_Load); // Already assigned in constructor
        //     this.ResumeLayout(false);
        // }
    }
}