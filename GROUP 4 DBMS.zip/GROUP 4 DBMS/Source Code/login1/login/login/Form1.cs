using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace login
{
    public partial class frmRegister : Form
    {
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // Controls for Student ID, Password, Confirm Password, and Show Password should exist on your form:
        // public TextBox regisUN;         // Student ID
        // public TextBox regisPass;       // Password
        // public TextBox regisConfPass;   // Confirm Password
        // public CheckBox regisShowPass; // Show Password Checkbox


        public frmRegister()
        {
            InitializeComponent();

        }

        private void button1_Click_1(object sender, EventArgs e) // Register button
        {
            // --- Get values from your UI controls (only Student ID, Password, Confirm Password) ---
            string studentIdText = regisUN.Text.Trim();
            string passwordText = textBox1.Text;
            string confirmPasswordText = regisConfPass.Text;

            // --- Fields for FirstName, LastName, Email, DateOfBirth, PhoneNumber are removed as requested ---
            // The corresponding database columns might become NULL if they are not NOT NULL in the DB.


            // Add checks for required fields (only Student ID, Password, Confirm Password)
            if (string.IsNullOrWhiteSpace(studentIdText) ||
                string.IsNullOrWhiteSpace(passwordText) ||
                string.IsNullOrWhiteSpace(confirmPasswordText)
               )
            {
                // Updated message to reflect fewer required fields
                MessageBox.Show("Please fill all required fields: Student ID, Password, and Confirm Password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                // Find the first empty required field and focus it
                if (string.IsNullOrWhiteSpace(studentIdText)) regisUN.Focus();
                else if (string.IsNullOrWhiteSpace(passwordText)) textBox1.Focus();
                else if (string.IsNullOrWhiteSpace(confirmPasswordText)) regisConfPass.Focus();

                return;
            }

            if (passwordText != confirmPasswordText)
            {
                MessageBox.Show("Password and Confirm Password do not match.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = "";
                regisConfPass.Text = "";
                textBox1.Focus();
                return;
            }

            // Validate Student ID is numeric
            int studentIDNumeric;
            if (!int.TryParse(studentIdText, out studentIDNumeric))
            {
                MessageBox.Show("Student ID must be a numerical value.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                regisUN.Text = "";
                regisUN.Focus();
                return;
            }

            // --- Updated INSERT Query to only include studentID and password ---
            // Make sure your dbo.student table has a 'password' column.
            // FirstName, LastName, DateOfBirth, Email, PhoneNumber columns will need to accept NULL values in the database.
            string registerQuery = @"INSERT INTO dbo.student
                                       (studentID, password)
                                   VALUES
                                       (@StudentID, @Password)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(registerQuery, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentIDNumeric); // Use parsed int

                    // **SECURITY WARNING:** Storing plain text passwords is NOT secure.
                    // You should HASH passwords using a strong hashing algorithm (like bcrypt)
                    // before storing them in the database. This is a critical security flaw
                    // in the current code that needs to be addressed.
                    cmd.Parameters.AddWithValue("@Password", passwordText);

                    // --- Parameters for FirstName, LastName, Email, DateOfBirth, PhoneNumber removed ---

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student Registration Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Debug.WriteLine($"Registration successful for Student ID: {studentIdText}"); // Updated debug message


                        // --- NAVIGATION: Go to Login after successful registration ---
                        // Check if frmLogin is already open to avoid multiple instances
                        Form loginForm = Application.OpenForms["frmLogin"];
                        if (loginForm != null)
                        {
                            loginForm.Show();
                            // Consider clearing the login form fields if needed
                            // if (loginForm is frmLogin login)
                            // {
                            // login.ClearFields(); // Assuming frmLogin has a ClearFields method
                            // }
                        }
                        else
                        {
                            loginForm = new frmLogin();
                            loginForm.Show();
                        }
                        this.Hide(); // Hide the current registration form

                    }
                    catch (SqlException sqlEx)
                    {
                        Debug.WriteLine($"SQL Error during registration: {sqlEx.Message} (Number: {sqlEx.Number})");
                        if (sqlEx.Number == 2627) // Unique key violation (e.g., Student ID already exists)
                        {
                            // With only studentID and password, this is likely a duplicate studentID
                            MessageBox.Show("Registration failed. This Student ID already exists.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (sqlEx.Number == 207) // Invalid column name (less likely now, but possible if 'password' is missing)
                        {
                            MessageBox.Show($"Database Error: Invalid column name. Please check your SQL query against your database schema. Details: {sqlEx.Message}", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (sqlEx.Number == 515) // Cannot insert the value NULL into column 'ColumnName'
                        {
                            MessageBox.Show($"Database Error: Cannot save data because some required information is missing (likely in the database schema). Please ensure columns can accept NULL or provide data.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show($"Registration failed. Database Error: {sqlEx.Message}", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"General Error during registration: {ex.Message}");
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void regisShowPass_CheckedChanged(object sender, EventArgs e)
        {
            bool show = regisShowPass.Checked;
            textBox1.PasswordChar = show ? '\0' : '*';
            regisConfPass.PasswordChar = show ? '\0' : '*';
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            // Clear only the fields that are part of this registration flow
            regisUN.Text = "";
            textBox1.Text = "";
            regisConfPass.Text = "";

            // --- Clearing for FirstName, LastName, Email, etc. removed ---

            regisUN.Focus(); // Set focus back to the Student ID field
        }

        private void label6_Click(object sender, EventArgs e) // "Back to LOGIN" Link/Label
        {
            // Check if frmLogin is already open to avoid multiple instances
            Form loginForm = Application.OpenForms["frmLogin"];
            if (loginForm != null)
            {
                loginForm.Show();
            }
            else
            {
                loginForm = new frmLogin();
                loginForm.Show();
            }
            this.Hide(); // Hide the current registration form
        }

        // --- Generated code placeholders - Keep these if they were in your original file ---
        // These methods are typically auto-generated by the form designer for specific events.
        // Make sure the method names match the events they are linked to in the designer.

        // username textbox TextChanged event (regisUN)
        private void regisUN_TextChanged(object sender, EventArgs e)
        {
            // Add any logic needed when the Student ID text changes
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {
            // Add any logic needed when the form loads
        }

        // password textbox TextChanged event (textBox1 - assuming this is regisPass based on context)
        // It's better to use the actual name regisPass_TextChanged if that's the control's name
        private void textBox1_TextChanged(object sender, EventArgs e) // CHECK THIS NAME - should it be regisPass_TextChanged?
        {
            // Add any logic needed when the Password text changes
        }

        // confirm password textbox TextChanged event (regisConfPass)
        private void regisConfPass_TextChanged(object sender, EventArgs e)
        {
            // Add any logic needed when the Confirm Password text changes
        }

        // --- Event handlers for controls you removed from the registration logic can be removed if not used elsewhere ---
        // Example: If txtFirstName_TextChanged only contained a placeholder comment, you can remove the method entirely.
        // private void txtFirstName_TextChanged(object sender, EventArgs e) { } // Remove if not needed
        // private void txtLastName_TextChanged(object sender, EventArgs e) { } // Remove if not needed
        // private void txtEmail_TextChanged(object sender, EventArgs e) { } // Remove if not needed
        // private void dtpDateOfBirth_ValueChanged(object sender, EventArgs e) { } // Remove if not needed
        // private void txtPhoneNumber_TextChanged(object sender, EventArgs e) { } // Remove if not needed


        // --- End of generated code placeholders ---
    }
}