﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace login
{
    public partial class frmLogin : Form
    {
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // Controls for Student ID, Password, Confirm Password, and Show Password should exist on your form:
        // public TextBox regisUN;         // Student ID input
        // public TextBox regisPass;       // Password input
        // public CheckBox regisShowPass; // Show Password Checkbox

        public frmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // Login Button
        {
            if (string.IsNullOrWhiteSpace(regisUN.Text) || string.IsNullOrWhiteSpace(regisPass.Text))
            {
                MessageBox.Show("Please enter both Student ID and password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                regisUN.Focus();
                return;
            }

            int studentIDNumeric;
            if (!int.TryParse(regisUN.Text, out studentIDNumeric))
            {
                MessageBox.Show("Student ID must be a numerical value.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                regisUN.Text = "";
                regisUN.Focus();
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // --- Updated Login Query ---
                // Select a minimal value (like 1) to check if a row exists.
                // We no longer select 'student_name' as it was removed from the table.
                string loginQuery = "SELECT 1 FROM dbo.student WHERE studentID = @StudentID AND password = @Password";

                // **SECURITY NOTE:** This query checks for a plain text password match.
                // If you implemented password hashing during registration (which is strongly recommended),
                // you MUST retrieve the hashed password from the database and compare it
                // with a hash of the entered password in your application code instead of the SQL query.

                using (SqlCommand cmd = new SqlCommand(loginQuery, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentIDNumeric); // Use the parsed int value
                    cmd.Parameters.AddWithValue("@Password", regisPass.Text); // Using plain text password from input

                    try
                    {
                        con.Open();
                        // ExecuteScalar is efficient if you only need to know if a row exists.
                        // If a row is found, ExecuteScalar returns the first column of the first row (which is 1 in this query).
                        // If no row is found, it returns null.
                        object result = cmd.ExecuteScalar();

                        if (result != null) // If a matching student was found (result is not null)
                        {
                            Debug.WriteLine($"Login successful for Student ID: {regisUN.Text}"); // Updated debug message

                            // --- MODIFIED DASHBOARD INSTANTIATION ---
                            // Open dashboard, passing only studentID (as string from regisUN.Text)
                            dashboard mainDashboard = new dashboard(regisUN.Text); // Pass the original text input for Student ID
                            mainDashboard.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Student ID or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            regisUN.Text = "";
                            regisPass.Text = "";
                            regisUN.Focus();
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Debug.WriteLine($"SQL Error during login: {sqlEx.Message} (Number: {sqlEx.Number})");
                        MessageBox.Show($"Database Error: {sqlEx.Message}", "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"General Error during login: {ex.Message}");
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            regisUN.Text = "";
            regisPass.Text = "";
            regisUN.Focus();
        }

        private void regisShowPass_CheckedChanged(object sender, EventArgs e)
        {
            regisPass.PasswordChar = regisShowPass.Checked ? '\0' : '*';
        }

        private void label6_Click(object sender, EventArgs e) // "Create Account" Link
        {
            // Check if frmRegister is already open to avoid multiple instances
            Form registrationForm = Application.OpenForms["frmRegister"];
            if (registrationForm != null)
            {
                registrationForm.Show();
            }
            else
            {
                registrationForm = new frmRegister();
                registrationForm.Show();
            }
            this.Hide();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            // Set initial focus when the form loads
            regisUN.Focus();
        }

        // Add or keep other event handlers defined in your designer if necessary

        // Example: TextChanged event for Student ID textbox (regisUN)
        // private void regisUN_TextChanged(object sender, EventArgs e) { }

        // Example: TextChanged event for Password textbox (regisPass or textBox1 based on your designer)
        // private void regisPass_TextChanged(object sender, EventArgs e) { } // Use the correct name from designer

    }
}