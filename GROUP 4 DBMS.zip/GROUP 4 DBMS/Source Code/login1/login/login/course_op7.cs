﻿using System;
using System.Collections.Generic; // Added for List
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Make sure you are using the correct SQL Client namespace if needed in this form
// using System.Data.SqlClient;
// using Microsoft.Data.SqlClient;

namespace login
{
    // CourseDetails class is defined in a shared file/namespace
    // Ensure this class definition is accessible and includes the AcademicPeriodId property.
    /*
    public class CourseDetails
    {
        // ... (Existing properties) ...
        public int AcademicPeriodId { get; set; } // Make sure this property is added
    }
    */

    // This form handles the EIGHTH course (Course 8) when N > 7.
    // It acts as the FINAL form if N=8 (navigating to selectterm). It needs to lead to course_op8 if N>8.
    public partial class course_op7 : Form // Ensure the class name is correct
    {
        // Optional: Connection string if you plan to save data here
        // private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";


        // Fields to store data passed from previous form (course_op6) and manage the sequence
        private string schoolYear;
        private string semester;
        private int totalCourses; // This is N
        private int currentCourseNumber; // Receives the course number for THIS form (should be 8)

        // Reference back to course_op6
        internal Form previousForm;

        // Reference to the Dashboard form for final navigation
        private Form dashboardForm;

        // A list to temporarily hold course details collected from previous forms + this one
        // This list is received from course_op6's constructor
        private List<CourseDetails> enteredCourses; // Uses the shared CourseDetails class

        // *** NEW: Field to store the Academic Period ID ***
        private int academicPeriodId;


        // --- Modified Constructors ---

        // Constructor to receive data from the previous form (course_op6) AND dashboard, AND academicPeriodId (8 arguments)
        public course_op7(string year, string sem, int totalNumCourses, int currentCourseNum, Form callingForm, Form dashboard, List<CourseDetails> collectedDataSoFar, int academicPeriodId) // *** Added academicPeriodId parameter ***
        {
            InitializeComponent();
            // Store the received data
            this.schoolYear = year;
            this.semester = sem;
            this.totalCourses = totalNumCourses; // Store total number of courses (N)
            this.currentCourseNumber = currentCourseNum; // Store current course number (should be 8)
            this.previousForm = callingForm; // This should be course_op6
            this.dashboardForm = dashboard;
            this.enteredCourses = collectedDataSoFar; // Store the list received from course_op6
            this.academicPeriodId = academicPeriodId; // *** Store the received ID ***

            // Set up the Load event to initialize the form's UI
            this.Load += course_op7_Load; // Make sure your Load event handler name is correct
        }


        // Keep the parameterless constructor (though it won't have necessary data if used directly)
        public course_op7()
        {
            InitializeComponent();
            this.Load += course_op7_Load;
            // Handle case if opened directly - data fields will be null/0
            this.enteredCourses = new List<CourseDetails>(); // Initialize list even if data is missing
            // Disable interaction if not properly initialized (optional but recommended)
            this.Load += (s, e) =>
            {
                // *** Added check for academicPeriodId == 0 ***
                if (totalCourses == 0 || dashboardForm == null || enteredCourses == null || academicPeriodId == 0)
                {
                    MessageBox.Show("This form was opened directly and is not fully initialized with Academic Period ID.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // Disable key controls if data is missing
                    Control[] foundControls = this.Controls.Find("button1", true);
                    if (foundControls.Length > 0 && foundControls[0] is Button btn1) btn1.Enabled = false;
                    foundControls = this.Controls.Find("button2", true);
                    if (foundControls.Length > 0 && foundControls[0] is Button btn2) btn2.Enabled = false;
                }
            };
        }


        // --- Form Load and Initialization ---
        private void course_op7_Load(object sender, EventArgs e)
        {
            // Ensure the form was initialized correctly, including the Academic Period ID
            // This form expects currentCourseNumber to be 8.
            // If N=7, course_op6 is the final form and navigates to selectterm.
            // This form is only reached if N >= 8 and course_op6 was Course 7.
            // So if totalCourses < 8 || currentCourseNumber != 8 || academicPeriodId == 0, something is wrong.
            if (totalCourses < 8 || currentCourseNumber != 8 || dashboardForm == null || enteredCourses == null || academicPeriodId == 0) // *** Added check for academicPeriodId and adjusted totalCourses check ***
            {
                MessageBox.Show("This form was initialized incorrectly. Expected Course 8. Missing required data or Academic Period ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Disable buttons if initialized incorrectly
                Control[] foundButtons = this.Controls.Find("button1", true);
                if (foundButtons.Length > 0 && foundButtons[0] is Button nextSubmitButtonControl) nextSubmitButtonControl.Enabled = false; // Used 'nextSubmitButtonControl'

                foundButtons = this.Controls.Find("button2", true);
                if (foundButtons.Length > 0 && foundButtons[0] is Button clearButton) clearButton.Enabled = false; // 'clearButton' is fine

                // Ensure a Back button exists to escape if necessary (assuming button3 exists)
                Control[] foundBackButton = this.Controls.Find("button3", true); // Corrected variable name
                if (foundBackButton.Length == 0)
                {
                    // If no back button, consider adding one or prompting the user to close.
                }
                return; // Exit Load if invalid state
            }

            // Update a label to show "Course 8 of N" (assuming lblCourseNumber exists)
            Control[] foundLabels = this.Controls.Find("lblCourseNumber", true); // Used 'foundLabels' again, which is fine
            if (foundLabels.Length > 0 && foundLabels[0] is Label lblCourseNumber) // 'lblCourseNumber' is fine
            {
                lblCourseNumber.Text = $"Course {currentCourseNumber} of {totalCourses}";
            }


            // Change button text based on if this is the LAST course entry form for the given N
            Control[] foundBtnSubmit = this.Controls.Find("button1", true); // Used 'foundBtnSubmit'
            if (foundBtnSubmit.Length > 0 && foundBtnSubmit[0] is Button nextSubmitButtonForText) // *** Used 'nextSubmitButtonForText' ***
            {
                if (currentCourseNumber == totalCourses) // If N=8, submit
                {
                    nextSubmitButtonForText.Text = "Submit"; // Change to Submit
                }
                else // currentCourseNumber < totalCourses - If N > 8, move to course_op8
                {
                    nextSubmitButtonForText.Text = "Next"; // Keep as Next
                }
            }

            // Set initial focus (assuming textBox1 exists)
            Control[] foundTextBoxes = this.Controls.Find("textBox1", true); // Used 'foundTextBoxes' again, which is fine
            if (foundTextBoxes.Length > 0 && foundTextBoxes[0] is TextBox tb1) // 'tb1' is fine
            {
                tb1.Focus();
            }
        }


        // --- Textbox Changed Events ---
        // (Assuming textBox1, textBox2, textBox4 exist on your form)
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }


        // --- Modified Button Click Event ---

        // next/submit button (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            // Ensure the form was initialized correctly, including Academic Period ID
            if (totalCourses < 8 || currentCourseNumber != 8 || dashboardForm == null || enteredCourses == null || academicPeriodId == 0) // *** Added check for academicPeriodId and adjusted totalCourses check ***
            {
                MessageBox.Show("This form is in an unexpected state for Course 8 processing. Missing required data or Academic Period ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // --- Get and Validate Course 8 Data ---
            // (Assuming textBox1, textBox2, textBox4 exist)
            string courseCode = "";
            string courseName = "";
            string unitsText = "";

            // Find textBox1 (Course Code)
            Control[] foundTextBox1 = this.Controls.Find("textBox1", true);
            if (foundTextBox1.Length > 0 && foundTextBox1[0] is TextBox textBox1Control)
            {
                courseCode = textBox1Control.Text.Trim();
            }
            else
            {
                MessageBox.Show("Configuration Error: 'textBox1' not found on the form.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Stop processing if critical control is missing
            }

            // Find textBox2 (Course Name)
            Control[] foundTextBox2 = this.Controls.Find("textBox2", true);
            if (foundTextBox2.Length > 0 && foundTextBox2[0] is TextBox textBox2Control)
            {
                courseName = textBox2Control.Text.Trim();
            }
            else
            {
                MessageBox.Show("Configuration Error: 'textBox2' not found on the form.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Stop processing if critical control is missing
            }


            // Find textBox4 (Units)
            Control[] foundTextBox4 = this.Controls.Find("textBox4", true);
            if (foundTextBox4.Length > 0 && foundTextBox4[0] is TextBox textBox4Control)
            {
                unitsText = textBox4Control.Text.Trim();
            }
            else
            {
                MessageBox.Show("Configuration Error: 'textBox4' not found on the form.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Stop processing if critical control is missing
            }


            int units;
            if (string.IsNullOrWhiteSpace(courseCode) || string.IsNullOrWhiteSpace(courseName) || string.IsNullOrWhiteSpace(unitsText))
            {
                MessageBox.Show($"Please fill in all fields for Course {currentCourseNumber}.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Set focus to the first empty field (check if controls were found first)
                if (string.IsNullOrWhiteSpace(courseCode) && foundTextBox1.Length > 0) foundTextBox1[0].Focus();
                else if (string.IsNullOrWhiteSpace(courseName) && foundTextBox2.Length > 0) foundTextBox2[0].Focus();
                else if (string.IsNullOrWhiteSpace(unitsText) && foundTextBox4.Length > 0) foundTextBox4[0].Focus();
                return;
            }
            if (!int.TryParse(unitsText, out units) || units <= 0)
            {
                MessageBox.Show($"Please enter a valid positive number for Units for Course {currentCourseNumber}.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (foundTextBox4.Length > 0) foundTextBox4[0].Focus();
                return;
            }


            // --- Save Course 8 Data (Modified to include AcademicPeriodId) ---
            // Add the data to the list received from course_op6.
            CourseDetails course8Details = new CourseDetails
            {
                Code = courseCode,
                Name = courseName,
                Units = units,
                SchoolYear = this.schoolYear,
                Semester = this.semester,
                CourseNumber = this.currentCourseNumber, // This should be 8
                AcademicPeriodId = this.academicPeriodId // *** NEW: Assign the received ID ***
            };
            this.enteredCourses.Add(course8Details); // Add Course 8 details to the list


            // --- Determine Next Step (Submit or Open next form) ---
            if (currentCourseNumber == totalCourses) // If N=8, submit
            {
                // --- INTEGRATED SELECT TERM FORM LOGIC ---
                // The navigation and saving logic for N=8 (and other N values
                // when the last course form is reached) is handled in selectterm.cs now.

                MessageBox.Show($"All {totalCourses} courses entered successfully! Please select the term for grading.", "Course Entry Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);

                try
                {
                    // Create an instance of your selectterm form
                    // Pass the collected course data AND THIS FORM AND THE DASHBOARD.
                    // *** IMPORTANT: Ensure selectterm has the constructor: public selectterm(List<CourseDetails> courses, Form callingForm, Form dashboard) ***
                    selectterm termForm = new selectterm(this.enteredCourses, this, this.dashboardForm); // *** Corrected constructor call ***

                    termForm.Show(); // Show the select term form

                    // Hide the current course form (course_op7)
                    this.Hide();

                    // The closing of the previous forms (course_op6, course_op5, ..., firstpartcourse)
                    // is now handled in the selectterm.cs NavigateToSelectCourse method.

                    // We will close the current form (course_op7) after selectterm finishes.
                    // Or you can close it here if you prefer, but closing the chain from selectterm is cleaner.
                    // this.Close(); // Option 1: Close course_op7 here

                }
                catch (MissingMethodException mmEx)
                {
                    // Handle case where the selectterm constructor is missing
                    MessageBox.Show("Configuration Error: The 'selectterm' form does not have the required constructor (List<CourseDetails>, Form, Form).\nPlease add this constructor to selectterm.cs.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on the current form if navigation failed
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening Select Term form: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on the current form if navigation failed
                }
            }
            else // currentCourseNumber < totalCourses - If N > 8, move to course_op8
            {
                // --- Move to Next Course Entry (Open course_op8) ---
                int nextCourseNumber = currentCourseNumber + 1; // Should be 9

                // Here you would open the NEXT form in the chain (course_op8)
                // This requires course_op8.cs to exist and have the same constructor signature:
                // public course_op8(string year, string sem, int totalNumCourses, int currentCourseNum, Form callingForm, Form dashboard, List<CourseDetails> collectedDataSoFar, int academicPeriodId) // *** It needs the academicPeriodId now ***

                try
                {
                    // *** Corrected constructor call to pass academicPeriodId ***
                    course_op8 nextForm = new course_op8(
                         this.schoolYear,
                         this.semester,
                         this.totalCourses,
                         nextCourseNumber, // Pass the NEXT course number (9)
                         this,             // Pass THIS form (course_op7) as the previous form for course_op8
                         this.dashboardForm, // Pass the dashboard reference
                         this.enteredCourses, // IMPORTANT: PASS THE LIST HERE
                         this.academicPeriodId // *** NEW: Pass the Academic Period ID ***
                     );

                    nextForm.Show();  // Show the next form (course_op8)
                    this.Hide();      // Hide the current form (course_op7)

                }
                catch (MissingMethodException mmEx)
                {
                    MessageBox.Show($"Configuration Error: The next course form (course_op{nextCourseNumber - 1}) does not have the required constructor (string, string, int, int, Form, Form, List<CourseDetails>, int academicPeriodId).\nPlease add this constructor to that form's .cs file.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on current form if navigation failed
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error navigating to next course entry: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show(); // Stay on current form if navigation failed
                }
            }
        }


        // clear button (button2)
        private void button2_Click(object sender, EventArgs e)
        {
            // Clear the input fields for the current course (Course 8)
            // (Assuming textBox1, textBox2, textBox4 exist)

            Control[] foundTextBoxes;

            foundTextBoxes = this.Controls.Find("textBox1", true);
            if (foundTextBoxes.Length > 0 && foundTextBoxes[0] is TextBox tb1) tb1.Clear();

            foundTextBoxes = this.Controls.Find("textBox2", true);
            if (foundTextBoxes.Length > 0 && foundTextBoxes[0] is TextBox tb2) tb2.Clear();

            foundTextBoxes = this.Controls.Find("textBox4", true);
            if (foundTextBoxes.Length > 0 && foundTextBoxes[0] is TextBox tb4) tb4.Clear();


            // Set focus back to the first input field (assuming textBox1 exists)
            foundTextBoxes = this.Controls.Find("textBox1", true);
            if (foundTextBoxes.Length > 0 && foundTextBoxes[0] is TextBox tb1Focus) tb1Focus.Focus(); // Use a different variable name like tb1Focus
        }

        // Back button (button3) <-- This goes back to course_op6
        // Add this method if you have a button named button3 on your form
        private void button3_Click(object sender, EventArgs e)
        {
            // Hide the current form (course_op7)
            this.Hide();

            // Show the previous form (course_op6) if the reference exists
            if (previousForm != null)
            {
                previousForm.Show(); // Show the previous form (course_op6)
            }
            else
            {
                // This shouldn't happen in the normal flow if N >= 8, but good to handle
                MessageBox.Show("Cannot go back from Course 8.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close(); // Close this form if we can't go back
            }
        }

        // Add other necessary methods or properties for course_op7 here.

    }
}