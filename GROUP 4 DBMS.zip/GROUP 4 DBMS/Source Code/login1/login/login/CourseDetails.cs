﻿// This class is defined once and shared across all forms
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace login
{
    public class CourseDetails
    {
        // Properties to store details for a single course entry
        public string SchoolYear { get; set; }
        public string Semester { get; set; }
        public int CourseNumber { get; set; } // e.g., 1, 2, 3, 4, ... N
        public string Code { get; set; }      // e.g., "CS101"
        public string Name { get; set; }      // e.g., "Introduction to Programming"
        public int Units { get; set; }      // e.g., 3

        // *** NEW: Link to the AcademicPeriods table ***
        public int AcademicPeriodId { get; set; }
        // public int CourseID { get; set; }



        // Add other properties here as needed for your application
        // e.g., public string Grade { get; set; }
        // e.g., public string Professor { get; set; }
        // e.g., public int StudentId { get; set; } // If tracking per student
    }
}