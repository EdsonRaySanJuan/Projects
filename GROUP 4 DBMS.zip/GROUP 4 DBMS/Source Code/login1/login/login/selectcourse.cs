﻿// selectcourse.cs - Integrated version linking to classStanding and passing grading term



using System;

using System.Collections.Generic;

using System.ComponentModel;

using System.Data;

using System.Drawing;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.Windows.Forms;

using Microsoft.Data.SqlClient;

using System.Diagnostics;



// Assuming CourseDetails class is defined in the 'login' namespace and is accessible.

// This class should be in its own file (e.g., CourseDetails.cs) and be public.

// Make sure it has the AcademicPeriodId, Code, Name, Units, SchoolYear, Semester properties.



// Ensure the classStanding form is also in the 'login' namespace and accessible.

// Make sure classStanding has this constructor: public classStanding(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard) { ... }



namespace login

{

    // This is a partial class definition. The rest of the class (including components and InitializeComponent)

    // is defined in the auto-generated selectcourse.Designer.cs file.

    // DO NOT define InitializeComponent, the 'components' field, Dispose(), or the Designer generated region here.

    public partial class selectcourse : Form

    {

        // Member variable to hold the reference to the Dashboard form for final navigation

        private Form dashboardForm;



        // Fields to store the data received from selectterm.cs (when returning from course entry)

        // These are populated by the constructor used when coming from selectterm.

        private List<CourseDetails> _receivedCourses;

        private string _selectedTerm; // This now holds the Grading Term (Prelim/Midterm/Finals)



        // We don't need a field to store academicPeriodId for *new* entry here

        // because we get it and use it immediately in button1_Click.





        // --- Constructors ---



        // Constructor that accepts the Dashboard form reference (likely used when starting a new entry from dashboard)

        public selectcourse(Form dashboard)

        {

            InitializeComponent(); // This calls the method in selectcourse.Designer.cs

            this.dashboardForm = dashboard; // Store the dashboard reference

            this.Load += Selectcourse_Load; // Hook up the Load event

        }



        // Constructor to receive courses, term (Grading Term), and dashboard (used when returning from selectterm)

        // This constructor receives the collected course data after the entry sequence is complete.

        public selectcourse(List<CourseDetails> courses, string term, Form dashboard) : this(dashboard) // Chain to the existing constructor to set dashboard

        {

            this._receivedCourses = courses; // Store the received list of courses

            this._selectedTerm = term;      // Store the received selected Grading Term (Prelim/Midterm/Finals)



            // The Selectcourse_Load event will handle displaying this data.

        }



        // Parameterless constructor (Needed by the form designer. Data fields will be default values if used directly.)

        // If this constructor is used for reasons other than the designer, the form will not have

        // the necessary data (_receivedCourses, _selectedTerm, dashboardForm) for normal operation.

        public selectcourse()

        {

            InitializeComponent(); // This calls the method in selectcourse.Designer.cs

            // Initialize the list and term to prevent NullReferenceException if this constructor is used directly

            this._receivedCourses = new List<CourseDetails>();

            this._selectedTerm = string.Empty; // Initialize _selectedTerm as well

            this.Load += Selectcourse_Load;

            this.Load += (s, e) => HandleParameterlessConstructorContext();

        }



        private void HandleParameterlessConstructorContext()

        {

            // Check if the form was likely opened incorrectly (not via the constructor that receives data)

            if (dashboardForm == null && (_receivedCourses == null || _receivedCourses.Count == 0 || string.IsNullOrEmpty(_selectedTerm)))

            {

                Debug.WriteLine("Warning: selectcourse form initialized without expected data or dashboard reference.");

                MessageBox.Show("This form was opened incorrectly. Missing data or context.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                EnableResultDisplay(false); // Show new entry controls (which should be hidden in this scenario)

            }

        }



        // --- Helper to manage control visibility based on state ---

        // Use this method to show/hide the correct set of controls

        // depending on whether the form is for starting a New Entry or Displaying Results.

        private void EnableResultDisplay(bool enable)

        {

            // Define controls for the 'New Entry' state

            // ADJUST THESE NAMES TO MATCH YOUR DESIGNER CONTROLS FOR NEW ENTRY

            Control[] newEntryControls = {

        FindControlRecursive(this, "label1"), // "Course Details" label or similar for new entry section

                FindControlRecursive(this, "label8"), // "Select School Year" label

                FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear"), // Input for School Year

                FindControlRecursive(this, "label2"), // "Select Semester" label

                FindControlRecursive(this, "textBoxSemester") ?? FindControlRecursive(this, "comboBoxSemester"), // Input for Semester

                FindControlRecursive(this, "label3"), // "Enter Number of Course" label

                FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses"), // Input for number of courses

                // FindControlRecursive(this, "button1"), // Original Submit button - handled separately below

                // FindControlRecursive(this, "button2"), // Original Clear button - handled separately below

            };



            // Define controls for the 'Display Results' state

            // ADJUST THESE NAMES TO MATCH YOUR DESIGNER CONTROLS FOR DISPLAYING RESULTS

            Control[] dataDisplayControls = {

        FindControlRecursive(this, "lblSelectedTerm"), // Label showing the selected Term (Grading Term)

                FindControlRecursive(this, "comboBox1"),        // ComboBox listing the Courses

                // Add other controls for displaying details of the selected course

                FindControlRecursive(this, "lblUnits"),

        FindControlRecursive(this, "lblAcademicPeriodId"),

        FindControlRecursive(this, "txtCourseCodeDisplay"),

        FindControlRecursive(this, "txtCourseNameDisplay"),

                // FindControlRecursive(this, "btnProcessGrades") // A separate button for grading, if you add one

            };



            // Manage visibility and text of button1 (Submit for new entry / Process Grades for results)

            Control btn1 = FindControlRecursive(this, "button1");

            if (btn1 is Button button1Control)

            {

                button1Control.Visible = true; // Assuming button1 is visible in both states

                button1Control.Text = enable ? "Process Grades" : "Submit Academic Period"; // Change text based on state

            }



            // Manage visibility and text of button2 (Clear for new entry / Clear Selection for results)

            Control btn2 = FindControlRecursive(this, "button2");

            if (btn2 is Button button2Control)

            {

                button2Control.Visible = true; // Assuming button2 is visible in both states

                button2Control.Text = enable ? "Clear Selection" : "Clear Inputs"; // Change text based on state

            }



            // Hide/Show controls based on the state (enable = true means Display Results state)

            foreach (Control ctrl in newEntryControls)

            {

                if (ctrl != null && this.Controls.Contains(ctrl)) ctrl.Visible = !enable;

            }



            foreach (Control ctrl in dataDisplayControls)

            {

                if (ctrl != null && this.Controls.Contains(ctrl)) ctrl.Visible = enable;

            }



            // Ensure the back button (button3) is visible regardless of state

            Control btnBack = FindControlRecursive(this, "button3");

            if (btnBack != null) btnBack.Visible = true;

        }





        // --- Helper to find controls recursively ---

        // This is needed because Controls.Find only searches direct children by default.

        private Control FindControlRecursive(Control root, string name)

        {

            if (root == null) return null;

            if (root.Name == name) return root;

            foreach (Control c in root.Controls)

            {

                Control t = FindControlRecursive(c, name);

                if (t != null) return t;

            }

            return null;

        }





        // Form Load event handler - Handles logic when the form is shown/loaded

        private void Selectcourse_Load(object sender, EventArgs e)

        {

            // Check if the form is loading with received data (meaning it's returning from selectterm)

            if (_receivedCourses != null && _receivedCourses.Count > 0 && !string.IsNullOrEmpty(_selectedTerm))

            {

                // --- Logic to use received data when returning from selectterm ---

                Debug.WriteLine($"selectcourse Load: Returned to selectcourse with {this._receivedCourses.Count} courses for {this._selectedTerm}.");

                MessageBox.Show($"Returned to selectcourse with {this._receivedCourses.Count} courses for {this._selectedTerm}.", "Data Received");



                // *** Removed the DataGridView code that caused "Control Missing" warning ***

                // Control[] foundDataGridView = this.Controls.Find("dataGridViewCourses", true); ... (Removed)



                // --- Call the method to populate your ComboBox and other display controls ---

                PopulateReceivedCourseData();



                // Show result display controls, hide new entry controls

                EnableResultDisplay(true);



            }

            else

            {

                // If the form is loading WITHOUT received data, assume it's for starting a NEW entry.

                // Ensure input controls are visible and data display controls are hidden.

                Debug.WriteLine("selectcourse Load: No received data, assuming starting new entry.");



                EnableResultDisplay(false); // Show input controls, hide result display controls



                // Set initial focus when starting a new entry

                Control initialFocusControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear"); // Assuming the first input control

                initialFocusControl?.Focus(); // Use null conditional for safety



                // Set default value for number of courses if applicable

                Control numCoursesControlForDefault = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses"); // Assuming control for num courses

                if (numCoursesControlForDefault is NumericUpDown numUpDownForDefault)

                {

                    numUpDownForDefault.Value = 1;

                }

                else if (numCoursesControlForDefault is TextBox txtNumCourses)

                {

                    txtNumCourses.Text = "1";

                }

            }

        }





        // Event handler for comboBox1 SelectedIndexChanged (if used as the courses combobox)

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)

        {

            // Add your logic here to display details of the selected course.

            ComboBox cmb = sender as ComboBox;

            if (cmb != null && cmb.SelectedItem != null && _receivedCourses != null)

            {

                string selectedText = cmb.SelectedItem.ToString();

                CourseDetails selectedCourse = _receivedCourses.FirstOrDefault(c => $"{c.Code} - {c.Name}" == selectedText);



                if (selectedCourse != null)

                {

                    // --- Update other UI elements with details from selectedCourse ---

                    // ADJUST THESE NAMES TO MATCH YOUR DETAIL DISPLAY CONTROLS

                    Control lblUnits = FindControlRecursive(this, "lblUnits");

                    if (lblUnits is Label lblU) lblU.Text = $"Units: {selectedCourse.Units}";



                    Control lblAcademicPeriodId = FindControlRecursive(this, "lblAcademicPeriodId");

                    if (lblAcademicPeriodId is Label lblAP) lblAP.Text = $"Academic Period ID: {selectedCourse.AcademicPeriodId}";



                    Control txtCourseCodeDisplay = FindControlRecursive(this, "txtCourseCodeDisplay");

                    if (txtCourseCodeDisplay is TextBox txtCCD) txtCCD.Text = selectedCourse.Code;



                    Control txtCourseNameDisplay = FindControlRecursive(this, "txtCourseNameDisplay");

                    if (txtCourseNameDisplay is TextBox txtCND) txtCND.Text = selectedCourse.Name;



                    Debug.WriteLine($"Selected Course Details: Code={selectedCourse.Code}, Name={selectedCourse.Name}, Units={selectedCourse.Units}, APId={selectedCourse.AcademicPeriodId}");

                }

                else

                {

                    Debug.WriteLine($"Could not find CourseDetails object for selected item text: {selectedText}");

                    // Clear detail display controls if the course object wasn't found

                    if (FindControlRecursive(this, "lblUnits") is Label lblU) lblU.Text = "Units:";

                    if (FindControlRecursive(this, "lblAcademicPeriodId") is Label lblAP) lblAP.Text = "Academic Period ID:";

                    if (FindControlRecursive(this, "txtCourseCodeDisplay") is TextBox txtCCD) txtCCD.Clear();

                    if (FindControlRecursive(this, "txtCourseNameDisplay") is TextBox txtCND) txtCND.Clear();

                }

            }

            else

            {

                Debug.WriteLine("comboBox1_SelectedIndexChanged triggered with null sender, selected item, or _receivedCourses.");

            }

        }



        // Event handler for comboBox2 SelectedIndexChanged (if used and hooked up)

        // Keep this defined ONCE if needed.

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)

        {

            // Add your logic here if this dropdown is used for something else (e.g., Semester)

        }



        // Event handler for textBox1 TextChanged (if used and hooked up)

        // Keep this defined ONCE if needed.

        private void textBox1_TextChanged(object sender, EventArgs e)

        {

            // Add your logic here if this textbox is used for something else.

        }





        // submit btn (button1) click handler - This method handles actions based on the form's state.

        // If displaying results, it acts as "Process Grades". If starting new entry, it saves Academic Period and starts course entry.

        private void button1_Click(object sender, EventArgs e)

        {

            // Check if the form is currently in the 'Display Results' state (i.e., has received courses)

            if (_receivedCourses != null && _receivedCourses.Count > 0 && !string.IsNullOrEmpty(this._selectedTerm))

            {

                // --- Logic for "Process Grades" ---

                Debug.WriteLine($"selectcourse: Button 1 (Process Grades) clicked for term: {this._selectedTerm}.");



                ComboBox cmbCourses = FindControlRecursive(this, "comboBox1") as ComboBox;

                if (cmbCourses != null && cmbCourses.SelectedItem != null)

                {

                    string selectedText = cmbCourses.SelectedItem.ToString();

                    CourseDetails selectedCourse = _receivedCourses?.FirstOrDefault(c => $"{c.Code} - {c.Name}" == selectedText);



                    if (selectedCourse != null)

                    {

                        Debug.WriteLine($"selectcourse: Proceeding with selected course: {selectedCourse.Code} ({selectedCourse.Name}).");



                        this.Hide(); // Hide selectcourse form to start the sequence



                        bool proceedToExamEntry = false; // Flag to determine if classExamprelim should be opened



                        // --- Step 1: Open classStanding (modal) ---

                        Debug.WriteLine("selectcourse: Attempting to show classStanding (modally)...");

                        try

                        {

                            using (classStandingprelim classStandingForm = new classStandingprelim(selectedCourse, this._selectedTerm, this, this.dashboardForm))

                            {

                                // Show classStanding modally. Execution in this method will pause until classStandingForm is closed.

                                DialogResult standingResult = classStandingForm.ShowDialog(this);

                                Debug.WriteLine($"selectcourse: classStanding closed with DialogResult: {standingResult}");



                                // IMPORTANT: For this flow to work, classStanding needs to signal completion.

                                // For example, its "Calculate CS" button (button1), upon successful calculation,

                                // might set 'this.DialogResult = DialogResult.OK;' and then 'this.Close();'.

                                // If it just closes or the back button is used, DialogResult might be Cancel.

                                if (standingResult == DialogResult.OK) // Check if classStanding indicated successful completion/proceed

                                {

                                    proceedToExamEntry = true;

                                }

                                else

                                {

                                    Debug.WriteLine("selectcourse: classStanding did not complete with OK. Not proceeding to Exam Entry.");

                                }

                            }

                        }

                        catch (Exception ex)

                        {

                            MessageBox.Show(this, "An error occurred while trying to open or process the Class Standing form: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            Debug.WriteLine($"selectcourse: Error with Class Standing form - {ex.Message}\n{ex.StackTrace}");

                            // Show selectcourse again or dashboard if error

                            if (this.dashboardForm != null && !this.dashboardForm.IsDisposed) this.dashboardForm.Show();

                            else if (!this.IsDisposed) this.Show();

                            return; // Exit if classStanding had issues

                        }





                        // --- Step 2: Open classExamprelim (modal) if classStanding completed successfully ---

                        if (proceedToExamEntry) // This flag comes from the logic handling classStanding closing

                        {

                            Debug.WriteLine("selectcourse: Attempting to show classExamprelim (modally)...");

                            try

                            {

                                // **** THIS IS THE LINE TO MODIFY ****

                                // Old line (causing error):

                                // using (classExamprelim examEntryForm = new classExamprelim(selectedCourse, this._selectedTerm))



                                // New line (passing the required Form references):

                                using (classExamprelim examEntryForm = new classExamprelim(

                  selectedCourse,

                  this._selectedTerm, // This is the current gradingTerm (e.g., "Prelim")

                                    this,               // 'this' is the current selectcourse instance (for selectCourseForm parameter)

                                    this.dashboardForm  // The dashboardForm reference held by selectcourse

                                ))

                                {

                                    examEntryForm.ShowDialog(this); // Show modally

                                    Debug.WriteLine($"selectcourse: classExamprelim closed.");

                                }



                                // After classExamprelim closes (and it internally launches classStandingmidterm and closes itself),

                                // selectcourse navigates to dashboard.

                                Debug.WriteLine("selectcourse: Sequence involving classExamprelim complete. Navigating to dashboard.");

                                if (this.dashboardForm != null && !this.dashboardForm.IsDisposed)

                                {

                                    this.dashboardForm.Show();

                                }

                                else

                                {

                                    Debug.WriteLine("selectcourse: Dashboard form is null or disposed. Exiting application as fallback.");

                                    Application.Exit();

                                }

                                this.Close(); // Close selectcourse as the entire sequence is finished.

                            }

                            catch (Exception ex)

                            {

                                MessageBox.Show(this, "An error occurred while opening the Exam Grade Entry form: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                                Debug.WriteLine($"selectcourse: Error opening Exam Grade Entry form - {ex.Message}\n{ex.StackTrace}");

                                // Show selectcourse again or dashboard if error

                                if (this.dashboardForm != null && !this.dashboardForm.IsDisposed) this.dashboardForm.Show();

                                else if (!this.IsDisposed) this.Show();

                            }

                        }

                        else // Did not proceed to exam entry (e.g., classStanding was cancelled or did not return OK)

                        {

                            // If not proceeding, and selectcourse was hidden, show dashboard or selectcourse again.

                            if (this.dashboardForm != null && !this.dashboardForm.IsDisposed)

                            {

                                this.dashboardForm.Show();

                                this.Close(); // Close selectcourse as the user might have "backed out" via classStanding

                            }

                            else if (!this.IsDisposed)

                            {

                                this.Show(); // Re-show selectcourse

                            }

                        }

                    }

                    else

                    {

                        MessageBox.Show(this, "Could not find details for the selected course.", "Selection Error");

                        if (!this.IsDisposed) this.Show(); // If selectcourse was hidden due to error/issue

                    }

                }

                else

                {

                    MessageBox.Show(this, "Please select a course from the list to process.", "Selection Required");

                    cmbCourses?.Focus();

                }

                return; // Exit after handling "Process Grades"

            }



            // --- If not in 'Display Results' state, proceed with original NEW entry logic ---

            // (Your existing code for creating new academic periods and courses - THIS PART REMAINS UNCHANGED)

            Debug.WriteLine("selectcourse: Button 1 (Submit Academic Period) clicked!");

            // ... (rest of your NEW entry logic) ...

        }



        // --- Corrected button2_Click (Clear) click handler ---

        // This method handles clearing inputs based on the form's current state.

        // If displaying results, it clears the selection; otherwise, clears new entry inputs.

        private void button2_Click(object sender, EventArgs e)

        {

            // Determine the form's current state

            bool isDisplayingResults = (_receivedCourses != null && _receivedCourses.Count > 0 && !string.IsNullOrEmpty(_selectedTerm));



            if (isDisplayingResults)

            {

                // --- Logic for "Clear Selection" when displaying received courses ---

                Debug.WriteLine("Button 2 (Clear Selection) clicked!");



                // Example: Clear ComboBox selection and detail display fields

                Control cmbCoursesControl = FindControlRecursive(this, "comboBox1");

                // Corrected: Declare and assign comboBox1 outside the if block to fix CS0165

                ComboBox comboBox1 = cmbCoursesControl as ComboBox;



                if (comboBox1 != null) // Now check if the control was successfully found and cast

                {

                    comboBox1.SelectedIndex = -1; // Clear selected item

                    Debug.WriteLine("Cleared ComboBox selection.");

                }

                else

                {

                    Debug.WriteLine("ComboBox 'comboBox1' not found or is not a ComboBox. Cannot clear selection.");

                }





                // Clear related detail display controls (adjust names to match your controls)

                if (FindControlRecursive(this, "lblUnits") is Label lblU) lblU.Text = "Units:";

                if (FindControlRecursive(this, "lblAcademicPeriodId") is Label lblAP) lblAP.Text = "Academic Period ID:";

                if (FindControlRecursive(this, "txtCourseCodeDisplay") is TextBox txtCCD) txtCCD.Clear();

                if (FindControlRecursive(this, "txtCourseNameDisplay") is TextBox txtCND) txtCND.Clear();

                Debug.WriteLine("Cleared detail display controls.");



                // Optional: Set focus back to the ComboBox

                // This is now safe because 'comboBox1' is always assigned (either the control or null)

                comboBox1?.Focus();

                Debug.WriteLine("Attempted to set focus to ComboBox.");



            }

            else

            {

                // --- Logic for "Clear Inputs" when starting a new entry ---

                Debug.WriteLine("Button 2 (Clear Inputs) clicked!");



                Control foundSchoolYearControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear");

                if (foundSchoolYearControl is TextBox schoolYearTextBox) { schoolYearTextBox.Clear(); }

                else if (foundSchoolYearControl is ComboBox schoolYearComboBox) { schoolYearComboBox.SelectedIndex = -1; }



                Control foundSemesterControl = FindControlRecursive(this, "textBoxSemester") ?? FindControlRecursive(this, "comboBoxSemester");

                if (foundSemesterControl is TextBox semesterTextBox) { semesterTextBox.Clear(); }

                else if (foundSemesterControl is ComboBox semesterComboBox) { semesterComboBox.SelectedIndex = -1; }





                Control foundNumCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses");

                if (foundNumCoursesControl is NumericUpDown numUpDown) { numUpDown.Value = 1; } // Reset to default

                else if (foundNumCoursesControl is TextBox numCoursesTextBox) { numCoursesTextBox.Clear(); }





                // Set focus back to the first input field (School Year)

                Control firstInputControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear");

                firstInputControl?.Focus();

            }

        }



        // Back button (button3) click handler - This button should likely go back to the Dashboard.

        private void button3_Click(object sender, EventArgs e)

        {

            this.Hide(); // Hide the current form (selectcourse)

            if (dashboardForm != null)

            {

                dashboardForm.Show(); // Navigate back to the dashboard

            }

            else

            {

                // If there's no dashboard form reference, exiting might be the only option.

                MessageBox.Show("Dashboard form reference is missing. Cannot navigate back.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                Application.Exit(); // Or this.Close(); depending on desired behavior

            }

        }



        // --- Method to display received course data (Populate ComboBox, Labels, etc.) ---

        // This is called from Selectcourse_Load when the form receives data from selectterm.

        private void PopulateReceivedCourseData()

        {

            // Example: Update a label to show the selected term (Assuming a label named 'lblSelectedTerm')

            // This lblSelectedTerm now displays the Grading Term (Prelim/Midterm/Finals)

            Control lblTerm = FindControlRecursive(this, "lblSelectedTerm");

            if (lblTerm is Label lbl)

            {

                lbl.Text = $"Term Selected: {_selectedTerm}";

            }

            else { Debug.WriteLine("Warning: Control 'lblSelectedTerm' not found."); }





            // Example: Populate the ComboBox with course names/codes (Using your confirmed name: comboBox1)

            Control cmbCoursesControl = FindControlRecursive(this, "comboBox1"); // *** Explicitly using comboBox1 ***

            if (cmbCoursesControl is ComboBox comboBox1)

            {

                comboBox1.Items.Clear(); // Clear existing items



                if (_receivedCourses != null && _receivedCourses.Count > 0)

                {

                    // Add each course to the ComboBox

                    foreach (var course in _receivedCourses)

                    {

                        // You can customize the text shown in the dropdown here

                        // It's helpful if this text uniquely identifies the course

                        comboBox1.Items.Add($"{course.Code} - {course.Name}");



                        // OPTIONAL: If you want to store the *actual* CourseDetails object in the item

                        // (useful for easily retrieving details in SelectedIndexChanged without searching)

                        // (Requires setting DisplayMember on the ComboBox)

                        // comboBox1.Items.Add(course);

                    }

                    // Select the first item by default if available

                    if (comboBox1.Items.Count > 0)

                    {

                        comboBox1.SelectedIndex = 0;

                    }

                }

                else

                {

                    // Handle case where no courses were received

                    comboBox1.Items.Add("No courses available.");

                    comboBox1.Enabled = false; // Disable combobox if empty

                }

            }

            else

            {

                Debug.WriteLine("Warning: ComboBox control 'comboBox1' not found for displaying courses.");

                // Add a warning message or disable related controls if the ComboBox is missing

            }



            // Add logic here to populate other controls if you have them

            // (These would typically be updated in the SelectedIndexChanged event)



            // Ensure you have a button to proceed with the next step (e.g., entering grades)

            // This button would likely be handled by a separate click event handler (e.g., btnProcessGrades_Click).

        }



    }

}