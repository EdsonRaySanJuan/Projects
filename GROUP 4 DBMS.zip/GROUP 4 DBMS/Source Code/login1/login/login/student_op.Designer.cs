﻿namespace login
{
    partial class student_op
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtName = new TextBox();
            label6 = new Label();
            txtEmail = new TextBox();
            label7 = new Label();
            txtProgram = new TextBox();
            label8 = new Label();
            txtYearLevel = new TextBox();
            label9 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(33, 44);
            label1.Name = "label1";
            label1.Size = new Size(202, 27);
            label1.TabIndex = 0;
            label1.Text = "Student Details";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(153, 163);
            label3.Name = "label3";
            label3.Size = new Size(0, 15);
            label3.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(181, 198);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(183, 234);
            label5.Name = "label5";
            label5.Size = new Size(0, 15);
            label5.TabIndex = 4;
            // 
            // txtName
            // 
            txtName.BorderStyle = BorderStyle.None;
            txtName.Cursor = Cursors.IBeam;
            txtName.Location = new Point(33, 115);
            txtName.Multiline = true;
            txtName.Name = "txtName";
            txtName.Size = new Size(216, 28);
            txtName.TabIndex = 7;
            txtName.TextChanged += txtName_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.Location = new Point(33, 91);
            label6.Name = "label6";
            label6.Size = new Size(56, 21);
            label6.TabIndex = 6;
            label6.Text = "Name";
            label6.Click += label6_Click;
            // 
            // txtEmail
            // 
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.Cursor = Cursors.IBeam;
            txtEmail.Location = new Point(33, 181);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(216, 28);
            txtEmail.TabIndex = 9;
            txtEmail.TextChanged += txtEmail_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.Location = new Point(33, 157);
            label7.Name = "label7";
            label7.Size = new Size(117, 21);
            label7.TabIndex = 8;
            label7.Text = "Email Address";
            // 
            // txtProgram
            // 
            txtProgram.BorderStyle = BorderStyle.None;
            txtProgram.Cursor = Cursors.IBeam;
            txtProgram.Location = new Point(33, 252);
            txtProgram.Multiline = true;
            txtProgram.Name = "txtProgram";
            txtProgram.Size = new Size(216, 28);
            txtProgram.TabIndex = 11;
            txtProgram.TextChanged += txtProgram_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.Location = new Point(33, 228);
            label8.Name = "label8";
            label8.Size = new Size(76, 21);
            label8.TabIndex = 10;
            label8.Text = "Program";
            // 
            // txtYearLevel
            // 
            txtYearLevel.BorderStyle = BorderStyle.None;
            txtYearLevel.Cursor = Cursors.IBeam;
            txtYearLevel.Location = new Point(33, 324);
            txtYearLevel.Multiline = true;
            txtYearLevel.Name = "txtYearLevel";
            txtYearLevel.Size = new Size(216, 28);
            txtYearLevel.TabIndex = 13;
            txtYearLevel.TextChanged += txtYearLevel_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label9.Location = new Point(33, 300);
            label9.Name = "label9";
            label9.Size = new Size(87, 21);
            label9.TabIndex = 12;
            label9.Text = "Year Level";
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(33, 367);
            button1.Name = "button1";
            button1.Size = new Size(88, 47);
            button1.TabIndex = 14;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(161, 367);
            button2.Name = "button2";
            button2.Size = new Size(88, 47);
            button2.TabIndex = 15;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(12, 12);
            button3.Name = "button3";
            button3.Size = new Size(77, 29);
            button3.TabIndex = 16;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // student_op
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.th__1___4___1_;
            ClientSize = new Size(289, 444);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtYearLevel);
            Controls.Add(label9);
            Controls.Add(txtProgram);
            Controls.Add(label8);
            Controls.Add(txtEmail);
            Controls.Add(label7);
            Controls.Add(txtName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Name = "student_op";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "student_op";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtName;
        private Label label6;
        private TextBox txtEmail;
        private Label label7;
        private TextBox txtProgram;
        private Label label8;
        private TextBox txtYearLevel;
        private Label label9;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}