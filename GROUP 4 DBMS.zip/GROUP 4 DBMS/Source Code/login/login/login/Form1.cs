using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace login
{
    // Assuming your file is frmRegister.cs and class is frmRegister
    public partial class frmRegister : Form
    {
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // Make sure you have TextBoxes/Controls in your UI for Student Name, Email, Program, Year Level
        // and their names are, for example: txtStudentName, txtEmail, txtProgram, txtYearLevel
        // For this example, I've uncommented placeholders assuming they exist.
        // You need to change "txtStudentName", "txtEmail", etc. to the actual names of your controls.

        public frmRegister()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e) // Register button
        {
            // Add checks for all required fields
            // Make sure you have TextBoxes/Controls for Student Name, Email, Program, Year Level
            // and replace txtStudentName, txtEmail etc. with their actual names
            if (string.IsNullOrWhiteSpace(regisUN.Text) ||� � // Student ID
                string.IsNullOrWhiteSpace(regisPass.Text) ||
                string.IsNullOrWhiteSpace(regisConfPass.Text) ||
                // Uncomment and replace with your actual control names if these fields are required
                // string.IsNullOrWhiteSpace(txtStudentName.Text) ||
                // string.IsNullOrWhiteSpace(txtEmail.Text) ||
                // string.IsNullOrWhiteSpace(txtProgram.Text) || // Or check ComboBox selected value
                // string.IsNullOrWhiteSpace(txtYearLevel.Text) || // Or check ComboBox selected value
                false // Dummy condition to easily add/remove checks above
                )
            {
                MessageBox.Show("Please fill all required fields including Student ID, Password, Confirm Password, Name, Email, Program, and Year Level.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Find the first empty required field and focus it
                if (string.IsNullOrWhiteSpace(regisUN.Text)) regisUN.Focus();
                // else if (string.IsNullOrWhiteSpace(txtStudentName.Text)) txtStudentName.Focus(); // Example
                // else if (string.IsNullOrWhiteSpace(txtEmail.Text)) txtEmail.Focus(); // Example
                // else if (string.IsNullOrWhiteSpace(txtProgram.Text)) txtProgram.Focus(); // Example
                // else if (string.IsNullOrWhiteSpace(txtYearLevel.Text)) txtYearLevel.Focus(); // Example
                else if (string.IsNullOrWhiteSpace(regisPass.Text)) regisPass.Focus();
                else if (string.IsNullOrWhiteSpace(regisConfPass.Text)) regisConfPass.Focus();

                return;
            }

            if (regisPass.Text != regisConfPass.Text)
            {
                MessageBox.Show("Password and Confirm Password do not match.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                regisPass.Text = "";
                regisConfPass.Text = "";
                regisPass.Focus();
                return;
            }

            // Validate Student ID is numeric
            int studentIDNumeric;
            if (!int.TryParse(regisUN.Text, out studentIDNumeric))
            {
                MessageBox.Show("Student ID must be a numerical value.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                regisUN.Text = "";
                regisUN.Focus();
                return;
            }

            // --- Get values from your UI for other fields ---
            // REPLACE THESE PLACEHOLDERS WITH THE ACTUAL VALUES FROM YOUR TEXTBOXES/CONTROLS
            // Example:
            // string studentNameToInsert = txtStudentName.Text;
            // string emailToInsert = txtEmail.Text;
            // string programToInsert = txtProgram.Text; // or ComboBox.SelectedItem.ToString()
            // string yearLevelToInsert = txtYearLevel.Text; // or ComboBox.SelectedItem.ToString()

            // **IMPORTANT:** Replace these placeholder values with the actual data from your UI controls.
            string studentNameToInsert = "TODO: Replace with txtStudentName.Text";
            string emailToInsert = "TODO: Replace with txtEmail.Text";
            string programToInsert = "TODO: Replace with txtProgram.Text";
            string yearLevelToInsert = "TODO: Replace with txtYearLevel.Text";


            string registerQuery = @"INSERT INTO dbo.student�
                                     (studentID, student_name, email, program, year_level, password)�
                                   VALUES�
                                     (@StudentID, @StudentName, @Email, @Program, @YearLevel, @Password)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(registerQuery, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentIDNumeric); // Use parsed int
                    // **SECURITY WARNING:** Storing plain text passwords is NOT secure.
                    // You should HASH passwords before storing them in the database.
                    cmd.Parameters.AddWithValue("@Password", regisPass.Text);
                    cmd.Parameters.AddWithValue("@StudentName", studentNameToInsert);
                    cmd.Parameters.AddWithValue("@Email", emailToInsert);
                    cmd.Parameters.AddWithValue("@Program", programToInsert);
                    cmd.Parameters.AddWithValue("@YearLevel", yearLevelToInsert);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student Registration Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Debug.WriteLine($"Registration successful for Student ID: {regisUN.Text}, Name: {studentNameToInsert}");

                        // --- NAVIGATION CHANGE: Go to Login instead of Dashboard ---
                        // Open login form
                        frmLogin loginForm = new frmLogin();
                        loginForm.Show();

                        // Hide the current registration form
                        this.Hide();

                    }
                    catch (SqlException sqlEx)
                    {
                        Debug.WriteLine($"SQL Error during registration: {sqlEx.Message} (Number: {sqlEx.Number})");
                        if (sqlEx.Number == 2627) // Unique key violation (e.g., Student ID already exists)
                        {
                            MessageBox.Show("Registration failed. This Student ID already exists.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show($"Registration failed. Database Error: {sqlEx.Message}", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"General Error during registration: {ex.Message}");
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void regisShowPass_CheckedChanged(object sender, EventArgs e)
        {
            bool show = regisShowPass.Checked;
            regisPass.PasswordChar = show ? '\0' : '*';
            regisConfPass.PasswordChar = show ? '\0' : '*';
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            regisUN.Text = "";
            regisPass.Text = "";
            regisConfPass.Text = "";
            // TODO: Clear your new TextBoxes for student_name, email, etc. here
            // Example:
            // txtStudentName.Text = "";
            // txtEmail.Text = "";
            // txtProgram.Text = ""; // or ComboBox.SelectedIndex = -1;
            // txtYearLevel.Text = ""; // or ComboBox.SelectedIndex = -1;
            regisUN.Focus();
        }

        private void label6_Click(object sender, EventArgs e) // "Back to LOGIN" Link/Label
        {
            frmLogin loginForm = new frmLogin();
            loginForm.Show();
            this.Hide();
        }

        // Keep these if they are part of your designer generated code
        private void regisUN_TextChanged(object sender, EventArgs e)
        {
            // Placeholder
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {
            // Placeholder
        }
        // End of generated code placeholders
    }
}