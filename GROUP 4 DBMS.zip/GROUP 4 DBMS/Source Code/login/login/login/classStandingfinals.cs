﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // Added for Debug.WriteLine

// Assuming CourseDetails class is defined and accessible (e.g., in another file within the 'login' namespace)
/*
public class CourseDetails
{
    public string AcademicPeriodId { get; set; } // Example property
    public string Code { get; set; }
    public string Name { get; set; }
    public int Units { get; set; } // Example property
    public string SchoolYear { get; set; }
    public string Semester { get; set; }
    // Add any other properties that your CourseDetails class might have
}
*/

namespace login
{
    public partial class classStandingfinals : Form
    {
        // Fields to store received data and form references
        private CourseDetails _selectedCourse;
        private string _gradingTerm;     // Field to store the selected grading term (e.g., "Finals")
        private Form _selectCourseForm;  // Reference to the selectcourse form that opened this one
        private Form _dashboardForm;     // Reference to the Dashboard form

        const int MAX_INPUT_ROWS_PER_CATEGORY = 10;

        // Parameterized constructor - Preferred for creating the form
        public classStandingfinals(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard)
        {
            InitializeComponent();
            _selectedCourse = course;
            _gradingTerm = gradingTerm; // Should be "Finals" or similar for this class
            _selectCourseForm = selectCourseForm;
            _dashboardForm = dashboard;
            DisplayDetails(_selectedCourse, _gradingTerm);
            this.Load += (s, e) => Debug.WriteLine($"classStandingfinals form loaded for Term: {_gradingTerm}");
        }

        // Parameterless constructor - Primarily for the Windows Forms Designer
        public classStandingfinals()
        {
            InitializeComponent();
            _selectedCourse = null;
            _gradingTerm = "Finals"; // Default or indicate it's not fully initialized
            _selectCourseForm = null;
            _dashboardForm = null;
            this.Load += (s, e) => HandleParameterlessConstructorContext();
        }

        private void HandleParameterlessConstructorContext()
        {
            if (_selectedCourse == null || string.IsNullOrEmpty(_gradingTerm) || _selectCourseForm == null || _dashboardForm == null)
            {
                bool designMode = (this.Site != null && this.Site.DesignMode) || (this.Parent == null && System.Diagnostics.Process.GetCurrentProcess().ProcessName == "devenv");

                if (!designMode && (_selectedCourse == null || _selectCourseForm == null || _dashboardForm == null))
                {
                    MessageBox.Show("Warning: classStandingfinals form initialized without required data or form references. Calculations may not work.", "Initialization Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                Debug.WriteLine("Warning: classStandingfinals initialized without expected data (could be designer or actual issue).");

                Control submitButton = this.Controls.Find("button1", true).FirstOrDefault(); // Assuming submit button is still named "button1" in designer
                if (submitButton != null && _selectedCourse == null && !designMode) submitButton.Enabled = false;

                if (!designMode && _selectedCourse == null)
                {
                    DisplayDetails(null, _gradingTerm);
                }
            }
        }

        private void DisplayDetails(CourseDetails course, string gradingTerm)
        {
            Control lblTermControl = this.Controls.Find("label1", true).FirstOrDefault();
            if (lblTermControl is Label lblTerm) { lblTerm.Text = $"Term: {gradingTerm}"; }
            else if (lblTermControl is TextBox txtTerm) { txtTerm.Text = $"Term: {gradingTerm}"; }
            else { Debug.WriteLine("Warning: Control 'label1' (for Term) not found or not a Label/TextBox."); }

            Control lblAcademicPeriodControl = this.Controls.Find("lblAcademicPeriod", true).FirstOrDefault();
            if (lblAcademicPeriodControl is Label lblAP)
            {
                if (course != null) lblAP.Text = $"Academic Period: {course.Semester} ({course.SchoolYear})";
                else lblAP.Text = "Academic Period: N/A";
            }
            else { Debug.WriteLine("Warning: Control 'lblAcademicPeriod' not found or not a Label."); }

            if (course != null)
            {
                Control lblCourseControl = this.Controls.Find("label4", true).FirstOrDefault();
                if (lblCourseControl is Label lblCourse) { lblCourse.Text = $"{course.Name} ({course.Code})"; }
                else if (lblCourseControl is TextBox txtCourse) { txtCourse.Text = $"{course.Name} ({course.Code})"; }
                else { Debug.WriteLine("Warning: Control 'label4' (for Course) not found or not a Label/TextBox."); }
                Debug.WriteLine($"Displayed details for Course: {course.Code}, Term: {gradingTerm}");
            }
            else
            {
                Control lblCourseControl = this.Controls.Find("label4", true).FirstOrDefault();
                if (lblCourseControl is Label lblCourse) { lblCourse.Text = "Course: N/A"; }
                else if (lblCourseControl is TextBox txtCourse) { txtCourse.Text = "Course: N/A"; }
                Debug.WriteLine("DisplayDetails called with null course. Displaying N/A.");
            }
        }

        private double GetDoubleFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null)
            {
                Debug.WriteLine($"Warning: Textbox for {fieldName} is null.");
                return 0;
            }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }

            if (double.TryParse(textBox.Text.Trim(), out double value))
            {
                return value;
            }
            else
            {
                MessageBox.Show($"Invalid input for {fieldName}: '{textBox.Text}'. Please enter a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus();
                return double.NaN;
            }
        }

        private int GetIntFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null)
            {
                Debug.WriteLine($"Warning: Textbox for {fieldName} is null.");
                return 0;
            }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }

            if (int.TryParse(textBox.Text.Trim(), out int value))
            {
                return value;
            }
            else
            {
                MessageBox.Show($"Invalid input for {fieldName}: '{textBox.Text}'. Please enter a whole number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus();
                return -1;
            }
        }

        private double ProcessCategory(string categoryName)
        {
            List<double> itemScoresAsPercentages = new List<double>();
            for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
            {
                Control scoreControl = this.Controls.Find($"txt{categoryName}Score{i}", true).FirstOrDefault();
                if (scoreControl == null)
                {
                    if (i == 1) { Debug.WriteLine($"Warning: No input control found for {categoryName} item {i} (expected txt{categoryName}Score{i}). Assuming no items or skipping category if this is the first item."); }
                    else { Debug.WriteLine($"No more score controls found for {categoryName} starting from item {i}."); }
                    break;
                }

                TextBox scoreTextBox = scoreControl as TextBox;
                if (scoreTextBox == null)
                {
                    Debug.WriteLine($"Warning: Control found for {categoryName} item {i} (txt{categoryName}Score{i}) is not a TextBox.");
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(scoreTextBox.Text))
                {
                    double scoreAsPercentage = GetDoubleFromTextBox(scoreTextBox, $"{categoryName} Score {i}");
                    if (double.IsNaN(scoreAsPercentage)) { return double.NaN; }

                    if (scoreAsPercentage < 0 || scoreAsPercentage > 100)
                    {
                        MessageBox.Show($"Score ({scoreAsPercentage}%) for {categoryName} item {i} must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        scoreTextBox.Focus();
                        return double.NaN;
                    }
                    itemScoresAsPercentages.Add(scoreAsPercentage);
                    Debug.WriteLine($"Read {scoreAsPercentage:F2}% for {categoryName} item {i}. Total items read for {categoryName}: {itemScoresAsPercentages.Count}");
                }
                else
                {
                    Debug.WriteLine($"Skipping empty score input for {categoryName} item {i}.");
                }
            }

            double overallAverage = 0;
            if (itemScoresAsPercentages.Count > 0)
            {
                overallAverage = itemScoresAsPercentages.Sum() / itemScoresAsPercentages.Count;
            }
            else
            {
                Debug.WriteLine($"No valid score items entered for {categoryName}. Average percentage for this category is 0.");
            }

            Control finalPercentageControl = this.Controls.Find($"txt{categoryName}FinalPercentage", true).FirstOrDefault();
            if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Text = overallAverage.ToString("F2") + "%"; }
            else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = overallAverage.ToString("F2") + "%"; }
            else { Debug.WriteLine($"Warning: Final Percentage display control for {categoryName} (e.g., txt{categoryName}FinalPercentage) not found."); }

            Control weightControl = this.Controls.Find($"txt{categoryName}Weight", true).FirstOrDefault();
            double weightPercentage = 0;
            if (weightControl is TextBox weightTextBox)
            {
                if (!string.IsNullOrWhiteSpace(weightTextBox.Text))
                {
                    weightPercentage = GetDoubleFromTextBox(weightTextBox, $"{categoryName} Weight");
                    if (double.IsNaN(weightPercentage)) { return double.NaN; }

                    if (weightPercentage < 0 || weightPercentage > 100)
                    {
                        MessageBox.Show($"Weight for {categoryName} must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        weightTextBox.Focus();
                        return double.NaN;
                    }
                }
                else
                {
                    Debug.WriteLine($"Weight for {categoryName} is not entered. Assuming 0% weight for this category.");
                }
            }
            else
            {
                Debug.WriteLine($"Warning: Weight control for {categoryName} (txt{categoryName}Weight) not found. Assuming weight 0.");
            }

            double weightedContribution = overallAverage * (weightPercentage / 100.0);

            Control weightedContributionControl = this.Controls.Find($"txt{categoryName}WeightedContribution", true).FirstOrDefault();
            if (weightedContributionControl is TextBox txtWeightedContribution) { txtWeightedContribution.Text = weightedContribution.ToString("F2"); }
            else if (weightedContributionControl is Label lblWeightedContribution) { lblWeightedContribution.Text = weightedContribution.ToString("F2"); }
            else { Debug.WriteLine($"Warning: Weighted Contribution display control for {categoryName} (e.g., txt{categoryName}WeightedContribution) not found."); }

            Debug.WriteLine($"Category: {categoryName}, Items: {itemScoresAsPercentages.Count}, Average: {overallAverage:F2}%, Weight: {weightPercentage:F2}%, Contribution: {weightedContribution:F2}%");
            return weightedContribution;
        }

        private double CalculateOverallClassStanding()
        {
            double totalClassStandingContribution = 0;
            double totalWeightSum = 0;
            bool calculationFailed = false;

            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };

            foreach (string category in categories)
            {
                double categoryContribution = ProcessCategory(category);
                if (double.IsNaN(categoryContribution))
                {
                    calculationFailed = true;
                    break;
                }
                totalClassStandingContribution += categoryContribution;

                Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                if (weightControl is TextBox weightTextBox)
                {
                    double weightVal = 0;
                    if (!string.IsNullOrWhiteSpace(weightTextBox.Text))
                    {
                        weightVal = GetDoubleFromTextBox(weightTextBox, $"{category} Weight (for sum check)");
                        if (double.IsNaN(weightVal) || weightVal < 0 || weightVal > 100)
                        {
                            calculationFailed = true;
                            break;
                        }
                    }
                    totalWeightSum += weightVal;
                }
                else
                {
                    Debug.WriteLine($"Warning: Weight TextBox for category '{category}' not found during total weight sum. Assuming 0 for this category in sum.");
                }
            }

            if (calculationFailed)
            {
                Control resultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();
                if (resultControl is TextBox txtResult) txtResult.Text = "Error";
                else if (resultControl is Label lblResult) lblResult.Text = "Error in calculation";
                return double.NaN;
            }

            bool anyWeightEntered = categories.Any(cat => {
                Control wc = this.Controls.Find($"txt{cat}Weight", true).FirstOrDefault();
                return (wc is TextBox wtb) && !string.IsNullOrWhiteSpace(wtb.Text) && GetDoubleFromTextBox(wtb, "temp") > 0;
            });

            if (anyWeightEntered && Math.Abs(totalWeightSum - 100.0) > 0.01)
            {
                MessageBox.Show($"The total weight of all categories must add up to 100% if any weights are specified. Current total weight: {totalWeightSum:F2}%", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return double.NaN;
            }
            else if (!anyWeightEntered && totalClassStandingContribution > 0.001)
            {
                MessageBox.Show($"Scores have been entered, but no category weights are specified. The class standing cannot be calculated meaningfully. Please enter weights for each category.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return double.NaN;
            }
            else if (!anyWeightEntered && Math.Abs(totalClassStandingContribution) < 0.001)
            {
                Debug.WriteLine("No scores or weights entered. Class standing is 0.");
            }
            return totalClassStandingContribution;
        }

        // Back Button (assuming name "button3" or similar from reference)
        // If your back button has a different name like "button3_Click_1", you'll need to rename this method
        // or ensure the designer links to this one.
        private void button3_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Back button clicked from classStandingfinals.");
            this.Hide();
            if (_selectCourseForm != null && !_selectCourseForm.IsDisposed)
            {
                _selectCourseForm.Show();
            }
            else if (_dashboardForm != null && !_dashboardForm.IsDisposed)
            {
                _dashboardForm.Show();
            }
            else
            {
                MessageBox.Show("Cannot navigate back. Previous form references are missing or disposed.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // --- User Provided Button Click Handlers ---

        // submit button (Calculates Class Standing)
        private void button1_Click_1(object sender, EventArgs e)
        {
            Debug.WriteLine("Submit button (button1_Click_1) clicked.");
            if (_selectedCourse == null)
            {
                MessageBox.Show("Cannot calculate class standing. Course details are missing. Please select a course first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double finalClassStanding = CalculateOverallClassStanding();

            Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();
            if (classStandingResultControl == null)
            {
                Debug.WriteLine("Warning: Result display control (e.g., txtClassStandingResult) not found.");
                if (!double.IsNaN(finalClassStanding))
                {
                    MessageBox.Show($"Calculated Class Standing for {_gradingTerm}: {finalClassStanding:F2}%", "Class Standing Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }

            if (!double.IsNaN(finalClassStanding))
            {
                if (classStandingResultControl is TextBox txtResult) { txtResult.Text = finalClassStanding.ToString("F2") + "%"; }
                else if (classStandingResultControl is Label lblResult) { lblResult.Text = $"Class Standing: {finalClassStanding:F2}%"; }
                Debug.WriteLine($"Successfully calculated Class Standing: {finalClassStanding:F2}% for course {_selectedCourse.Code} ({_selectedCourse.Name}), Term: {_gradingTerm}");

                DialogResult proceedToExam = MessageBox.Show($"Class Standing calculation for {_gradingTerm} complete: {finalClassStanding:F2}%\n\nDo you want to proceed to Exam calculation (if applicable)?", "Next Step", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (proceedToExam == DialogResult.Yes)
                {
                    MessageBox.Show("Exam calculation functionality would be invoked here.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                if (classStandingResultControl is TextBox txtResult) { txtResult.Text = "Error"; }
                else if (classStandingResultControl is Label lblResult) { lblResult.Text = "Class Standing: Error"; }
                Debug.WriteLine("Calculation resulted in NaN. Check previous debug messages for specific input errors.");
            }
        }

        // clear button
        private void button2_Click_1(object sender, EventArgs e)
        {
            Debug.WriteLine("Clear button (button2_Click_1) clicked.");
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };

            foreach (string category in categories)
            {
                for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
                {
                    Control scoreControl = this.Controls.Find($"txt{category}Score{i}", true).FirstOrDefault();
                    if (scoreControl is TextBox scoreTextBox) { scoreTextBox.Clear(); }
                }

                Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                if (weightControl is TextBox weightTextBox) { weightTextBox.Clear(); }

                Control finalPercentageControl = this.Controls.Find($"txt{category}FinalPercentage", true).FirstOrDefault();
                if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Clear(); }
                else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = string.Empty; }

                Control weightedContributionControl = this.Controls.Find($"txt{category}WeightedContribution", true).FirstOrDefault();
                if (weightedContributionControl is TextBox txtWeightedContribution) { txtWeightedContribution.Clear(); }
                else if (weightedContributionControl is Label lblWeightedContribution) { lblWeightedContribution.Text = string.Empty; }
            }

            Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();
            if (classStandingResultControl is TextBox txtClassStandingResult) { txtClassStandingResult.Clear(); }
            else if (classStandingResultControl is Label lblClassStandingResult) { lblClassStandingResult.Text = "Class Standing:"; }

            Control firstInput = this.Controls.Find("txtQuizScore1", true).FirstOrDefault();
            firstInput?.Focus();
            Debug.WriteLine("All input and result fields cleared via button2_Click_1.");
        }

        // --- Existing Empty TextChanged Event Handlers ---
        // quiz weight percentage
        private void txtQuizWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtAssignmentWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtSeatworkWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtLaboratoryWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtRecitationWeight_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }

        // quiz score textboxes 1-10
        private void txtQuizScore1_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        private void txtQuizScore2_TextChanged(object sender, EventArgs e) { /* Optional: Live validation/formatting */ }
        // ... (all other score TextChanged handlers remain empty as before) ...
        private void txtQuizScore3_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore4_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore5_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore6_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore7_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore8_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore9_TextChanged(object sender, EventArgs e) { }
        private void txtQuizScore10_TextChanged(object sender, EventArgs e) { }

        private void txtAssignmentScore1_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore2_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore3_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore4_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore5_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore6_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore7_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore8_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore9_TextChanged(object sender, EventArgs e) { }
        private void txtAssignmentScore10_TextChanged(object sender, EventArgs e) { }

        private void txtSeatworkScore1_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore2_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore3_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore4_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore5_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore6_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore7_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore8_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore9_TextChanged(object sender, EventArgs e) { }
        private void txtSeatworkScore10_TextChanged(object sender, EventArgs e) { }

        private void txtLaboratoryScore1_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore2_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore3_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore4_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore5_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore6_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore7_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore8_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore9_TextChanged(object sender, EventArgs e) { }
        private void txtLaboratoryScore10_TextChanged(object sender, EventArgs e) { }

        private void txtRecitationScore1_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore2_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore3_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore4_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore5_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore6_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore7_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore8_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore9_TextChanged(object sender, EventArgs e) { }
        private void txtRecitationScore10_TextChanged(object sender, EventArgs e) { }
    }
}