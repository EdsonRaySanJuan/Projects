﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // Required for SQL Server interaction

namespace login
{
    public partial class student_op : Form
    {
        // Define the connection string for your SQL Server database
        // Make sure this matches your server name, database name, and credentials
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // Field to hold the reference to the previous form (the form that opened this one)
        private Form previousForm;

        // Constructor that accepts a reference to the calling form
        // Use this constructor when navigating from another form (like Dashboard)
        public student_op(Form callingForm)
        {
            InitializeComponent();
            // Store the reference to the calling form
            this.previousForm = callingForm;

            // Optional: You can set initial focus when the form loads
            this.Load += Student_op_Load;
        }

        // Keep the parameterless constructor if it's needed elsewhere (e.g., by the designer)
        // If you only ever open this form *from* another form, you could potentially remove this.
        public student_op()
        {
             InitializeComponent();
             this.Load += Student_op_Load;
             // previousForm will be null if this constructor is used directly
        }


        // Optional: Set initial focus when the form loads
        private void Student_op_Load(object sender, EventArgs e)
        {
            // Assuming txtStudentNumber is the name of the text box for Student Number
            // Make sure 'txtStudentNumber' is the correct name of your textbox in the designer.
            txtStudentNumber.Focus();
        }

        // This is the CORRECT event handler for your Submit button (button1)
        // based on the comment "//submit btn" in your code.
        private void button1_Click(object sender, EventArgs e)
        {
             // Get data from text boxes
            // Assuming the text box names are:
            // txtStudentNumber, txtName, txtEmail, txtProgram, txtYearLevel
            // Make sure these names match the actual names of your text boxes in the designer.

            // Validate and get Student ID
            int studentID;
            if (string.IsNullOrWhiteSpace(txtStudentNumber.Text) || !int.TryParse(txtStudentNumber.Text, out studentID))
            {
                MessageBox.Show("Please enter a valid Student Number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStudentNumber.Focus();
                return; // Stop the process if student number is invalid
            }

            string studentName = txtName.Text.Trim(); // Trim whitespace
            // Get email from txtEmail
            string email = txtEmail.Text.Trim();
            string program = txtProgram.Text.Trim();
            string yearLevel = txtYearLevel.Text.Trim();

            // Basic validation for other fields (optional but recommended)
            if (string.IsNullOrWhiteSpace(studentName) || string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(program) || string.IsNullOrWhiteSpace(yearLevel))
            {
                MessageBox.Show("Please fill in all fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // You could set focus to the first empty field here if needed
                return;
            }

            // SQL INSERT statement with parameters to prevent SQL injection
            string insertQuery = "INSERT INTO student (studentID, student_name, email, program, year_level) " +
                                 "VALUES (@studentID, @studentName, @email, @program, @yearLevel)";

            // Use 'using' statements to ensure resources are closed and disposed
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    // Add parameters to the command
                    cmd.Parameters.AddWithValue("@studentID", studentID);
                    cmd.Parameters.AddWithValue("@studentName", studentName);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@program", program);
                    cmd.Parameters.AddWithValue("@yearLevel", yearLevel);

                    try
                    {
                        con.Open(); // Open the database connection
                        int rowsAffected = cmd.ExecuteNonQuery(); // Execute the INSERT command

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Student details saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Optionally clear the form after successful submission
                            button2_Click(null, null); // Call the clear button's click event (button2_Click)
                        }
                        else
                        {
                            MessageBox.Show("Failed to save student details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (SqlException ex)
                    {
                        // Handle specific SQL errors (e.g., primary key violation)
                        if (ex.Number == 2627) // SQL Server error code for primary key violation
                        {
                            MessageBox.Show("Error: Student Number already exists.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtStudentNumber.Focus(); // Set focus back to Student Number
                        }
                        else
                        {
                            MessageBox.Show("A database error occurred: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle any other unexpected errors
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                } // SqlCommand is disposed here
            } // SqlConnection is disposed here
        }

         // This is the CORRECT event handler for your Clear button (button2)
        // based on the comment "//clear btn" in your code.
        private void button2_Click(object sender, EventArgs e)
        {
            // Clear the text from all input fields
            // Make sure txtName, txtEmail, txtProgram, txtYearLevel are correct textbox names
            txtStudentNumber.Clear();
            txtName.Clear();
            txtEmail.Clear();
            txtProgram.Clear();
            txtYearLevel.Clear();

            // Set focus back to the first input field
            txtStudentNumber.Focus();
        }


        // This is the empty event handler you had in your original code (for label6)
        private void label6_Click(object sender, EventArgs e)
        {
            // Your code for label6 click goes here (if any)
        }

        // This is the CORRECT event handler for your Back button (button3)
        // based on the comment "// back btn" in your code.
        private void button3_Click(object sender, EventArgs e)
        {
            // Hide the current form (student_op)
            this.Hide();

            // Show the previous form if the reference exists
            if (previousForm != null)
            {
                previousForm.Show();
            }
            else
            {
                 // Optional: If previousForm is null (e.g., form was opened directly),
                 // you might want to handle this case - maybe close the application or go to a main menu.
                 MessageBox.Show("Cannot go back. The previous form reference was not set.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 this.Close(); // Close this form if we can't go back
            }
        }

        // The empty btnSubmit_Click and btnClear_Click methods are removed
        // as button1_Click and button2_Click are the actual handlers.

        // You might have other methods related to the form's design or other controls
        // These would also be part of the full code.
    }
}