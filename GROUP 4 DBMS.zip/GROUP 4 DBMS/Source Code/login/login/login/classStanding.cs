﻿// classStanding.cs - Integrated version with Term display, Calculation, and support for Multiple Percentage Inputs per Category

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // Added for Debug.WriteLine

// Ensure CourseDetails class is accessible (defined elsewhere, e.g., CourseDetails.cs)
// It must have properties: AcademicPeriodId, Code, Name, Units, SchoolYear, Semester
// using login; // If CourseDetails is in the login namespace but a different file

namespace login
{
    public partial class classStanding : Form
    {
        // Fields to store received data and form references
        private CourseDetails _selectedCourse;
        private string _gradingTerm;      // Field to store the selected grading term (Prelim/Midterm/Finals)
        private Form _selectCourseForm;   // Reference to the selectcourse form that opened this one
        private Form _dashboardForm;      // Reference to the Dashboard form

        const int MAX_INPUT_ROWS_PER_CATEGORY = 10;

        public classStanding(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard)
        {
            InitializeComponent();
            _selectedCourse = course;
            _gradingTerm = gradingTerm;
            _selectCourseForm = selectCourseForm;
            _dashboardForm = dashboard;
            DisplayDetails(_selectedCourse, _gradingTerm);
        }

        public classStanding()
        {
            InitializeComponent();
            _selectedCourse = null;
            _gradingTerm = string.Empty;
            _selectCourseForm = null;
            _dashboardForm = null;
            this.Load += (s, e) => HandleParameterlessConstructorContext();
        }

        private void HandleParameterlessConstructorContext()
        {
            if (_selectedCourse == null || string.IsNullOrEmpty(_gradingTerm) || _selectCourseForm == null || _dashboardForm == null)
            {
                MessageBox.Show("Warning: classStanding form initialized without required data or form references.", "Initialization Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Debug.WriteLine("Warning: classStanding initialized without expected data.");
                Control submitButton = this.Controls.Find("button1", true).FirstOrDefault();
                if (submitButton != null) submitButton.Enabled = false;
            }
        }

        private void DisplayDetails(CourseDetails course, string gradingTerm)
        {
            Control lblTermControl = this.Controls.Find("label1", true).FirstOrDefault();
            if (lblTermControl is Label lblTerm) { lblTerm.Text = $"Term: {gradingTerm}"; }
            else if (lblTermControl is TextBox txtTerm) { txtTerm.Text = $"Term: {gradingTerm}"; }
            else { Debug.WriteLine("Warning: Control 'label1' not found for Term."); }

            Control lblAcademicPeriodControl = this.Controls.Find("lblAcademicPeriod", true).FirstOrDefault();
            if (lblAcademicPeriodControl is Label lblAP)
            {
                if (course != null) lblAP.Text = $"Academic Period: {course.Semester} ({course.SchoolYear})";
                else lblAP.Text = "Academic Period: N/A";
            }
            else { Debug.WriteLine("Warning: Control 'lblAcademicPeriod' not found."); }

            if (course != null)
            {
                Control lblCourseControl = this.Controls.Find("label4", true).FirstOrDefault();
                if (lblCourseControl is Label lblCourse) { lblCourse.Text = $"{course.Name} ({course.Code})"; }
                else if (lblCourseControl is TextBox txtCourse) { txtCourse.Text = $"{course.Name} ({course.Code})"; }
                else { Debug.WriteLine("Warning: Control 'label4' not found for Course."); }
                Debug.WriteLine($"Displayed details for Course: {course.Code}, Term: {gradingTerm}");
            }
            else
            {
                MessageBox.Show("No course details received.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine("Error: DisplayDetails called with null course.");
            }
        }

        private double GetDoubleFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null)
            {
                Debug.WriteLine($"Warning: Textbox for {fieldName} is null.");
                return 0;
            }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }
            if (double.TryParse(textBox.Text.Trim(), out double value)) { return value; }
            else
            {
                MessageBox.Show($"Invalid input for {fieldName}. Please enter a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus();
                return double.NaN;
            }
        }

        private int GetIntFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null)
            {
                Debug.WriteLine($"Warning: Textbox for {fieldName} is null.");
                return 0;
            }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }
            if (int.TryParse(textBox.Text.Trim(), out int value)) { return value; }
            else
            {
                MessageBox.Show($"Invalid input for {fieldName}. Please enter an integer.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus();
                return -1;
            }
        }

        private double ProcessCategory(string categoryName)
        {
            List<double> itemScoresAsPercentages = new List<double>();
            for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
            {
                Control scoreControl = this.Controls.Find($"txt{categoryName}Score{i}", true).FirstOrDefault();
                if (scoreControl == null)
                {
                    if (i == 1) { Debug.WriteLine($"Warning: No input control found for {categoryName} item {i} (expected txt{categoryName}Score{i}). Assuming no items or skipping category."); }
                    else { Debug.WriteLine($"No more controls found for {categoryName} starting from item {i}. Stopping loop for this category."); break; }
                    continue;
                }
                TextBox scoreTextBox = scoreControl as TextBox;
                if (scoreTextBox == null) { Debug.WriteLine($"Warning: Control found for {categoryName} item {i} (txt{categoryName}Score{i}) is not a TextBox."); continue; }
                double scoreAsPercentage = GetDoubleFromTextBox(scoreTextBox, $"{categoryName} Score {i}");
                if (double.IsNaN(scoreAsPercentage)) { return double.NaN; }
                if (scoreAsPercentage < 0 || scoreAsPercentage > 100)
                {
                    MessageBox.Show($"Score ({scoreAsPercentage}%) for {categoryName} item {i} must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scoreTextBox.Focus(); return double.NaN;
                }
                if (scoreAsPercentage > 0 || (!string.IsNullOrWhiteSpace(scoreTextBox.Text) && scoreAsPercentage == 0))
                { itemScoresAsPercentages.Add(scoreAsPercentage); Debug.WriteLine($"Read {scoreAsPercentage:F2}% for {categoryName} item {i}. Total items read so far: {itemScoresAsPercentages.Count}"); }
                else { Debug.WriteLine($"Skipping empty score input for {categoryName} item {i}."); }
            }
            double overallAverage = 0;
            if (itemScoresAsPercentages.Count > 0)
            {
                overallAverage = itemScoresAsPercentages.Sum() / itemScoresAsPercentages.Count;
                Control finalPercentageControl = this.Controls.Find($"txt{categoryName}FinalPercentage", true).FirstOrDefault();
                if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Text = overallAverage.ToString("F2") + "%"; }
                else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = overallAverage.ToString("F2") + "%"; }
                else { Debug.WriteLine($"Warning: Final Percentage control for {categoryName} (txt{categoryName}FinalPercentage) not found."); }
            }
            else
            {
                Debug.WriteLine($"No valid score items entered for {categoryName}. Average percentage is 0.");
                Control finalPercentageControl = this.Controls.Find($"txt{categoryName}FinalPercentage", true).FirstOrDefault();
                if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Clear(); }
                else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = string.Empty; }
            }
            Control weightControl = this.Controls.Find($"txt{categoryName}Weight", true).FirstOrDefault();
            double weightPercentage = 0;
            if (weightControl is TextBox weightTextBox)
            {
                weightPercentage = GetDoubleFromTextBox(weightTextBox, $"{categoryName} Weight");
                if (double.IsNaN(weightPercentage)) { return double.NaN; }
                if (weightPercentage < 0 || weightPercentage > 100)
                { MessageBox.Show($"Weight for {categoryName} must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error); weightTextBox.Focus(); return double.NaN; }
            }
            else { Debug.WriteLine($"Warning: Weight control for {categoryName} (txt{categoryName}Weight) not found. Assuming weight 0."); }
            double weightedContribution = overallAverage * (weightPercentage / 100.0);
            Control weightedContributionControl = this.Controls.Find($"txt{categoryName}WeightedContribution", true).FirstOrDefault();
            if (weightedContributionControl is TextBox txtWeightedContribution) { txtWeightedContribution.Text = weightedContribution.ToString("F2"); }
            else if (weightedContributionControl is Label lblWeightedContribution) { lblWeightedContribution.Text = weightedContribution.ToString("F2"); }
            else { Debug.WriteLine($"Warning: Weighted Contribution control for {categoryName} (txt{categoryName}WeightedContribution) not found."); }
            Debug.WriteLine($"Category: {categoryName}, Average: {overallAverage:F2}%, Weight: {weightPercentage:F2}%, Contribution: {weightedContribution:F2}%");
            return double.IsNaN(weightPercentage) ? double.NaN : weightedContribution;
        }

        private double CalculateOverallClassStanding()
        {
            double totalClassStanding = 0;
            double totalWeightSum = 0;
            bool calculationFailed = false;
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };
            foreach (string category in categories)
            {
                double categoryContribution = ProcessCategory(category);
                if (double.IsNaN(categoryContribution)) { calculationFailed = true; }
                else { totalClassStanding += categoryContribution; }
                if (!calculationFailed)
                {
                    Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                    if (weightControl is TextBox weightTextBox)
                    {
                        if (double.TryParse(weightTextBox.Text.Trim(), out double weightValue))
                        { if (weightValue >= 0 && weightValue <= 100) { totalWeightSum += weightValue; } }
                    }
                }
            }
            if (calculationFailed) { return double.NaN; }
            totalWeightSum = 0; // Recalculate accurately for final check
            foreach (string category in categories)
            {
                Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                if (weightControl is TextBox weightTextBox)
                {
                    double weight = GetDoubleFromTextBox(weightTextBox, $"{category} Weight (for total sum check)");
                    if (double.IsNaN(weight)) { calculationFailed = true; break; }
                    totalWeightSum += weight;
                }
            }
            if (calculationFailed) { return double.NaN; }
            if (categories.Length > 0 && Math.Abs(totalWeightSum - 100.0) > 0.01)
            { MessageBox.Show($"The total weight of all categories must add up to 100%. Current total weight: {totalWeightSum:F2}%", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return double.NaN; }
            else if (categories.Length > 0 && totalWeightSum < 0.01 && totalClassStanding > 0.01)
            { Debug.WriteLine("Warning: Total weight is zero or negligible, but class standing has a value."); }
            return totalClassStanding;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Calculate CS button clicked.");
            if (_selectedCourse == null || string.IsNullOrEmpty(_gradingTerm))
            { MessageBox.Show("Cannot calculate class standing. Course details or grading term are missing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            double calculatedClassStanding = CalculateOverallClassStanding();
            if (!double.IsNaN(calculatedClassStanding))
            {
                Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();
                if (classStandingResultControl is TextBox txtClassStandingResult) { txtClassStandingResult.Text = calculatedClassStanding.ToString("F2") + "%"; }
                else if (classStandingResultControl is Label lblClassStandingResult) { lblClassStandingResult.Text = $"Calculated Class Standing: {calculatedClassStanding:F2}%"; }
                else { MessageBox.Show($"Calculated Class Standing: {calculatedClassStanding:F2}%", "Class Standing Result", MessageBoxButtons.OK, MessageBoxIcon.Information); Debug.WriteLine("Warning: Result display control (txtClassStandingResult) not found."); }
                Debug.WriteLine($"Calculated Class Standing: {calculatedClassStanding:F2}% for course {_selectedCourse.Code} ({_selectedCourse.Name}) Term: {_gradingTerm}");
                DialogResult proceedToExam = MessageBox.Show("Class Standing calculation complete. Do you want to proceed to Exam calculation?", "Next Step", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (proceedToExam == DialogResult.Yes) { MessageBox.Show("Exam calculation functionality is not yet available.", "Information"); }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Back button clicked from classStanding.");
            this.Hide();
            if (_selectCourseForm != null) { _selectCourseForm.Show(); }
            else if (_dashboardForm != null) { _dashboardForm.Show(); }
            else { MessageBox.Show("Cannot navigate back. Previous form references are missing.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e) { }
        private void classStanding_Load(object sender, EventArgs e) { Debug.WriteLine("classStanding form loaded."); }
        private void label1_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }

        // --- NEW TextChanged Event Handlers (as provided by user) ---
        // IMPORTANT: These methods are now defined.
        // YOU MUST manually connect these to the TextChanged event of the
        // corresponding TextBox controls in the Visual Studio Form Designer.
        // For example, for txtQuizScore1, assign its TextChanged event to textBox1_TextChanged_1.
        // For txtQuizScore2, assign its TextChanged event to textBox2_TextChanged_1, and so on.

        // quiz1 item textbox
        private void textBox1_TextChanged_1(object sender, EventArgs e) { }
        // quiz2 item textbox
        private void textBox2_TextChanged_1(object sender, EventArgs e) { }
        // quiz3 item textbox
        private void textBox3_TextChanged_1(object sender, EventArgs e) { }
        // quiz4 item textbox
        private void textBox4_TextChanged_1(object sender, EventArgs e) { }
        // quiz5 item textbox
        private void textBox5_TextChanged_1(object sender, EventArgs e) { }
        // quiz6 item textbox
        private void textBox6_TextChanged_1(object sender, EventArgs e) { }
        // quiz7 item textbox
        private void textBox7_TextChanged_1(object sender, EventArgs e) { }
        // quiz8 item textbox
        private void textBox8_TextChanged_1(object sender, EventArgs e) { }
        // quiz9 item textbox
        private void textBox9_TextChanged_1(object sender, EventArgs e) { }
        // quiz10 item textbox
        private void textBox10_TextChanged_1(object sender, EventArgs e) { }
        // assignment1 item textbox
        private void textBox11_TextChanged_1(object sender, EventArgs e) { }
        // assignment2 item textbox
        private void textBox12_TextChanged_1(object sender, EventArgs e) { }
        // assignment3 item textbox
        private void textBox13_TextChanged_1(object sender, EventArgs e) { }
        // assignment4 item textbox
        private void textBox14_TextChanged_1(object sender, EventArgs e) { }
        // assignment5 item textbox
        private void textBox15_TextChanged_1(object sender, EventArgs e) { }
        // assignment6 item textbox
        private void textBox16_TextChanged_1(object sender, EventArgs e) { }
        // assignment7 item textbox
        private void textBox17_TextChanged_1(object sender, EventArgs e) { }
        // assignment8 item textbox
        private void textBox18_TextChanged_1(object sender, EventArgs e) { }
        // assignment9 item textbox
        private void textBox19_TextChanged_1(object sender, EventArgs e) { }
        // assignment10 item textbox
        private void textBox20_TextChanged_1(object sender, EventArgs e) { }
        // seatwork1 textbox
        private void textBox21_TextChanged_1(object sender, EventArgs e) { }
        // seatwork2 textbox
        private void textBox22_TextChanged_1(object sender, EventArgs e) { }
        // seatwork3 textbox
        private void textBox23_TextChanged_1(object sender, EventArgs e) { }
        // seatwork4 textbox
        private void textBox24_TextChanged_1(object sender, EventArgs e) { }
        // seatwork5 textbox
        private void textBox25_TextChanged_1(object sender, EventArgs e) { }
        // seatwork6 textbox
        private void textBox26_TextChanged_1(object sender, EventArgs e) { }
        // seatwork7 textbox
        private void textBox27_TextChanged_1(object sender, EventArgs e) { }
        // seatwork8 textbox
        private void textBox28_TextChanged_1(object sender, EventArgs e) { }
        // seatwork9 textbox
        private void textBox29_TextChanged_1(object sender, EventArgs e) { }
        // seatwork10 textbox
        private void textBox30_TextChanged_1(object sender, EventArgs e) { }
        // laboratory1 textbox
        private void textBox31_TextChanged_1(object sender, EventArgs e) { }
        // laboratory2 textbox
        private void textBox32_TextChanged_1(object sender, EventArgs e) { }
        // laboratory3 textbox
        private void textBox33_TextChanged_1(object sender, EventArgs e) { }
        // laboratory4 textbox
        private void textBox34_TextChanged_1(object sender, EventArgs e) { }
        // laboratory5 textbox
        private void textBox35_TextChanged_1(object sender, EventArgs e) { }
        // laboratory6 textbox
        private void textBox36_TextChanged_1(object sender, EventArgs e) { }
        // laboratory7 textbox
        private void textBox37_TextChanged_1(object sender, EventArgs e) { }
        // laboratory8 textbox
        private void textBox38_TextChanged_1(object sender, EventArgs e) { }
        // laboratory9 textbox
        private void textBox39_TextChanged_1(object sender, EventArgs e) { }
        // laboratory10 textbox
        private void textBox40_TextChanged_1(object sender, EventArgs e) { }
        // recitation1 textbox
        private void textBox41_TextChanged_1(object sender, EventArgs e) { }
        // recitation2 textbox
        private void textBox42_TextChanged_1(object sender, EventArgs e) { }
        // recitation3 textbox
        private void textBox43_TextChanged_1(object sender, EventArgs e) { }
        // recitation4 textbox
        private void textBox44_TextChanged_1(object sender, EventArgs e) { }
        // recitation5 textbox
        private void textBox45_TextChanged_1(object sender, EventArgs e) { }
        // recitation6 textbox
        private void textBox46_TextChanged_1(object sender, EventArgs e) { }
        // recitation7 textbox
        private void textBox47_TextChanged_1(object sender, EventArgs e) { }
        // recitation8 textbox
        private void textBox48_TextChanged_1(object sender, EventArgs e) { }
        // recitation9 textbox
        private void textBox49_TextChanged_1(object sender, EventArgs e) { }
        // recitation10 textbox
        private void textBox50_TextChanged_1(object sender, EventArgs e) { }

        // --- End of NEW TextChanged Event Handlers ---

        private void button2_Click(object sender, EventArgs e) // Clear Inputs button
        {
            Debug.WriteLine("Clear Inputs button clicked.");
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };
            foreach (string category in categories)
            {
                for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
                {
                    Control scoreControl = this.Controls.Find($"txt{category}Score{i}", true).FirstOrDefault();
                    if (scoreControl is TextBox scoreTextBox) { scoreTextBox.Clear(); }
                }
                Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                if (weightControl is TextBox weightTextBox) { weightTextBox.Clear(); }
                Control finalPercentageControl = this.Controls.Find($"txt{category}FinalPercentage", true).FirstOrDefault();
                if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Clear(); }
                else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = string.Empty; }
                Control weightedContributionControl = this.Controls.Find($"txt{category}WeightedContribution", true).FirstOrDefault();
                if (weightedContributionControl is TextBox txtWeightedContribution) { txtWeightedContribution.Clear(); }
                else if (weightedContributionControl is Label lblWeightedContribution) { lblWeightedContribution.Text = string.Empty; }
            }
            Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();
            if (classStandingResultControl is TextBox txtClassStandingResult) { txtClassStandingResult.Clear(); }
            else if (classStandingResultControl is Label lblClassStandingResult) { lblClassStandingResult.Text = "Calculated Class Standing:"; }
            Control firstInput = this.Controls.Find("txtQuizScore1", true).FirstOrDefault();
            firstInput?.Focus();
        }

        private void txtSeatworkWeight_TextChanged(object sender, EventArgs e)
        {

        }
    }
}