﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace login
{
    public partial class frmLogin : Form
    {
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        public frmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // Login Button
        {
            if (string.IsNullOrWhiteSpace(regisUN.Text) || string.IsNullOrWhiteSpace(regisPass.Text))
            {
                MessageBox.Show("Please enter both Student ID and password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                regisUN.Focus();
                return;
            }

            int studentIDNumeric; // Use a different name to avoid confusion with the string version if needed
            if (!int.TryParse(regisUN.Text, out studentIDNumeric))
            {
                MessageBox.Show("Student ID must be a numerical value.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                regisUN.Text = "";
                regisUN.Focus();
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // You can still select student_name if you want to log it or use it for other purposes
                // but it won't be passed to the dashboard constructor.
                string loginQuery = "SELECT student_name FROM dbo.student WHERE studentID = @StudentID AND password = @Password";

                using (SqlCommand cmd = new SqlCommand(loginQuery, con))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentIDNumeric); // Use the parsed int value
                    cmd.Parameters.AddWithValue("@Password", regisPass.Text);

                    try
                    {
                        con.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read()) // If a matching student was found
                            {
                                string studentName = dr["student_name"].ToString() ?? "N/A"; // Still useful for logging
                                Debug.WriteLine($"Login successful for Student ID: {regisUN.Text}, Name: {studentName}");

                                // --- MODIFIED DASHBOARD INSTANTIATION ---
                                // Open dashboard, passing only studentID (as string from regisUN.Text)
                                dashboard mainDashboard = new dashboard(regisUN.Text); // Pass the original text input for Student ID
                                mainDashboard.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Invalid Student ID or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                regisUN.Text = "";
                                regisPass.Text = "";
                                regisUN.Focus();
                            }
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Debug.WriteLine($"SQL Error during login: {sqlEx.Message} (Number: {sqlEx.Number})");
                        MessageBox.Show($"Database Error: {sqlEx.Message}", "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"General Error during login: {ex.Message}");
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            regisUN.Text = "";
            regisPass.Text = "";
            regisUN.Focus();
        }

        private void regisShowPass_CheckedChanged(object sender, EventArgs e)
        {
            regisPass.PasswordChar = regisShowPass.Checked ? '\0' : '*';
        }

        private void label6_Click(object sender, EventArgs e) // "Create Account" Link
        {
            frmRegister registrationForm = new frmRegister();
            registrationForm.Show();
            this.Hide();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            regisUN.Focus();
        }
    }
}