﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    // --- Corrected Order: goals_op partial class is now the first class ---
    public partial class goals_op : Form
    {
        // Define an event that other parts of the application can subscribe to.
        // This event will be triggered when a goal is successfully submitted.
        public event EventHandler<GoalSubmittedEventArgs> GoalSubmitted; // This uses the class defined below

        public goals_op()
        {
            InitializeComponent();
            // Optional: Add any initial setup here
        }

        // --- Event Handlers ---

        // Handler for Title textbox text changed
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // Add validation or other logic that should happen as the user types the title
        }

        // Handler for Date textbox text changed
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Add validation or other logic that should happen as the user types the date
        }

        // Handler for Description textbox text changed
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Add validation or other logic that should happen as the user types the description
        }

        // Handler for Submit button click
        private void button1_Click(object sender, EventArgs e)
        {
            // --- Input Validation ---
            string title = textBox4.Text.Trim();
            string dateText = textBox2.Text.Trim();
            string description = textBox1.Text.Trim();
            DateTime dueDate;

            // Validate Title
            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Please enter a goal title.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox4.Focus();
                return;
            }

            // Validate Date format and if it's a valid date
            if (string.IsNullOrEmpty(dateText))
            {
                MessageBox.Show("Please enter a due date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return;
            }

            if (!DateTime.TryParse(dateText, out dueDate))
            {
                MessageBox.Show("Please enter a valid date format for the due date (e.g., MM/DD/YYYY).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return;
            }

            // Past date validation was removed as per your previous request.
            /*
            if (dueDate < DateTime.Today)
            {
                 MessageBox.Show("Due date cannot be in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 textBox2.Focus();
                 return;
            }
            */

            // --- Process and Submit Data ---

            // If validation passes, create a Goal object
            Goal newGoal = new Goal(title, dueDate, description); // Uses the Goal class defined below

            // Raise the GoalSubmitted event
            GoalSubmitted?.Invoke(this, new GoalSubmittedEventArgs(newGoal)); // Uses GoalSubmittedEventArgs defined below

            // Call the clear method after submission
            ClearFormFields();

            // Optional: Close the form after submission
            // this.Close();

            MessageBox.Show("Goal submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Handler for Clear button click
        private void button2_Click(object sender, EventArgs e)
        {
            ClearFormFields();
        }

        // Helper method to clear the form fields
        private void ClearFormFields()
        {
            textBox4.Clear(); // Clear Title
            textBox2.Clear(); // Clear Date
            textBox1.Clear(); // Clear Description
            textBox4.Focus(); // Set focus back to the first field
        }

        // Comments about structure, appearance, and connection remain relevant.
    }

    // --- Define Goal class and EventArgs AFTER the goals_op partial class ---

    // Define a simple class to hold goal data
    public class Goal
    {
        public string Title { get; set; }
        public DateTime DueDate { get; set; }
        public string Description { get; set; }

        public Goal(string title, DateTime dueDate, string description)
        {
            Title = title;
            DueDate = dueDate;
            Description = description;
        }

        public override string ToString()
        {
            return $"{Title} (Due: {DueDate.ToShortDateString()})\n{Description}";
        }
    }

    // Custom EventArgs to pass the Goal object when the event is fired
    public class GoalSubmittedEventArgs : EventArgs
    {
        public Goal SubmittedGoal { get; }

        public GoalSubmittedEventArgs(Goal goal)
        {
            SubmittedGoal = goal;
        }
    }
}