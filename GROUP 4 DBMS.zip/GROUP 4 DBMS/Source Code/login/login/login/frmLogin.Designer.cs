﻿namespace login
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            label5 = new Label();
            button2 = new Button();
            button1 = new Button();
            regisShowPass = new CheckBox();
            regisConfPass = new TextBox();
            regisPass = new TextBox();
            label3 = new Label();
            regisUN = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Cursor = Cursors.Hand;
            label6.ForeColor = Color.Black;
            label6.Location = new Point(96, 421);
            label6.Name = "label6";
            label6.Size = new Size(101, 17);
            label6.TabIndex = 23;
            label6.Text = "Create Account";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Cursor = Cursors.Hand;
            label5.ForeColor = Color.Black;
            label5.Location = new Point(65, 395);
            label5.Name = "label5";
            label5.Size = new Size(152, 17);
            label5.TabIndex = 22;
            label5.Text = "Don't Have An Account";
            // 
            // button2
            // 
            button2.BackColor = Color.White;
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderSize = 2;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.Black;
            button2.Location = new Point(39, 346);
            button2.Name = "button2";
            button2.Size = new Size(216, 35);
            button2.TabIndex = 21;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.White;
            button1.Location = new Point(39, 295);
            button1.Name = "button1";
            button1.Size = new Size(216, 35);
            button1.TabIndex = 20;
            button1.Text = "LOGIN";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // regisShowPass
            // 
            regisShowPass.AutoSize = true;
            regisShowPass.BackColor = Color.Transparent;
            regisShowPass.Cursor = Cursors.Hand;
            regisShowPass.FlatStyle = FlatStyle.Flat;
            regisShowPass.ForeColor = Color.Black;
            regisShowPass.Location = new Point(133, 236);
            regisShowPass.Name = "regisShowPass";
            regisShowPass.Size = new Size(119, 21);
            regisShowPass.TabIndex = 19;
            regisShowPass.Text = "Show Password";
            regisShowPass.UseVisualStyleBackColor = false;
            regisShowPass.CheckedChanged += regisShowPass_CheckedChanged;
            // 
            // regisConfPass
            // 
            regisConfPass.BackColor = Color.FromArgb(230, 231, 233);
            regisConfPass.BorderStyle = BorderStyle.None;
            regisConfPass.Font = new Font("MS UI Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            regisConfPass.Location = new Point(39, 265);
            regisConfPass.Multiline = true;
            regisConfPass.Name = "regisConfPass";
            regisConfPass.Size = new Size(0, 0);
            regisConfPass.TabIndex = 18;
            // 
            // regisPass
            // 
            regisPass.BackColor = Color.FromArgb(230, 231, 233);
            regisPass.BorderStyle = BorderStyle.None;
            regisPass.Font = new Font("MS UI Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            regisPass.Location = new Point(39, 199);
            regisPass.Multiline = true;
            regisPass.Name = "regisPass";
            regisPass.PasswordChar = '*';
            regisPass.Size = new Size(216, 28);
            regisPass.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.ForeColor = Color.Black;
            label3.Location = new Point(39, 179);
            label3.Name = "label3";
            label3.Size = new Size(66, 17);
            label3.TabIndex = 15;
            label3.Text = "Password";
            // 
            // regisUN
            // 
            regisUN.BackColor = Color.FromArgb(230, 231, 233);
            regisUN.BorderStyle = BorderStyle.None;
            regisUN.Font = new Font("MS UI Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            regisUN.Location = new Point(39, 135);
            regisUN.Multiline = true;
            regisUN.Name = "regisUN";
            regisUN.Size = new Size(216, 28);
            regisUN.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.ForeColor = Color.Black;
            label2.Location = new Point(39, 115);
            label2.Name = "label2";
            label2.Size = new Size(69, 17);
            label2.TabIndex = 13;
            label2.Text = "Username";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(29, 43);
            label1.Name = "label1";
            label1.Size = new Size(78, 27);
            label1.TabIndex = 12;
            label1.Text = "Login";
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.th__1___1_;
            ClientSize = new Size(285, 544);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(regisShowPass);
            Controls.Add(regisConfPass);
            Controls.Add(regisPass);
            Controls.Add(label3);
            Controls.Add(regisUN);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmLogin";
            Load += frmLogin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private Label label5;
        private Button button2;
        private Button button1;
        private CheckBox regisShowPass;
        private TextBox regisConfPass;
        private TextBox regisPass;
        private Label label3;
        private TextBox regisUN;
        private Label label2;
        private Label label1;
    }
}