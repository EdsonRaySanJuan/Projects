﻿// selectcourse.cs - Integrated version linking to classStanding and passing grading term

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

// Assuming CourseDetails class is defined in the 'login' namespace and is accessible.
// This class should be in its own file (e.g., CourseDetails.cs) and be public.
// Make sure it has the AcademicPeriodId, Code, Name, Units, SchoolYear, Semester properties.

// Ensure the classStanding form is also in the 'login' namespace and accessible.
// Make sure classStanding has this constructor: public classStanding(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard) { ... }

namespace login
{
    // This is a partial class definition. The rest of the class (including components and InitializeComponent)
    // is defined in the auto-generated selectcourse.Designer.cs file.
    // DO NOT define InitializeComponent, the 'components' field, Dispose(), or the Designer generated region here.
    public partial class selectcourse : Form
    {
        // Member variable to hold the reference to the Dashboard form for final navigation
        private Form dashboardForm;

        // Fields to store the data received from selectterm.cs (when returning from course entry)
        // These are populated by the constructor used when coming from selectterm.
        private List<CourseDetails> _receivedCourses;
        private string _selectedTerm; // This now holds the Grading Term (Prelim/Midterm/Finals)

        // We don't need a field to store academicPeriodId for *new* entry here
        // because we get it and use it immediately in button1_Click.


        // --- Constructors ---

        // Constructor that accepts the Dashboard form reference (likely used when starting a new entry from dashboard)
        public selectcourse(Form dashboard)
        {
            InitializeComponent(); // This calls the method in selectcourse.Designer.cs
            this.dashboardForm = dashboard; // Store the dashboard reference
            this.Load += Selectcourse_Load; // Hook up the Load event
        }

        // Constructor to receive courses, term (Grading Term), and dashboard (used when returning from selectterm)
        // This constructor receives the collected course data after the entry sequence is complete.
        public selectcourse(List<CourseDetails> courses, string term, Form dashboard) : this(dashboard) // Chain to the existing constructor to set dashboard
        {
            this._receivedCourses = courses; // Store the received list of courses
            this._selectedTerm = term;      // Store the received selected Grading Term (Prelim/Midterm/Finals)

            // The Selectcourse_Load event will handle displaying this data.
        }

        // Parameterless constructor (Needed by the form designer. Data fields will be default values if used directly.)
        // If this constructor is used for reasons other than the designer, the form will not have
        // the necessary data (_receivedCourses, _selectedTerm, dashboardForm) for normal operation.
        public selectcourse()
        {
            InitializeComponent(); // This calls the method in selectcourse.Designer.cs
            // Initialize the list and term to prevent NullReferenceException if this constructor is used directly
            this._receivedCourses = new List<CourseDetails>();
            this._selectedTerm = string.Empty; // Initialize _selectedTerm as well
            this.Load += Selectcourse_Load;
            this.Load += (s, e) => HandleParameterlessConstructorContext();
        }

        private void HandleParameterlessConstructorContext()
        {
            // Check if the form was likely opened incorrectly (not via the constructor that receives data)
            if (dashboardForm == null && (_receivedCourses == null || _receivedCourses.Count == 0 || string.IsNullOrEmpty(_selectedTerm)))
            {
                Debug.WriteLine("Warning: selectcourse form initialized without expected data or dashboard reference.");
                MessageBox.Show("This form was opened incorrectly. Missing data or context.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                EnableResultDisplay(false); // Show new entry controls (which should be hidden in this scenario)
            }
        }

        // --- Helper to manage control visibility based on state ---
        // Use this method to show/hide the correct set of controls
        // depending on whether the form is for starting a New Entry or Displaying Results.
        private void EnableResultDisplay(bool enable)
        {
            // Define controls for the 'New Entry' state
            // ADJUST THESE NAMES TO MATCH YOUR DESIGNER CONTROLS FOR NEW ENTRY
            Control[] newEntryControls = {
                FindControlRecursive(this, "label1"), // "Course Details" label or similar for new entry section
                FindControlRecursive(this, "label8"), // "Select School Year" label
                FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear"), // Input for School Year
                FindControlRecursive(this, "label2"), // "Select Semester" label
                FindControlRecursive(this, "textBoxSemester") ?? FindControlRecursive(this, "comboBoxSemester"), // Input for Semester
                FindControlRecursive(this, "label3"), // "Enter Number of Course" label
                FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses"), // Input for number of courses
                // FindControlRecursive(this, "button1"), // Original Submit button - handled separately below
                // FindControlRecursive(this, "button2"), // Original Clear button - handled separately below
            };

            // Define controls for the 'Display Results' state
            // ADJUST THESE NAMES TO MATCH YOUR DESIGNER CONTROLS FOR DISPLAYING RESULTS
            Control[] dataDisplayControls = {
                FindControlRecursive(this, "lblSelectedTerm"), // Label showing the selected Term (Grading Term)
                FindControlRecursive(this, "comboBox1"),        // ComboBox listing the Courses
                // Add other controls for displaying details of the selected course
                FindControlRecursive(this, "lblUnits"),
                FindControlRecursive(this, "lblAcademicPeriodId"),
                FindControlRecursive(this, "txtCourseCodeDisplay"),
                FindControlRecursive(this, "txtCourseNameDisplay"),
                // FindControlRecursive(this, "btnProcessGrades") // A separate button for grading, if you add one
            };

            // Manage visibility and text of button1 (Submit for new entry / Process Grades for results)
            Control btn1 = FindControlRecursive(this, "button1");
            if (btn1 is Button button1Control)
            {
                button1Control.Visible = true; // Assuming button1 is visible in both states
                button1Control.Text = enable ? "Process Grades" : "Submit Academic Period"; // Change text based on state
            }

            // Manage visibility and text of button2 (Clear for new entry / Clear Selection for results)
            Control btn2 = FindControlRecursive(this, "button2");
            if (btn2 is Button button2Control)
            {
                button2Control.Visible = true; // Assuming button2 is visible in both states
                button2Control.Text = enable ? "Clear Selection" : "Clear Inputs"; // Change text based on state
            }

            // Hide/Show controls based on the state (enable = true means Display Results state)
            foreach (Control ctrl in newEntryControls)
            {
                if (ctrl != null && this.Controls.Contains(ctrl)) ctrl.Visible = !enable;
            }

            foreach (Control ctrl in dataDisplayControls)
            {
                if (ctrl != null && this.Controls.Contains(ctrl)) ctrl.Visible = enable;
            }

            // Ensure the back button (button3) is visible regardless of state
            Control btnBack = FindControlRecursive(this, "button3");
            if (btnBack != null) btnBack.Visible = true;
        }


        // --- Helper to find controls recursively ---
        // This is needed because Controls.Find only searches direct children by default.
        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }


        // Form Load event handler - Handles logic when the form is shown/loaded
        private void Selectcourse_Load(object sender, EventArgs e)
        {
            // Check if the form is loading with received data (meaning it's returning from selectterm)
            if (_receivedCourses != null && _receivedCourses.Count > 0 && !string.IsNullOrEmpty(_selectedTerm))
            {
                // --- Logic to use received data when returning from selectterm ---
                Debug.WriteLine($"selectcourse Load: Returned to selectcourse with {this._receivedCourses.Count} courses for {this._selectedTerm}.");
                MessageBox.Show($"Returned to selectcourse with {this._receivedCourses.Count} courses for {this._selectedTerm}.", "Data Received");

                // *** Removed the DataGridView code that caused "Control Missing" warning ***
                // Control[] foundDataGridView = this.Controls.Find("dataGridViewCourses", true); ... (Removed)

                // --- Call the method to populate your ComboBox and other display controls ---
                PopulateReceivedCourseData();

                // Show result display controls, hide new entry controls
                EnableResultDisplay(true);

            }
            else
            {
                // If the form is loading WITHOUT received data, assume it's for starting a NEW entry.
                // Ensure input controls are visible and data display controls are hidden.
                Debug.WriteLine("selectcourse Load: No received data, assuming starting new entry.");

                EnableResultDisplay(false); // Show input controls, hide result display controls

                // Set initial focus when starting a new entry
                Control initialFocusControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear"); // Assuming the first input control
                initialFocusControl?.Focus(); // Use null conditional for safety

                // Set default value for number of courses if applicable
                Control numCoursesControlForDefault = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses"); // Assuming control for num courses
                if (numCoursesControlForDefault is NumericUpDown numUpDownForDefault)
                {
                    numUpDownForDefault.Value = 1;
                }
                else if (numCoursesControlForDefault is TextBox txtNumCourses)
                {
                    txtNumCourses.Text = "1";
                }
            }
        }


        // Event handler for comboBox1 SelectedIndexChanged (if used as the courses combobox)
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Add your logic here to display details of the selected course.
            ComboBox cmb = sender as ComboBox;
            if (cmb != null && cmb.SelectedItem != null && _receivedCourses != null)
            {
                string selectedText = cmb.SelectedItem.ToString();
                CourseDetails selectedCourse = _receivedCourses.FirstOrDefault(c => $"{c.Code} - {c.Name}" == selectedText);

                if (selectedCourse != null)
                {
                    // --- Update other UI elements with details from selectedCourse ---
                    // ADJUST THESE NAMES TO MATCH YOUR DETAIL DISPLAY CONTROLS
                    Control lblUnits = FindControlRecursive(this, "lblUnits");
                    if (lblUnits is Label lblU) lblU.Text = $"Units: {selectedCourse.Units}";

                    Control lblAcademicPeriodId = FindControlRecursive(this, "lblAcademicPeriodId");
                    if (lblAcademicPeriodId is Label lblAP) lblAP.Text = $"Academic Period ID: {selectedCourse.AcademicPeriodId}";

                    Control txtCourseCodeDisplay = FindControlRecursive(this, "txtCourseCodeDisplay");
                    if (txtCourseCodeDisplay is TextBox txtCCD) txtCCD.Text = selectedCourse.Code;

                    Control txtCourseNameDisplay = FindControlRecursive(this, "txtCourseNameDisplay");
                    if (txtCourseNameDisplay is TextBox txtCND) txtCND.Text = selectedCourse.Name;

                    Debug.WriteLine($"Selected Course Details: Code={selectedCourse.Code}, Name={selectedCourse.Name}, Units={selectedCourse.Units}, APId={selectedCourse.AcademicPeriodId}");
                }
                else
                {
                    Debug.WriteLine($"Could not find CourseDetails object for selected item text: {selectedText}");
                    // Clear detail display controls if the course object wasn't found
                    if (FindControlRecursive(this, "lblUnits") is Label lblU) lblU.Text = "Units:";
                    if (FindControlRecursive(this, "lblAcademicPeriodId") is Label lblAP) lblAP.Text = "Academic Period ID:";
                    if (FindControlRecursive(this, "txtCourseCodeDisplay") is TextBox txtCCD) txtCCD.Clear();
                    if (FindControlRecursive(this, "txtCourseNameDisplay") is TextBox txtCND) txtCND.Clear();
                }
            }
            else
            {
                Debug.WriteLine("comboBox1_SelectedIndexChanged triggered with null sender, selected item, or _receivedCourses.");
            }
        }

        // Event handler for comboBox2 SelectedIndexChanged (if used and hooked up)
        // Keep this defined ONCE if needed.
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Add your logic here if this dropdown is used for something else (e.g., Semester)
        }

        // Event handler for textBox1 TextChanged (if used and hooked up)
        // Keep this defined ONCE if needed.
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Add your logic here if this textbox is used for something else.
        }


        // submit btn (button1) click handler - This method handles actions based on the form's state.
        // If displaying results, it acts as "Process Grades". If starting new entry, it saves Academic Period and starts course entry.
        private void button1_Click(object sender, EventArgs e)
        {
            // Check if the form is currently in the 'Display Results' state (i.e., has received courses)
            // If so, this button acts as "Process Grades" or the next step button.
            if (_receivedCourses != null && _receivedCourses.Count > 0 && !string.IsNullOrEmpty(this._selectedTerm)) // Use 'this._selectedTerm'
            {
                // --- Logic for "Process Grades" or the next step after displaying courses ---
                Debug.WriteLine("Button 1 (Process Grades) clicked!");

                // Example: Get the currently selected course from the ComboBox
                ComboBox cmbCourses = FindControlRecursive(this, "comboBox1") as ComboBox;
                if (cmbCourses != null && cmbCourses.SelectedItem != null)
                {
                    string selectedText = cmbCourses.SelectedItem.ToString();
                    // Find the corresponding CourseDetails object
                    // Make sure your CourseDetails class has properties like Code and Name used here
                    CourseDetails selectedCourse = _receivedCourses?.FirstOrDefault(c => $"{c.Code} - {c.Name}" == selectedText);

                    if (selectedCourse != null)
                    {
                        Debug.WriteLine($"Proceeding with selected course: {selectedCourse.Code}");
                        // --- Navigate to the classStanding form, passing the selected course details AND THE GRADING TERM ---

                        try
                        {
                            // Create an instance of the classStanding form
                            // Pass the selected course details, the SELECTED GRADING TERM (_selectedTerm), the current selectcourse form (this), and the dashboard form (this.dashboardForm)
                            // ASSUMES classStanding HAS THIS CONSTRUCTOR: public classStanding(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard)
                            classStanding classStandingForm = new classStanding(selectedCourse, this._selectedTerm, this, this.dashboardForm); // Pass this._selectedTerm

                            this.Hide(); // Hide the current form (selectcourse)
                            classStandingForm.Show(); // Show the classStanding form

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred while trying to open the Class Standing form: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Debug.WriteLine($"Error opening Class Standing form: {ex.Message}\n{ex.StackTrace}");
                            this.Show(); // Stay on the current form if navigation failed
                        }
                    }
                    else
                    {
                        MessageBox.Show("Could not find details for the selected course.", "Selection Error");
                    }
                }
                else
                {
                    MessageBox.Show("Please select a course from the list to process grades.", "Selection Required");
                    cmbCourses?.Focus();
                }

                // Exit the method after handling the "Process Grades" logic
                return;
            }

            // --- If not in 'Display Results' state, proceed with original NEW entry logic ---
            // This part remains unchanged, leading to the course_opX forms
            // *** NOTE: This functionality for starting a NEW entry sequence (including saving to DB) ***
            // *** conflicts with firstpartcourse.cs also starting a new entry. It is recommended to ***
            // *** have only ONE form responsible for initiating a new academic period entry. ***

            // --- 1. Get Input from UI Controls (for NEW entry) ---
            string schoolYearInput = "";
            Control foundSchoolYearControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear"); // Correctly assigned to single Control
            if (foundSchoolYearControl is TextBox schoolYearTextBox) { schoolYearInput = schoolYearTextBox.Text.Trim(); }
            else if (foundSchoolYearControl is ComboBox schoolYearComboBox) { if (schoolYearComboBox.SelectedItem != null) schoolYearInput = schoolYearComboBox.SelectedItem.ToString(); }
            else { MessageBox.Show("Configuration Error: School Year input control not found.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }


            string semesterInput = "";
            Control foundSemesterControl = FindControlRecursive(this, "textBoxSemester") ?? FindControlRecursive(this, "comboBoxSemester"); // Correctly assigned to single Control
            if (foundSemesterControl is TextBox semesterTextBox) { semesterInput = semesterTextBox.Text.Trim(); }
            else if (foundSemesterControl is ComboBox semesterComboBox) { if (semesterComboBox.SelectedItem != null) semesterInput = semesterComboBox.SelectedItem.ToString(); }
            else { MessageBox.Show("Configuration Error: Semester input control not found.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }


            int numberOfCoursesInput = 0;
            Control foundNumCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses"); // Correctly assigned to single Control
            if (foundNumCoursesControl is NumericUpDown numUpDown)
            {
                numberOfCoursesInput = (int)numUpDown.Value;
            }
            else if (foundNumCoursesControl is TextBox numCoursesTextBox)
            {
                if (!int.TryParse(numCoursesTextBox.Text.Trim(), out numberOfCoursesInput))
                {
                    MessageBox.Show("Please enter a valid number for the Number of Courses.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    numCoursesTextBox.Focus();
                    return;
                }
            }
            else { MessageBox.Show("Configuration Error: Number of Courses input control not found.", "Control Missing", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }


            // --- 2. Validate Input (for NEW entry) ---
            if (string.IsNullOrWhiteSpace(schoolYearInput))
            {
                MessageBox.Show("Please enter the School Year.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Control syControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear");
                syControl?.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(semesterInput))
            {
                MessageBox.Show("Please enter the Semester.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Control semControl = FindControlRecursive(this, "textBoxSemester") ?? FindControlRecursive(this, "comboBoxSemester");
                semControl?.Focus();
                return;
            }

            // Validate number of courses is within the expected range (1 to 10, based on available course_op forms)
            if (numberOfCoursesInput < 1 || numberOfCoursesInput > 10) // Adjust max if you have more/fewer course_op forms
            {
                MessageBox.Show("Please enter a valid number of courses between 1 and 10.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Control numControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses");
                numControl?.Focus();
                return;
            }

            // Ensure dashboardForm is not null before proceeding to navigation
            if (dashboardForm == null)
            {
                MessageBox.Show("Dashboard form reference is missing. Cannot proceed.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // --- 3. Save Academic Period to Database and Get ID (for NEW entry) ---
            int academicPeriodId = 0; // Variable to store the generated ID
            // *** Ensure your connection string is correct ***
            string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;"; // Your database connection string

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // SQL query to insert the academic period and get the generated ID
                    string insertAcademicPeriodQuery = @"
                        INSERT INTO AcademicPeriods (SchoolYear, Semester)
                        VALUES (@SchoolYear, @Semester);
                        SELECT SCOPE_IDENTITY();"; // Get the newly generated ID for the inserted row

                    using (SqlCommand command = new SqlCommand(insertAcademicPeriodQuery, connection))
                    {
                        command.Parameters.AddWithValue("@SchoolYear", schoolYearInput);
                        command.Parameters.AddWithValue("@Semester", semesterInput);

                        // ExecuteScalar is used because we expect a single value (the ID)
                        object result = command.ExecuteScalar();

                        if (result != null && int.TryParse(result.ToString(), out academicPeriodId))
                        {
                            // Successfully inserted Academic Period and got the ID
                            Debug.WriteLine($"Academic Period '{schoolYearInput} - {semesterInput}' saved successfully from selectcourse. ID generated: {academicPeriodId}");
                        }
                        else
                        {
                            MessageBox.Show("Failed to retrieve the Academic Period ID after saving. Cannot proceed with course entry.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return; // Stop if ID retrieval fails
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    // Log the detailed error for debugging
                    Debug.WriteLine("SQL Error saving Academic Period in selectcourse: " + sqlEx.Message);
                    MessageBox.Show("Failed to save Academic Period to the database. Error: " + sqlEx.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Stop if a database error occurs
                }
                catch (Exception ex)
                {
                    // Catch any other unexpected errors during database operation
                    Debug.WriteLine("General Error saving Academic Period in selectcourse: " + ex.Message);
                    MessageBox.Show("An unexpected error occurred while saving Academic Period: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Stop if any other error occurs
                }
                // The 'using' statement ensures the connection is closed even if errors occur.
            }

            // --- Check if Academic Period ID was successfully obtained ---
            if (academicPeriodId == 0)
            {
                // This case should have been handled by the return statements in the try/catch blocks,
                // but included as a final safeguard.
                MessageBox.Show("Could not obtain Academic Period ID. Cannot start course entry.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // --- 4. Initialize Data Structure and Start Course Entry Sequence (for NEW entry) ---
            // Create a new empty list to store CourseDetails objects. This list will be
            // passed through the course_op forms to collect data.
            List<CourseDetails> collectedCourses = new List<CourseDetails>();

            try
            {
                // Determine which is the FIRST course entry form to open based on the number of courses (N)
                Form firstCourseForm = null;
                int firstCourseNumber = 1; // Always start collecting data from Course 1

                // Use a switch statement to select the correct starting form based on the number of courses.
                // This requires you to have course_op, course_op1, ..., course_op9 forms defined,
                // and their constructors must accept the 8 arguments including academicPeriodId.
                switch (numberOfCoursesInput) // Use numberOfCoursesInput here
                {
                    case 1:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 2:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op1(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 3:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op2(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 4:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op3(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 5:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op4(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 6:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op5(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 7:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op6(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 8:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op7(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 9:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op8(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    case 10:
                        // *** Pass the obtained academicPeriodId HERE ***
                        firstCourseForm = new course_op9(schoolYearInput, semesterInput, numberOfCoursesInput, firstCourseNumber, this, dashboardForm, collectedCourses, academicPeriodId);
                        break;
                    default:
                        // This case should ideally not be reached if validation (numberOfCoursesInput < 1 || numberOfCoursesInput > 10) is correct
                        MessageBox.Show("Invalid number of courses specified.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Control numControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses");
                        numControl?.Focus();
                        return;
                }

                // Check if a valid course form was created
                if (firstCourseForm != null)
                {
                    firstCourseForm.Show(); // Show the selected first course entry form
                    this.Hide();          // Hide the current form (selectcourse)
                }
                else
                {
                    // This might happen if numberOfCoursesInput is valid but no case matched (e.g., typo in switch)
                    MessageBox.Show("Error: Could not determine the correct course entry form to open.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (MissingMethodException mmEx)
            {
                // This catch block helps diagnose if a course_opX constructor is missing or incorrect.
                // Ensure the constructors in course_opX.cs files match the expected signature (8 arguments).
                MessageBox.Show($"Configuration Error: A course entry form constructor is missing or incorrect.\nPlease ensure all course_opX forms (from course_op to course_op9) have the required public constructor signature (string, string, int, int, Form, Form, List<CourseDetails>, int).\nDetails: {mmEx.Message}", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Show(); // Stay on the current form if navigation failed
            }
            catch (Exception ex)
            {
                MessageBox.Show("An unexpected error occurred while starting the course entry: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Show(); // Stay on the current form if navigation failed
            }
        }

        // --- Corrected button2_Click (Clear) click handler ---
        // This method handles clearing inputs based on the form's current state.
        // If displaying results, it clears the selection; otherwise, clears new entry inputs.
        private void button2_Click(object sender, EventArgs e)
        {
            // Determine the form's current state
            bool isDisplayingResults = (_receivedCourses != null && _receivedCourses.Count > 0 && !string.IsNullOrEmpty(_selectedTerm));

            if (isDisplayingResults)
            {
                // --- Logic for "Clear Selection" when displaying received courses ---
                Debug.WriteLine("Button 2 (Clear Selection) clicked!");

                // Example: Clear ComboBox selection and detail display fields
                Control cmbCoursesControl = FindControlRecursive(this, "comboBox1");
                // Corrected: Declare and assign comboBox1 outside the if block to fix CS0165
                ComboBox comboBox1 = cmbCoursesControl as ComboBox;

                if (comboBox1 != null) // Now check if the control was successfully found and cast
                {
                    comboBox1.SelectedIndex = -1; // Clear selected item
                    Debug.WriteLine("Cleared ComboBox selection.");
                }
                else
                {
                    Debug.WriteLine("ComboBox 'comboBox1' not found or is not a ComboBox. Cannot clear selection.");
                }


                // Clear related detail display controls (adjust names to match your controls)
                if (FindControlRecursive(this, "lblUnits") is Label lblU) lblU.Text = "Units:";
                if (FindControlRecursive(this, "lblAcademicPeriodId") is Label lblAP) lblAP.Text = "Academic Period ID:";
                if (FindControlRecursive(this, "txtCourseCodeDisplay") is TextBox txtCCD) txtCCD.Clear();
                if (FindControlRecursive(this, "txtCourseNameDisplay") is TextBox txtCND) txtCND.Clear();
                Debug.WriteLine("Cleared detail display controls.");

                // Optional: Set focus back to the ComboBox
                // This is now safe because 'comboBox1' is always assigned (either the control or null)
                comboBox1?.Focus();
                Debug.WriteLine("Attempted to set focus to ComboBox.");

            }
            else
            {
                // --- Logic for "Clear Inputs" when starting a new entry ---
                Debug.WriteLine("Button 2 (Clear Inputs) clicked!");

                Control foundSchoolYearControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear");
                if (foundSchoolYearControl is TextBox schoolYearTextBox) { schoolYearTextBox.Clear(); }
                else if (foundSchoolYearControl is ComboBox schoolYearComboBox) { schoolYearComboBox.SelectedIndex = -1; }

                Control foundSemesterControl = FindControlRecursive(this, "textBoxSemester") ?? FindControlRecursive(this, "comboBoxSemester");
                if (foundSemesterControl is TextBox semesterTextBox) { semesterTextBox.Clear(); }
                else if (foundSemesterControl is ComboBox semesterComboBox) { semesterComboBox.SelectedIndex = -1; }


                Control foundNumCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBoxNumCourses");
                if (foundNumCoursesControl is NumericUpDown numUpDown) { numUpDown.Value = 1; } // Reset to default
                else if (foundNumCoursesControl is TextBox numCoursesTextBox) { numCoursesTextBox.Clear(); }


                // Set focus back to the first input field (School Year)
                Control firstInputControl = FindControlRecursive(this, "textBoxSchoolYear") ?? FindControlRecursive(this, "comboBoxSchoolYear");
                firstInputControl?.Focus();
            }
        }

        // Back button (button3) click handler - This button should likely go back to the Dashboard.
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form (selectcourse)
            if (dashboardForm != null)
            {
                dashboardForm.Show(); // Navigate back to the dashboard
            }
            else
            {
                // If there's no dashboard form reference, exiting might be the only option.
                MessageBox.Show("Dashboard form reference is missing. Cannot navigate back.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit(); // Or this.Close(); depending on desired behavior
            }
        }

        // --- Method to display received course data (Populate ComboBox, Labels, etc.) ---
        // This is called from Selectcourse_Load when the form receives data from selectterm.
        private void PopulateReceivedCourseData()
        {
            // Example: Update a label to show the selected term (Assuming a label named 'lblSelectedTerm')
            // This lblSelectedTerm now displays the Grading Term (Prelim/Midterm/Finals)
            Control lblTerm = FindControlRecursive(this, "lblSelectedTerm");
            if (lblTerm is Label lbl)
            {
                lbl.Text = $"Term Selected: {_selectedTerm}";
            }
            else { Debug.WriteLine("Warning: Control 'lblSelectedTerm' not found."); }


            // Example: Populate the ComboBox with course names/codes (Using your confirmed name: comboBox1)
            Control cmbCoursesControl = FindControlRecursive(this, "comboBox1"); // *** Explicitly using comboBox1 ***
            if (cmbCoursesControl is ComboBox comboBox1)
            {
                comboBox1.Items.Clear(); // Clear existing items

                if (_receivedCourses != null && _receivedCourses.Count > 0)
                {
                    // Add each course to the ComboBox
                    foreach (var course in _receivedCourses)
                    {
                        // You can customize the text shown in the dropdown here
                        // It's helpful if this text uniquely identifies the course
                        comboBox1.Items.Add($"{course.Code} - {course.Name}");

                        // OPTIONAL: If you want to store the *actual* CourseDetails object in the item
                        // (useful for easily retrieving details in SelectedIndexChanged without searching)
                        // (Requires setting DisplayMember on the ComboBox)
                        // comboBox1.Items.Add(course);
                    }
                    // Select the first item by default if available
                    if (comboBox1.Items.Count > 0)
                    {
                        comboBox1.SelectedIndex = 0;
                    }
                }
                else
                {
                    // Handle case where no courses were received
                    comboBox1.Items.Add("No courses available.");
                    comboBox1.Enabled = false; // Disable combobox if empty
                }
            }
            else
            {
                Debug.WriteLine("Warning: ComboBox control 'comboBox1' not found for displaying courses.");
                // Add a warning message or disable related controls if the ComboBox is missing
            }

            // Add logic here to populate other controls if you have them
            // (These would typically be updated in the SelectedIndexChanged event)

            // Ensure you have a button to proceed with the next step (e.g., entering grades)
            // This button would likely be handled by a separate click event handler (e.g., btnProcessGrades_Click).
        }

    }
}