﻿using System;
using System.Collections.Generic; // Required for List<> if you use it here
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // For Debug.WriteLine

// If you plan to fetch more student details directly within the dashboard:
// using Microsoft.Data.SqlClient;

namespace login
{
    public partial class dashboard : Form
    {
        // Private field to store the ID of the currently logged-in student
        private string currentStudentID;

        // Optional: If you fetch data directly from the dashboard, you might need this.
        // private string connectionString = "Server=matt_torres;Database=testdb;User Id=mattserver;Password=ssms;TrustServerCertificate=True;";

        // --- Constructor ---
        // This constructor accepts the student ID from the login or registration form
        public dashboard(string studentId)
        {
            InitializeComponent(); // Essential for loading your form's designed components

            this.currentStudentID = studentId; // Store the passed student ID

            // You can use this.currentStudentID here to customize the dashboard upon loading.
            // For example, set the window title or display the ID in a label.
            this.Text = $"Dashboard - Student ID: {this.currentStudentID}";

            // Example: If you have a label named lblDisplayStudentID on your dashboard
            // Label lblDisplayStudentID = this.Controls.Find("lblDisplayStudentID", true).FirstOrDefault() as Label;
            // if (lblDisplayStudentID != null)
            // {
            //     lblDisplayStudentID.Text = $"Logged in as: {this.currentStudentID}";
            // }

            // If you need to load more details about the student (like their name)
            // you could call a method here to fetch it from the database.
            // LoadAdditionalStudentDetails(this.currentStudentID);
        }

        /*
        // Optional: Method to load more student details from the database if needed
        private void LoadAdditionalStudentDetails(string studentIdToLoad)
        {
            // Make sure studentIdToLoad is a valid integer if your DB expects int
            if (!int.TryParse(studentIdToLoad, out int studentIdNumeric))
            {
                Debug.WriteLine("Dashboard: Invalid Student ID format for DB lookup.");
                return;
            }

            // using (SqlConnection con = new SqlConnection(connectionString))
            // {
            //     string query = "SELECT student_name FROM dbo.student WHERE studentID = @StudentID";
            //     using (SqlCommand cmd = new SqlCommand(query, con))
            //     {
            //         cmd.Parameters.AddWithValue("@StudentID", studentIdNumeric);
            //         try
            //         {
            //             con.Open();
            //             object result = cmd.ExecuteScalar();
            //             if (result != null)
            //             {
            //                 string studentName = result.ToString();
            //                 // Update a welcome label, e.g., lblWelcome.Text = $"Welcome, {studentName}!";
            //                 Debug.WriteLine($"Dashboard: Fetched student name: {studentName}");
            //             }
            //             else
            //             {
            //                 Debug.WriteLine($"Dashboard: No student found with ID {studentIdToLoad} to fetch name.");
            //             }
            //         }
            //         catch (Exception ex)
            //         {
            //             Debug.WriteLine($"Dashboard: Error fetching student details: {ex.Message}");
            //             // Consider showing a less technical error to the user or logging it more formally.
            //         }
            //     }
            // }
        }
        */

        // --- Event Handler for "Student Operations" Button ---
        private void button1_Click(object sender, EventArgs e) // Assumed to be for student_op
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot open student section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // How you instantiate student_op depends on its constructor:
            // Option 1: If student_op constructor is "public student_op(Form dashboard)"
            // student_op studentForm = new student_op(this);

            // Option 2: If student_op constructor is "public student_op(string studentID, Form dashboard)"
            // student_op studentForm = new student_op(this.currentStudentID, this);

            // Option 3: If student_op constructor is "public student_op(string studentID)"
            // student_op studentForm = new student_op(this.currentStudentID);

            // Option 4: If student_op constructor is parameterless "public student_op()"
            // student_op studentForm = new student_op();
            // In this case, student_op might have public properties to set the studentID if needed,
            // or it fetches student info in another way.

            // For now, assuming it takes at least the dashboard reference (as per previous code):
            // Replace this with the correct instantiation based on student_op.cs constructor.
            student_op studentForm = new student_op(this); // MODIFY THIS LINE based on student_op's actual constructor
                                                           // For example, if it needs studentID and dashboard:
                                                           // student_op studentForm = new student_op(this.currentStudentID, this);


            studentForm.Show();
            this.Hide();
        }

        // --- Event Handler for "Course Operations" Button ---
        private void buttonCourse_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot open course section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // This now correctly calls the firstpartcourse constructor that expects (string, Form)
            firstpartcourse courseForm = new firstpartcourse(this.currentStudentID, this);

            courseForm.Show();
            this.Hide();
        }

        // --- Event Handler for "Goal Operations" Button ---
        private void buttonGoal_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.currentStudentID))
            {
                MessageBox.Show("Student ID is not available. Cannot open goals section.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // How you instantiate goals_op depends on its constructor:
            // Option 1: If goals_op constructor is "public goals_op()" (as in your previous code)
            goals_op goalsForm = new goals_op();
            // If it's parameterless but needs the studentID for context (e.g., to save goals for this student),
            // goals_op might have a public property like: goalsForm.CurrentStudentId = this.currentStudentID;
            // Or, it might receive it through the GoalSubmittedEventArgs later.

            // Option 2: If goals_op constructor is "public goals_op(string studentID)"
            // goals_op goalsForm = new goals_op(this.currentStudentID);

            // Option 3: If goals_op constructor is "public goals_op(string studentID, Form dashboard)"
            // goals_op goalsForm = new goals_op(this.currentStudentID, this);

            // Using the parameterless constructor as per your prior code structure:
            // goals_op goalsForm = new goals_op(); // MODIFY THIS LINE if goals_op constructor changes

            goalsForm.GoalSubmitted += GoalsForm_GoalSubmitted;
            goalsForm.ShowDialog(); // ShowDialog is modal, execution pauses here until goalsForm is closed.
            goalsForm.GoalSubmitted -= GoalsForm_GoalSubmitted; // Unsubscribe after the form is closed.
        }

        // --- Handler for the GoalSubmitted event from goals_op ---
        private void GoalsForm_GoalSubmitted(object sender, GoalSubmittedEventArgs e)
        {
            Goal submittedGoal = e.SubmittedGoal;

            // Now you have the submittedGoal and the currentStudentID in the dashboard.
            // You can associate them, save to database, update UI, etc.
            MessageBox.Show($"Dashboard received Goal:\nTitle: {submittedGoal.Title}\nDue Date: {submittedGoal.DueDate.ToShortDateString()}\nDescription: {submittedGoal.Description}\nFor Student ID: {this.currentStudentID}", "Goal Received in Dashboard");

            // Example: Update a list of goals on the dashboard
            // lstMyGoals.Items.Add($"[{this.currentStudentID}] {submittedGoal.Title} - Due: {submittedGoal.DueDate.ToShortDateString()}");
        }

        // Any other methods or event handlers for your dashboard would go here.
        // For example, a "Logout" button:
        // private void btnLogout_Click(object sender, EventArgs e)
        // {
        //     frmLogin loginForm = new frmLogin();
        //     loginForm.Show();
        //     this.Close(); // Or this.Hide() if you want to keep it in memory. Close() is usually better for logout.
        // }
    }

    // Ensure these class definitions exist, preferably in their own .cs files within the 'login' namespace.
    // If they are already defined elsewhere in your project, you don't need to redefine them here.

    // public class Goal
    // {
    //     public string Title { get; set; }
    //     public DateTime DueDate { get; set; }
    //     public string Description { get; set; }
    //     // Optional: public string StudentID { get; set; } // If you want to store student ID directly in the Goal object
    // }

    // public class GoalSubmittedEventArgs : EventArgs
    // {
    //     public Goal SubmittedGoal { get; }
    //
    //     public GoalSubmittedEventArgs(Goal goal)
    //     {
    //         SubmittedGoal = goal;
    //     }
    // }
}