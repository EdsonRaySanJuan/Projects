﻿namespace login
{
    partial class classStanding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button1 = new Button();
            button2 = new Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label12 = new Label();
            label13 = new Label();
            txtQuizWeight = new TextBox();
            txtAssignmentWeight = new TextBox();
            txtSeatworkWeight = new TextBox();
            txtLaboratoryWeight = new TextBox();
            txtRecitationWeight = new TextBox();
            txtQuizScore1 = new TextBox();
            txtQuizScore2 = new TextBox();
            txtQuizScore3 = new TextBox();
            txtQuizScore4 = new TextBox();
            txtQuizScore5 = new TextBox();
            txtQuizScore6 = new TextBox();
            txtQuizScore7 = new TextBox();
            txtQuizScore8 = new TextBox();
            txtQuizScore9 = new TextBox();
            txtQuizScore10 = new TextBox();
            txtAssignmentScore1 = new TextBox();
            txtAssignmentScore2 = new TextBox();
            txtAssignmentScore3 = new TextBox();
            txtAssignmentScore4 = new TextBox();
            txtAssignmentScore5 = new TextBox();
            txtAssignmentScore6 = new TextBox();
            txtAssignmentScore7 = new TextBox();
            txtAssignmentScore8 = new TextBox();
            txtAssignmentScore9 = new TextBox();
            txtAssignmentScore10 = new TextBox();
            txtSeatworkScore1 = new TextBox();
            txtSeatworkScore2 = new TextBox();
            txtSeatworkScore3 = new TextBox();
            txtSeatworkScore4 = new TextBox();
            txtSeatworkScore5 = new TextBox();
            txtSeatworkScore6 = new TextBox();
            txtSeatworkScore7 = new TextBox();
            txtSeatworkScore8 = new TextBox();
            txtSeatworkScore9 = new TextBox();
            txtSeatworkScore10 = new TextBox();
            txtLaboratoryScore1 = new TextBox();
            txtLaboratoryScore2 = new TextBox();
            txtLaboratoryScore3 = new TextBox();
            txtLaboratoryScore4 = new TextBox();
            txtLaboratoryScore5 = new TextBox();
            txtLaboratoryScore6 = new TextBox();
            txtLaboratoryScore7 = new TextBox();
            txtLaboratoryScore8 = new TextBox();
            txtLaboratoryScore9 = new TextBox();
            txtLaboratoryScore10 = new TextBox();
            txtRecitationScore1 = new TextBox();
            txtRecitationScore2 = new TextBox();
            txtRecitationScore3 = new TextBox();
            txtRecitationScore4 = new TextBox();
            txtRecitationScore5 = new TextBox();
            txtRecitationScore6 = new TextBox();
            txtRecitationScore7 = new TextBox();
            txtRecitationScore8 = new TextBox();
            txtRecitationScore9 = new TextBox();
            txtRecitationScore10 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label1.Location = new Point(26, 18);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(73, 24);
            label1.TabIndex = 0;
            label1.Text = "label1";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label2.Location = new Point(26, 42);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(170, 24);
            label2.TabIndex = 1;
            label2.Text = "Class Standing";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label3.ForeColor = Color.Blue;
            label3.Location = new Point(26, 66);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(191, 24);
            label3.TabIndex = 2;
            label3.Text = "Course Subject: ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MS UI Gothic", 18F, FontStyle.Bold);
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(211, 66);
            label4.Name = "label4";
            label4.Size = new Size(73, 24);
            label4.TabIndex = 3;
            label4.Text = "label4";
            label4.Click += label4_Click;
            // 
            // button1
            // 
            button1.Font = new Font("MS UI Gothic", 12F, FontStyle.Bold);
            button1.Location = new Point(375, 501);
            button1.Name = "button1";
            button1.Size = new Size(89, 41);
            button1.TabIndex = 7;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("MS UI Gothic", 12F, FontStyle.Bold);
            button2.Location = new Point(495, 501);
            button2.Name = "button2";
            button2.Size = new Size(89, 41);
            button2.TabIndex = 8;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label9.Location = new Point(781, 109);
            label9.Name = "label9";
            label9.Size = new Size(88, 21);
            label9.TabIndex = 26;
            label9.Text = "Recitation";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.Location = new Point(584, 113);
            label8.Name = "label8";
            label8.Size = new Size(94, 21);
            label8.TabIndex = 24;
            label8.Text = "Laboratory";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.Location = new Point(396, 109);
            label7.Name = "label7";
            label7.Size = new Size(81, 21);
            label7.TabIndex = 22;
            label7.Text = "Seatwork";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.Location = new Point(211, 109);
            label6.Name = "label6";
            label6.Size = new Size(100, 21);
            label6.TabIndex = 20;
            label6.Text = "Assignment";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label12.Location = new Point(26, 109);
            label12.Name = "label12";
            label12.Size = new Size(45, 21);
            label12.TabIndex = 15;
            label12.Text = "Quiz";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(26, 90);
            label13.Name = "label13";
            label13.Size = new Size(0, 27);
            label13.TabIndex = 14;
            // 
            // txtQuizWeight
            // 
            txtQuizWeight.Location = new Point(74, 104);
            txtQuizWeight.Multiline = true;
            txtQuizWeight.Name = "txtQuizWeight";
            txtQuizWeight.Size = new Size(72, 23);
            txtQuizWeight.TabIndex = 78;
            // 
            // txtAssignmentWeight
            // 
            txtAssignmentWeight.Location = new Point(317, 104);
            txtAssignmentWeight.Multiline = true;
            txtAssignmentWeight.Name = "txtAssignmentWeight";
            txtAssignmentWeight.Size = new Size(72, 23);
            txtAssignmentWeight.TabIndex = 79;
            // 
            // txtSeatworkWeight
            // 
            txtSeatworkWeight.Location = new Point(476, 108);
            txtSeatworkWeight.Multiline = true;
            txtSeatworkWeight.Name = "txtSeatworkWeight";
            txtSeatworkWeight.Size = new Size(72, 23);
            txtSeatworkWeight.TabIndex = 80;
            txtSeatworkWeight.TextChanged += txtSeatworkWeight_TextChanged;
            // 
            // txtLaboratoryWeight
            // 
            txtLaboratoryWeight.Location = new Point(684, 108);
            txtLaboratoryWeight.Multiline = true;
            txtLaboratoryWeight.Name = "txtLaboratoryWeight";
            txtLaboratoryWeight.Size = new Size(72, 23);
            txtLaboratoryWeight.TabIndex = 81;
            // 
            // txtRecitationWeight
            // 
            txtRecitationWeight.Location = new Point(874, 104);
            txtRecitationWeight.Multiline = true;
            txtRecitationWeight.Name = "txtRecitationWeight";
            txtRecitationWeight.Size = new Size(51, 23);
            txtRecitationWeight.TabIndex = 82;
            // 
            // txtQuizScore1
            // 
            txtQuizScore1.Location = new Point(26, 145);
            txtQuizScore1.Multiline = true;
            txtQuizScore1.Name = "txtQuizScore1";
            txtQuizScore1.Size = new Size(120, 23);
            txtQuizScore1.TabIndex = 83;
            txtQuizScore1.TextChanged += textBox1_TextChanged_1;
            // 
            // txtQuizScore2
            // 
            txtQuizScore2.Location = new Point(26, 174);
            txtQuizScore2.Multiline = true;
            txtQuizScore2.Name = "txtQuizScore2";
            txtQuizScore2.Size = new Size(120, 23);
            txtQuizScore2.TabIndex = 84;
            txtQuizScore2.TextChanged += textBox2_TextChanged_1;
            // 
            // txtQuizScore3
            // 
            txtQuizScore3.Location = new Point(26, 203);
            txtQuizScore3.Multiline = true;
            txtQuizScore3.Name = "txtQuizScore3";
            txtQuizScore3.Size = new Size(120, 23);
            txtQuizScore3.TabIndex = 85;
            txtQuizScore3.TextChanged += textBox3_TextChanged_1;
            // 
            // txtQuizScore4
            // 
            txtQuizScore4.Location = new Point(26, 232);
            txtQuizScore4.Multiline = true;
            txtQuizScore4.Name = "txtQuizScore4";
            txtQuizScore4.Size = new Size(120, 23);
            txtQuizScore4.TabIndex = 86;
            txtQuizScore4.TextChanged += textBox4_TextChanged_1;
            // 
            // txtQuizScore5
            // 
            txtQuizScore5.Location = new Point(26, 261);
            txtQuizScore5.Multiline = true;
            txtQuizScore5.Name = "txtQuizScore5";
            txtQuizScore5.Size = new Size(120, 23);
            txtQuizScore5.TabIndex = 87;
            txtQuizScore5.TextChanged += textBox5_TextChanged_1;
            // 
            // txtQuizScore6
            // 
            txtQuizScore6.Location = new Point(26, 290);
            txtQuizScore6.Multiline = true;
            txtQuizScore6.Name = "txtQuizScore6";
            txtQuizScore6.Size = new Size(120, 23);
            txtQuizScore6.TabIndex = 88;
            txtQuizScore6.TextChanged += textBox6_TextChanged_1;
            // 
            // txtQuizScore7
            // 
            txtQuizScore7.Location = new Point(26, 319);
            txtQuizScore7.Multiline = true;
            txtQuizScore7.Name = "txtQuizScore7";
            txtQuizScore7.Size = new Size(120, 23);
            txtQuizScore7.TabIndex = 89;
            txtQuizScore7.TextChanged += textBox7_TextChanged_1;
            // 
            // txtQuizScore8
            // 
            txtQuizScore8.Location = new Point(26, 348);
            txtQuizScore8.Multiline = true;
            txtQuizScore8.Name = "txtQuizScore8";
            txtQuizScore8.Size = new Size(120, 23);
            txtQuizScore8.TabIndex = 90;
            txtQuizScore8.TextChanged += textBox8_TextChanged_1;
            // 
            // txtQuizScore9
            // 
            txtQuizScore9.Location = new Point(26, 377);
            txtQuizScore9.Multiline = true;
            txtQuizScore9.Name = "txtQuizScore9";
            txtQuizScore9.Size = new Size(120, 23);
            txtQuizScore9.TabIndex = 91;
            txtQuizScore9.TextChanged += textBox9_TextChanged_1;
            // 
            // txtQuizScore10
            // 
            txtQuizScore10.Location = new Point(26, 406);
            txtQuizScore10.Multiline = true;
            txtQuizScore10.Name = "txtQuizScore10";
            txtQuizScore10.Size = new Size(120, 23);
            txtQuizScore10.TabIndex = 92;
            txtQuizScore10.TextChanged += textBox10_TextChanged_1;
            // 
            // txtAssignmentScore1
            // 
            txtAssignmentScore1.Location = new Point(211, 145);
            txtAssignmentScore1.Multiline = true;
            txtAssignmentScore1.Name = "txtAssignmentScore1";
            txtAssignmentScore1.Size = new Size(120, 23);
            txtAssignmentScore1.TabIndex = 93;
            txtAssignmentScore1.TextChanged += textBox11_TextChanged_1;
            // 
            // txtAssignmentScore2
            // 
            txtAssignmentScore2.Location = new Point(211, 174);
            txtAssignmentScore2.Multiline = true;
            txtAssignmentScore2.Name = "txtAssignmentScore2";
            txtAssignmentScore2.Size = new Size(120, 23);
            txtAssignmentScore2.TabIndex = 94;
            txtAssignmentScore2.TextChanged += textBox12_TextChanged_1;
            // 
            // txtAssignmentScore3
            // 
            txtAssignmentScore3.Location = new Point(211, 203);
            txtAssignmentScore3.Multiline = true;
            txtAssignmentScore3.Name = "txtAssignmentScore3";
            txtAssignmentScore3.Size = new Size(120, 23);
            txtAssignmentScore3.TabIndex = 95;
            txtAssignmentScore3.TextChanged += textBox13_TextChanged_1;
            // 
            // txtAssignmentScore4
            // 
            txtAssignmentScore4.Location = new Point(211, 232);
            txtAssignmentScore4.Multiline = true;
            txtAssignmentScore4.Name = "txtAssignmentScore4";
            txtAssignmentScore4.Size = new Size(120, 23);
            txtAssignmentScore4.TabIndex = 96;
            txtAssignmentScore4.TextChanged += textBox14_TextChanged_1;
            // 
            // txtAssignmentScore5
            // 
            txtAssignmentScore5.Location = new Point(211, 261);
            txtAssignmentScore5.Multiline = true;
            txtAssignmentScore5.Name = "txtAssignmentScore5";
            txtAssignmentScore5.Size = new Size(120, 23);
            txtAssignmentScore5.TabIndex = 97;
            txtAssignmentScore5.TextChanged += textBox15_TextChanged_1;
            // 
            // txtAssignmentScore6
            // 
            txtAssignmentScore6.Location = new Point(211, 290);
            txtAssignmentScore6.Multiline = true;
            txtAssignmentScore6.Name = "txtAssignmentScore6";
            txtAssignmentScore6.Size = new Size(120, 23);
            txtAssignmentScore6.TabIndex = 98;
            txtAssignmentScore6.TextChanged += textBox16_TextChanged_1;
            // 
            // txtAssignmentScore7
            // 
            txtAssignmentScore7.Location = new Point(211, 319);
            txtAssignmentScore7.Multiline = true;
            txtAssignmentScore7.Name = "txtAssignmentScore7";
            txtAssignmentScore7.Size = new Size(120, 23);
            txtAssignmentScore7.TabIndex = 99;
            txtAssignmentScore7.TextChanged += textBox17_TextChanged_1;
            // 
            // txtAssignmentScore8
            // 
            txtAssignmentScore8.Location = new Point(211, 348);
            txtAssignmentScore8.Multiline = true;
            txtAssignmentScore8.Name = "txtAssignmentScore8";
            txtAssignmentScore8.Size = new Size(120, 23);
            txtAssignmentScore8.TabIndex = 100;
            txtAssignmentScore8.TextChanged += textBox18_TextChanged_1;
            // 
            // txtAssignmentScore9
            // 
            txtAssignmentScore9.Location = new Point(211, 377);
            txtAssignmentScore9.Multiline = true;
            txtAssignmentScore9.Name = "txtAssignmentScore9";
            txtAssignmentScore9.Size = new Size(120, 23);
            txtAssignmentScore9.TabIndex = 101;
            txtAssignmentScore9.TextChanged += textBox19_TextChanged_1;
            // 
            // txtAssignmentScore10
            // 
            txtAssignmentScore10.Location = new Point(211, 406);
            txtAssignmentScore10.Multiline = true;
            txtAssignmentScore10.Name = "txtAssignmentScore10";
            txtAssignmentScore10.Size = new Size(120, 23);
            txtAssignmentScore10.TabIndex = 102;
            txtAssignmentScore10.TextChanged += textBox20_TextChanged_1;
            // 
            // txtSeatworkScore1
            // 
            txtSeatworkScore1.Location = new Point(396, 145);
            txtSeatworkScore1.Multiline = true;
            txtSeatworkScore1.Name = "txtSeatworkScore1";
            txtSeatworkScore1.Size = new Size(120, 23);
            txtSeatworkScore1.TabIndex = 103;
            txtSeatworkScore1.TextChanged += textBox21_TextChanged_1;
            // 
            // txtSeatworkScore2
            // 
            txtSeatworkScore2.Location = new Point(396, 174);
            txtSeatworkScore2.Multiline = true;
            txtSeatworkScore2.Name = "txtSeatworkScore2";
            txtSeatworkScore2.Size = new Size(120, 23);
            txtSeatworkScore2.TabIndex = 104;
            txtSeatworkScore2.TextChanged += textBox22_TextChanged_1;
            // 
            // txtSeatworkScore3
            // 
            txtSeatworkScore3.Location = new Point(396, 203);
            txtSeatworkScore3.Multiline = true;
            txtSeatworkScore3.Name = "txtSeatworkScore3";
            txtSeatworkScore3.Size = new Size(120, 23);
            txtSeatworkScore3.TabIndex = 105;
            txtSeatworkScore3.TextChanged += textBox23_TextChanged_1;
            // 
            // txtSeatworkScore4
            // 
            txtSeatworkScore4.Location = new Point(396, 232);
            txtSeatworkScore4.Multiline = true;
            txtSeatworkScore4.Name = "txtSeatworkScore4";
            txtSeatworkScore4.Size = new Size(120, 23);
            txtSeatworkScore4.TabIndex = 106;
            txtSeatworkScore4.TextChanged += textBox24_TextChanged_1;
            // 
            // txtSeatworkScore5
            // 
            txtSeatworkScore5.Location = new Point(396, 261);
            txtSeatworkScore5.Multiline = true;
            txtSeatworkScore5.Name = "txtSeatworkScore5";
            txtSeatworkScore5.Size = new Size(120, 23);
            txtSeatworkScore5.TabIndex = 107;
            txtSeatworkScore5.TextChanged += textBox25_TextChanged_1;
            // 
            // txtSeatworkScore6
            // 
            txtSeatworkScore6.Location = new Point(396, 290);
            txtSeatworkScore6.Multiline = true;
            txtSeatworkScore6.Name = "txtSeatworkScore6";
            txtSeatworkScore6.Size = new Size(120, 23);
            txtSeatworkScore6.TabIndex = 108;
            txtSeatworkScore6.TextChanged += textBox26_TextChanged_1;
            // 
            // txtSeatworkScore7
            // 
            txtSeatworkScore7.Location = new Point(396, 319);
            txtSeatworkScore7.Multiline = true;
            txtSeatworkScore7.Name = "txtSeatworkScore7";
            txtSeatworkScore7.Size = new Size(120, 23);
            txtSeatworkScore7.TabIndex = 109;
            txtSeatworkScore7.TextChanged += textBox27_TextChanged_1;
            // 
            // txtSeatworkScore8
            // 
            txtSeatworkScore8.Location = new Point(396, 348);
            txtSeatworkScore8.Multiline = true;
            txtSeatworkScore8.Name = "txtSeatworkScore8";
            txtSeatworkScore8.Size = new Size(120, 23);
            txtSeatworkScore8.TabIndex = 110;
            txtSeatworkScore8.TextChanged += textBox28_TextChanged_1;
            // 
            // txtSeatworkScore9
            // 
            txtSeatworkScore9.Location = new Point(396, 377);
            txtSeatworkScore9.Multiline = true;
            txtSeatworkScore9.Name = "txtSeatworkScore9";
            txtSeatworkScore9.Size = new Size(120, 23);
            txtSeatworkScore9.TabIndex = 111;
            txtSeatworkScore9.TextChanged += textBox29_TextChanged_1;
            // 
            // txtSeatworkScore10
            // 
            txtSeatworkScore10.Location = new Point(396, 406);
            txtSeatworkScore10.Multiline = true;
            txtSeatworkScore10.Name = "txtSeatworkScore10";
            txtSeatworkScore10.Size = new Size(120, 23);
            txtSeatworkScore10.TabIndex = 111;
            txtSeatworkScore10.TextChanged += textBox30_TextChanged_1;
            // 
            // txtLaboratoryScore1
            // 
            txtLaboratoryScore1.Location = new Point(591, 145);
            txtLaboratoryScore1.Multiline = true;
            txtLaboratoryScore1.Name = "txtLaboratoryScore1";
            txtLaboratoryScore1.Size = new Size(120, 23);
            txtLaboratoryScore1.TabIndex = 112;
            txtLaboratoryScore1.TextChanged += textBox31_TextChanged_1;
            // 
            // txtLaboratoryScore2
            // 
            txtLaboratoryScore2.Location = new Point(591, 174);
            txtLaboratoryScore2.Multiline = true;
            txtLaboratoryScore2.Name = "txtLaboratoryScore2";
            txtLaboratoryScore2.Size = new Size(120, 23);
            txtLaboratoryScore2.TabIndex = 113;
            txtLaboratoryScore2.TextChanged += textBox32_TextChanged_1;
            // 
            // txtLaboratoryScore3
            // 
            txtLaboratoryScore3.Location = new Point(591, 203);
            txtLaboratoryScore3.Multiline = true;
            txtLaboratoryScore3.Name = "txtLaboratoryScore3";
            txtLaboratoryScore3.Size = new Size(120, 23);
            txtLaboratoryScore3.TabIndex = 114;
            txtLaboratoryScore3.TextChanged += textBox33_TextChanged_1;
            // 
            // txtLaboratoryScore4
            // 
            txtLaboratoryScore4.Location = new Point(591, 232);
            txtLaboratoryScore4.Multiline = true;
            txtLaboratoryScore4.Name = "txtLaboratoryScore4";
            txtLaboratoryScore4.Size = new Size(120, 23);
            txtLaboratoryScore4.TabIndex = 115;
            txtLaboratoryScore4.TextChanged += textBox34_TextChanged_1;
            // 
            // txtLaboratoryScore5
            // 
            txtLaboratoryScore5.Location = new Point(591, 261);
            txtLaboratoryScore5.Multiline = true;
            txtLaboratoryScore5.Name = "txtLaboratoryScore5";
            txtLaboratoryScore5.Size = new Size(120, 23);
            txtLaboratoryScore5.TabIndex = 116;
            txtLaboratoryScore5.TextChanged += textBox35_TextChanged_1;
            // 
            // txtLaboratoryScore6
            // 
            txtLaboratoryScore6.Location = new Point(591, 290);
            txtLaboratoryScore6.Multiline = true;
            txtLaboratoryScore6.Name = "txtLaboratoryScore6";
            txtLaboratoryScore6.Size = new Size(120, 23);
            txtLaboratoryScore6.TabIndex = 117;
            txtLaboratoryScore6.TextChanged += textBox36_TextChanged_1;
            // 
            // txtLaboratoryScore7
            // 
            txtLaboratoryScore7.Location = new Point(591, 319);
            txtLaboratoryScore7.Multiline = true;
            txtLaboratoryScore7.Name = "txtLaboratoryScore7";
            txtLaboratoryScore7.Size = new Size(120, 23);
            txtLaboratoryScore7.TabIndex = 118;
            txtLaboratoryScore7.TextChanged += textBox37_TextChanged_1;
            // 
            // txtLaboratoryScore8
            // 
            txtLaboratoryScore8.Location = new Point(591, 348);
            txtLaboratoryScore8.Multiline = true;
            txtLaboratoryScore8.Name = "txtLaboratoryScore8";
            txtLaboratoryScore8.Size = new Size(120, 23);
            txtLaboratoryScore8.TabIndex = 119;
            txtLaboratoryScore8.TextChanged += textBox38_TextChanged_1;
            // 
            // txtLaboratoryScore9
            // 
            txtLaboratoryScore9.Location = new Point(591, 377);
            txtLaboratoryScore9.Multiline = true;
            txtLaboratoryScore9.Name = "txtLaboratoryScore9";
            txtLaboratoryScore9.Size = new Size(120, 23);
            txtLaboratoryScore9.TabIndex = 120;
            txtLaboratoryScore9.TextChanged += textBox39_TextChanged_1;
            // 
            // txtLaboratoryScore10
            // 
            txtLaboratoryScore10.Location = new Point(591, 406);
            txtLaboratoryScore10.Multiline = true;
            txtLaboratoryScore10.Name = "txtLaboratoryScore10";
            txtLaboratoryScore10.Size = new Size(120, 23);
            txtLaboratoryScore10.TabIndex = 121;
            txtLaboratoryScore10.TextChanged += textBox40_TextChanged_1;
            // 
            // txtRecitationScore1
            // 
            txtRecitationScore1.Location = new Point(781, 145);
            txtRecitationScore1.Multiline = true;
            txtRecitationScore1.Name = "txtRecitationScore1";
            txtRecitationScore1.Size = new Size(120, 23);
            txtRecitationScore1.TabIndex = 122;
            txtRecitationScore1.TextChanged += textBox41_TextChanged_1;
            // 
            // txtRecitationScore2
            // 
            txtRecitationScore2.Location = new Point(781, 174);
            txtRecitationScore2.Multiline = true;
            txtRecitationScore2.Name = "txtRecitationScore2";
            txtRecitationScore2.Size = new Size(120, 23);
            txtRecitationScore2.TabIndex = 123;
            txtRecitationScore2.TextChanged += textBox42_TextChanged_1;
            // 
            // txtRecitationScore3
            // 
            txtRecitationScore3.Location = new Point(781, 203);
            txtRecitationScore3.Multiline = true;
            txtRecitationScore3.Name = "txtRecitationScore3";
            txtRecitationScore3.Size = new Size(120, 23);
            txtRecitationScore3.TabIndex = 124;
            txtRecitationScore3.TextChanged += textBox43_TextChanged_1;
            // 
            // txtRecitationScore4
            // 
            txtRecitationScore4.Location = new Point(781, 232);
            txtRecitationScore4.Multiline = true;
            txtRecitationScore4.Name = "txtRecitationScore4";
            txtRecitationScore4.Size = new Size(120, 23);
            txtRecitationScore4.TabIndex = 125;
            txtRecitationScore4.TextChanged += textBox44_TextChanged_1;
            // 
            // txtRecitationScore5
            // 
            txtRecitationScore5.Location = new Point(781, 261);
            txtRecitationScore5.Multiline = true;
            txtRecitationScore5.Name = "txtRecitationScore5";
            txtRecitationScore5.Size = new Size(120, 23);
            txtRecitationScore5.TabIndex = 125;
            txtRecitationScore5.TextChanged += textBox45_TextChanged_1;
            // 
            // txtRecitationScore6
            // 
            txtRecitationScore6.Location = new Point(781, 290);
            txtRecitationScore6.Multiline = true;
            txtRecitationScore6.Name = "txtRecitationScore6";
            txtRecitationScore6.Size = new Size(120, 23);
            txtRecitationScore6.TabIndex = 126;
            txtRecitationScore6.TextChanged += textBox46_TextChanged_1;
            // 
            // txtRecitationScore7
            // 
            txtRecitationScore7.Location = new Point(781, 319);
            txtRecitationScore7.Multiline = true;
            txtRecitationScore7.Name = "txtRecitationScore7";
            txtRecitationScore7.Size = new Size(120, 23);
            txtRecitationScore7.TabIndex = 126;
            txtRecitationScore7.TextChanged += textBox47_TextChanged_1;
            // 
            // txtRecitationScore8
            // 
            txtRecitationScore8.Location = new Point(781, 348);
            txtRecitationScore8.Multiline = true;
            txtRecitationScore8.Name = "txtRecitationScore8";
            txtRecitationScore8.Size = new Size(120, 23);
            txtRecitationScore8.TabIndex = 127;
            txtRecitationScore8.TextChanged += textBox48_TextChanged_1;
            // 
            // txtRecitationScore9
            // 
            txtRecitationScore9.Location = new Point(781, 377);
            txtRecitationScore9.Multiline = true;
            txtRecitationScore9.Name = "txtRecitationScore9";
            txtRecitationScore9.Size = new Size(120, 23);
            txtRecitationScore9.TabIndex = 128;
            txtRecitationScore9.TextChanged += textBox49_TextChanged_1;
            // 
            // txtRecitationScore10
            // 
            txtRecitationScore10.Location = new Point(781, 406);
            txtRecitationScore10.Multiline = true;
            txtRecitationScore10.Name = "txtRecitationScore10";
            txtRecitationScore10.Size = new Size(120, 23);
            txtRecitationScore10.TabIndex = 129;
            txtRecitationScore10.TextChanged += textBox50_TextChanged_1;
            // 
            // classStanding
            // 
            AutoScaleDimensions = new SizeF(15F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(937, 569);
            Controls.Add(txtRecitationScore10);
            Controls.Add(txtRecitationScore9);
            Controls.Add(txtRecitationScore8);
            Controls.Add(txtRecitationScore7);
            Controls.Add(txtRecitationScore6);
            Controls.Add(txtRecitationScore5);
            Controls.Add(txtQuizScore1);
            Controls.Add(txtQuizScore2);
            Controls.Add(txtQuizScore3);
            Controls.Add(txtQuizScore4);
            Controls.Add(txtQuizScore5);
            Controls.Add(txtQuizScore6);
            Controls.Add(txtQuizScore7);
            Controls.Add(txtQuizScore8);
            Controls.Add(txtQuizScore9);
            Controls.Add(txtQuizScore10);
            Controls.Add(txtAssignmentScore1);
            Controls.Add(txtAssignmentScore2);
            Controls.Add(txtAssignmentScore3);
            Controls.Add(txtAssignmentScore4);
            Controls.Add(txtAssignmentScore5);
            Controls.Add(txtAssignmentScore6);
            Controls.Add(txtAssignmentScore7);
            Controls.Add(txtAssignmentScore8);
            Controls.Add(txtAssignmentScore9);
            Controls.Add(txtAssignmentScore10);
            Controls.Add(txtSeatworkScore1);
            Controls.Add(txtSeatworkScore2);
            Controls.Add(txtSeatworkScore3);
            Controls.Add(txtSeatworkScore4);
            Controls.Add(txtSeatworkScore5);
            Controls.Add(txtSeatworkScore6);
            Controls.Add(txtSeatworkScore7);
            Controls.Add(txtSeatworkScore8);
            Controls.Add(txtSeatworkScore9);
            Controls.Add(txtSeatworkScore10);
            Controls.Add(txtLaboratoryScore1);
            Controls.Add(txtLaboratoryScore2);
            Controls.Add(txtLaboratoryScore3);
            Controls.Add(txtLaboratoryScore4);
            Controls.Add(txtLaboratoryScore5);
            Controls.Add(txtLaboratoryScore6);
            Controls.Add(txtLaboratoryScore7);
            Controls.Add(txtLaboratoryScore8);
            Controls.Add(txtLaboratoryScore9);
            Controls.Add(txtLaboratoryScore10);
            Controls.Add(txtRecitationScore1);
            Controls.Add(txtRecitationScore2);
            Controls.Add(txtRecitationScore3);
            Controls.Add(txtRecitationScore4);
            Controls.Add(txtRecitationWeight);
            Controls.Add(txtLaboratoryWeight);
            Controls.Add(txtSeatworkWeight);
            Controls.Add(txtAssignmentWeight);
            Controls.Add(txtQuizWeight);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold);
            Margin = new Padding(6, 5, 6, 5);
            Name = "classStanding";
            Text = "classStanding";
            Load += classStanding_Load;
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtQuizWeight;
        private System.Windows.Forms.TextBox txtAssignmentWeight;
        private System.Windows.Forms.TextBox txtSeatworkWeight;
        private System.Windows.Forms.TextBox txtLaboratoryWeight;
        private System.Windows.Forms.TextBox txtRecitationWeight;
        private System.Windows.Forms.TextBox txtQuizScore1;
        private System.Windows.Forms.TextBox txtQuizScore2;
        private System.Windows.Forms.TextBox txtQuizScore3;
        private System.Windows.Forms.TextBox txtQuizScore4;
        private System.Windows.Forms.TextBox txtQuizScore5;
        private System.Windows.Forms.TextBox txtQuizScore6;
        private System.Windows.Forms.TextBox txtQuizScore7;
        private System.Windows.Forms.TextBox txtQuizScore8;
        private System.Windows.Forms.TextBox txtQuizScore9;
        private System.Windows.Forms.TextBox txtQuizScore10;
        private System.Windows.Forms.TextBox txtAssignmentScore1;
        private System.Windows.Forms.TextBox txtAssignmentScore2;
        private System.Windows.Forms.TextBox txtAssignmentScore3;
        private System.Windows.Forms.TextBox txtAssignmentScore4;
        private System.Windows.Forms.TextBox txtAssignmentScore5;
        private System.Windows.Forms.TextBox txtAssignmentScore6;
        private System.Windows.Forms.TextBox txtAssignmentScore7;
        private System.Windows.Forms.TextBox txtAssignmentScore8;
        private System.Windows.Forms.TextBox txtAssignmentScore9;
        private System.Windows.Forms.TextBox txtAssignmentScore10;
        private System.Windows.Forms.TextBox txtSeatworkScore1;
        private System.Windows.Forms.TextBox txtSeatworkScore2;
        private System.Windows.Forms.TextBox txtSeatworkScore3;
        private System.Windows.Forms.TextBox txtSeatworkScore4;
        private System.Windows.Forms.TextBox txtSeatworkScore5;
        private System.Windows.Forms.TextBox txtSeatworkScore6;
        private System.Windows.Forms.TextBox txtSeatworkScore7;
        private System.Windows.Forms.TextBox txtSeatworkScore8;
        private System.Windows.Forms.TextBox txtSeatworkScore9;
        private System.Windows.Forms.TextBox txtSeatworkScore10;
        private System.Windows.Forms.TextBox txtLaboratoryScore1;
        private System.Windows.Forms.TextBox txtLaboratoryScore2;
        private System.Windows.Forms.TextBox txtLaboratoryScore3;
        private System.Windows.Forms.TextBox txtLaboratoryScore4;
        private System.Windows.Forms.TextBox txtLaboratoryScore5;
        private System.Windows.Forms.TextBox txtLaboratoryScore6;
        private System.Windows.Forms.TextBox txtLaboratoryScore7;
        private System.Windows.Forms.TextBox txtLaboratoryScore8;
        private System.Windows.Forms.TextBox txtLaboratoryScore9;
        private System.Windows.Forms.TextBox txtLaboratoryScore10;
        private System.Windows.Forms.TextBox txtRecitationScore1;
        private System.Windows.Forms.TextBox txtRecitationScore2;
        private System.Windows.Forms.TextBox txtRecitationScore3;
        private System.Windows.Forms.TextBox txtRecitationScore4;
        private System.Windows.Forms.TextBox txtRecitationScore5;
        private System.Windows.Forms.TextBox txtRecitationScore6;
        private System.Windows.Forms.TextBox txtRecitationScore7;
        private System.Windows.Forms.TextBox txtRecitationScore8;
        private System.Windows.Forms.TextBox txtRecitationScore9;
        private System.Windows.Forms.TextBox txtRecitationScore10;
    }
}