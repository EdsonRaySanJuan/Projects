﻿// firstpartcourse.cs
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace login
{
    public partial class firstpartcourse : Form
    {
        private Form dashboardFormInstance;
        private string currentStudentID; // Assuming studentID is passed to this form

        private string collectedSchoolYear;
        private string collectedSemester;
        private int collectedTotalCourses;
        private int generatedAcademicPeriodId; // ID generated when saving AcademicPeriod

        // MODIFIED: Using the connection string you provided
        private string connectionString = "Server=EDSON-LAPTOP;Database=dbms_proj;User Id=ssms;Password=ssms;TrustServerCertificate=True;";

        // --- Constructors ---

        // Constructor updated to accept studentID and dashboard reference
        public firstpartcourse(string studentID, Form dashboard)
        {
            InitializeComponent();
            this.currentStudentID = studentID; // Store the passed studentID
            this.dashboardFormInstance = dashboard; // Store the dashboard reference
            this.Load += Firstpartcourse_Load;
        }

        // Parameterless constructor (for designer)
        public firstpartcourse()
        {
            InitializeComponent();
            this.Load += Firstpartcourse_Load;
            // Add Load event handler for parameterless context if needed
            this.Load += (s, e) => HandleParameterlessConstructorContext();
        }

        private void HandleParameterlessConstructorContext()
        {
            // This checks if required parameters (studentID, dashboard) were NOT passed via a proper constructor
            if (dashboardFormInstance == null || string.IsNullOrEmpty(currentStudentID))
            {
                Debug.WriteLine("Warning: firstpartcourse form initialized without dashboard reference or studentID.");
                MessageBox.Show("Application was not started correctly. Missing student or dashboard info.", "Startup Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Optionally disable controls or close the form if it's in an invalid state
                EnableFormControls(false); // Example: Disable input/buttons
            }
        }

        // Helper to enable/disable controls (assuming button1 is Submit, button2 is Clear)
        private void EnableFormControls(bool enable)
        {
            Control[] foundBtn1 = this.Controls.Find("button1", true);
            if (foundBtn1.Length > 0 && foundBtn1[0] is Button btn1) btn1.Enabled = enable;
            Control[] foundBtn2 = this.Controls.Find("button2", true);
            if (foundBtn2.Length > 0 && foundBtn2[0] is Button btn2) btn2.Enabled = enable;
            // Add other controls like textboxes, comboboxes, numericupdown if needed
        }

        // Helper to find controls recursively (from your code)
        private Control FindControlRecursive(Control root, string name)
        {
            if (root == null) return null;
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, name);
                if (t != null) return t;
            }
            return null;
        }


        private void Firstpartcourse_Load(object sender, EventArgs e)
        {
            HandleParameterlessConstructorContext(); // Perform checks on load

            // Assumed control names: "comboBox1" (SchoolYear), "comboBox2" (Semester),
            // "numericUpDownNumCourses" or "textBox1" (NumCourses) - Check your designer file.

            if (FindControlRecursive(this, "comboBox1") is ComboBox cbSchoolYear)
            {
                cbSchoolYear.Items.Clear();
                cbSchoolYear.Items.Add("2023-2024");
                cbSchoolYear.Items.Add("2024-2025");
                cbSchoolYear.Items.Add("2025-2026");
                // Optional: set default selected index if needed
                // cbSchoolYear.SelectedIndex = 0;
            }
            else { Debug.WriteLine("Warning: Control 'comboBox1' for School Year not found."); }

            if (FindControlRecursive(this, "comboBox2") is ComboBox cbSemester)
            {
                cbSemester.Items.Clear();
                cbSemester.Items.Add("1st Semester");
                cbSemester.Items.Add("2nd Semester");
                cbSemester.Items.Add("Summer");
                // Optional: set default selected index if needed
                // cbSemester.SelectedIndex = 0;
            }
            else { Debug.WriteLine("Warning: Control 'comboBox2' for Semester not found."); }

            Control numCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBox1");
            if (numCoursesControl is NumericUpDown numCourses)
            {
                numCourses.Minimum = 1;
                numCourses.Maximum = 10; // Adjust max if you have more forms
                numCourses.Value = 1;
            }
            else if (numCoursesControl is TextBox txtNumCourses)
            {
                txtNumCourses.Text = "1";
            }
            else { Debug.WriteLine("Warning: Control for Number of Courses ('numericUpDownNumCourses' or 'textBox1') not found."); }


            // Set initial focus
            Control initialFocusControl = FindControlRecursive(this, "comboBox1") ?? FindControlRecursive(this, "textBoxSchoolYear");
            if (initialFocusControl != null)
            {
                initialFocusControl.Focus();
            }
        }

        // submit button (button1) click handler
        private void button1_Click(object sender, EventArgs e)
        {
            string schoolYearInput = "";
            string semesterInput = "";
            int numberOfCoursesInput = 0;

            // Get input from UI controls
            Control syControl = FindControlRecursive(this, "comboBox1") ?? FindControlRecursive(this, "textBoxSchoolYear"); // Assuming comboBox1 or textBoxSchoolYear
            if (syControl is ComboBox cbSchoolYear && cbSchoolYear.SelectedItem != null)
            {
                schoolYearInput = cbSchoolYear.SelectedItem.ToString();
            }
            else if (syControl is TextBox txtSchoolYear)
            {
                schoolYearInput = txtSchoolYear.Text.Trim();
            }
            else { MessageBox.Show("Configuration Error: School Year control not found.", "Control Missing"); return; }

            Control semControl = FindControlRecursive(this, "comboBox2") ?? FindControlRecursive(this, "textBoxSemester"); // Assuming comboBox2 or textBoxSemester
            if (semControl is ComboBox cbSemester && cbSemester.SelectedItem != null)
            {
                semesterInput = cbSemester.SelectedItem.ToString();
            }
            else if (semControl is TextBox txtSemester)
            {
                semesterInput = txtSemester.Text.Trim();
            }
            else { MessageBox.Show("Configuration Error: Semester control not found.", "Control Missing"); return; }


            Control numCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBox1"); // Assuming numericUpDownNumCourses or textBox1
            if (numCoursesControl is NumericUpDown numCourses)
            {
                numberOfCoursesInput = (int)numCourses.Value;
            }
            else if (numCoursesControl is TextBox txtNumCourses)
            {
                if (!int.TryParse(txtNumCourses.Text.Trim(), out numberOfCoursesInput))
                {
                    MessageBox.Show("Please enter a valid number for Courses.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNumCourses.Focus(); return;
                }
                if (numberOfCoursesInput < 1 || numberOfCoursesInput > 10) // Validate range
                {
                    MessageBox.Show("Number of courses must be between 1 and 10.", "Input Error");
                    txtNumCourses.Focus(); return;
                }
            }
            else { MessageBox.Show("Num Courses control not found.", "Config Error"); return; }


            // Validate Input
            if (string.IsNullOrWhiteSpace(this.currentStudentID))
            {
                MessageBox.Show("Student information is missing. Cannot save Academic Period.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(schoolYearInput)) { MessageBox.Show("Please select/enter School Year.", "Input Error"); if (syControl != null) syControl.Focus(); return; }
            if (string.IsNullOrWhiteSpace(semesterInput)) { MessageBox.Show("Please select/enter Semester.", "Input Error"); if (semControl != null) semControl.Focus(); return; }
            // numberOfCoursesInput is validated above
            if (dashboardFormInstance == null) { MessageBox.Show("Dashboard reference missing. Cannot proceed.", "Error"); return; }


            // --- Save Academic Period to Database and Get ID ---
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Ensure your AcademicPeriods table has StudentID, SchoolYear, Semester, NumberOfCourses columns
                // Ensure StudentID column type matches currentStudentID (string vs int)
                string insertAcademicPeriodQuery = @"
                    INSERT INTO dbo.AcademicPeriods (studentID, SchoolYear, Semester, NumberOfCourses)
                    VALUES (@StudentID, @SchoolYear, @Semester, @NumberOfCourses);
                    SELECT SCOPE_IDENTITY();"; // Get the newly generated ID

                using (SqlCommand command = new SqlCommand(insertAcademicPeriodQuery, connection))
                {
                    // Assuming StudentID in DB is INT. If it's NVARCHAR, remove int.TryParse.
                    if (!int.TryParse(this.currentStudentID, out int studentIdInt))
                    {
                        MessageBox.Show("Invalid Student ID format for database. Expected integer.", "Error");
                        Debug.WriteLine($"Failed to parse StudentID '{this.currentStudentID}' as integer.");
                        return;
                    }
                    command.Parameters.AddWithValue("@StudentID", studentIdInt);

                    command.Parameters.AddWithValue("@SchoolYear", schoolYearInput);
                    command.Parameters.AddWithValue("@Semester", semesterInput);
                    command.Parameters.AddWithValue("@NumberOfCourses", numberOfCoursesInput);

                    try
                    {
                        connection.Open();
                        object result = command.ExecuteScalar();

                        if (result != null && int.TryParse(result.ToString(), out this.generatedAcademicPeriodId))
                        {
                            Debug.WriteLine($"Academic Period saved. ID: {this.generatedAcademicPeriodId}");
                            // Optional: Show success message for saving Academic Period
                            // MessageBox.Show($"Academic Period saved with ID: {this.generatedAcademicPeriodId}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Store collected data in fields
                            this.collectedSchoolYear = schoolYearInput;
                            this.collectedSemester = semesterInput;
                            this.collectedTotalCourses = numberOfCoursesInput;

                            // --- CORRECTED: Always start with the first course entry form (course_op) ---
                            StartCourseEntrySequence();
                        }
                        else
                        {
                            MessageBox.Show("Failed to retrieve Academic Period ID after saving.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Debug.WriteLine("ExecuteScalar returned null or could not parse ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Debug.WriteLine($"SQL Error saving Academic Period: {sqlEx.Message}\n{sqlEx.StackTrace}");
                        MessageBox.Show("Database Error saving Academic Period: " + sqlEx.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"General Error saving Academic Period: {ex.Message}\n{ex.StackTrace}");
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // --- CORRECTED: Method to start the course entry sequence (always starts with course_op) ---
        private void StartCourseEntrySequence()
        {
            // Ensure we have the necessary info to start
            if (string.IsNullOrWhiteSpace(this.collectedSchoolYear) || string.IsNullOrWhiteSpace(this.collectedSemester) || this.collectedTotalCourses < 1 || this.generatedAcademicPeriodId == 0 || this.dashboardFormInstance == null)
            {
                MessageBox.Show("Missing academic period details. Cannot start course entry.", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Always start with the form for the first course (course_op)
            Form firstCourseForm = null;
            int firstCourseNumber = 1; // Always start collecting data from Course 1
            List<CourseDetails> collectedCourses = new List<CourseDetails>(); // Start with a new empty list

            try
            {
                // Instantiate the first course entry form (course_op)
                // Pass all necessary data, including the generated AcademicPeriodId
                firstCourseForm = new course_op(
                    this.collectedSchoolYear,
                    this.collectedSemester,
                    this.collectedTotalCourses, // Total courses for the entire period
                    firstCourseNumber,         // The current course number (1)
                    this,                      // Pass THIS form (firstpartcourse) as the previous form
                    this.dashboardFormInstance,
                    collectedCourses,          // Pass the NEWLY CREATED EMPTY LIST
                    this.generatedAcademicPeriodId // Pass the generated Academic Period ID
                );

                if (firstCourseForm != null)
                {
                    firstCourseForm.Show(); // Show the form for the first course
                    this.Hide();           // Hide the current form (firstpartcourse)
                }
                else
                {
                    MessageBox.Show("Failed to create the first course entry form.", "Error");
                }
            }
            catch (MissingMethodException mmEx)
            {
                // This catch block helps diagnose if course_op's constructor is missing or incorrect.
                MessageBox.Show($"Configuration Error: The 'course_op' form does not have the required constructor.\nPlease ensure course_op.cs has the public constructor: public course_op(string, string, int, int, Form, Form, List<CourseDetails>, int).\nDetails: {mmEx.Message}", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine($"MissingMethodException: {mmEx.Message}\n{mmEx.StackTrace}");
                this.Show(); // Stay on current form if navigation failed
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error starting course entry sequence: " + ex.Message, "Error");
                Debug.WriteLine($"General Error starting sequence: {ex.Message}\n{ex.StackTrace}");
                this.Show(); // Stay on current form if navigation failed
            }
        }


        // clear button (button2) click handler
        private void button2_Click(object sender, EventArgs e)
        {
            // Clear input fields
            if (FindControlRecursive(this, "comboBox1") is ComboBox cbSchoolYear) cbSchoolYear.SelectedIndex = -1;
            if (FindControlRecursive(this, "textBoxSchoolYear") is TextBox txtSchoolYear) txtSchoolYear.Clear();
            if (FindControlRecursive(this, "comboBox2") is ComboBox cbSemester) cbSemester.SelectedIndex = -1;
            if (FindControlRecursive(this, "textBoxSemester") is TextBox txtSemester) txtSemester.Clear();
            Control numCoursesControl = FindControlRecursive(this, "numericUpDownNumCourses") ?? FindControlRecursive(this, "textBox1");
            if (numCoursesControl is NumericUpDown numCourses) numCourses.Value = numCourses.Minimum > 0 ? numCourses.Minimum : 1;
            if (numCoursesControl is TextBox txtNumCourses) txtNumCourses.Text = "1";
            // Set focus back to the first input control
            Control initialFocusControl = FindControlRecursive(this, "comboBox1") ?? FindControlRecursive(this, "textBoxSchoolYear");
            if (initialFocusControl != null)
            {
                initialFocusControl.Focus();
            }
        }

        // back button (button3) click handler
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (dashboardFormInstance != null)
            {
                dashboardFormInstance.Show(); // Navigate back to the Dashboard
            }
            else
            {
                // Fallback if dashboard reference is lost
                MessageBox.Show("Returning to Login.", "Navigation");
                frmLogin loginForm = new frmLogin(); // Assuming frmLogin is your login form
                loginForm.Show();
                this.Close(); // Close the current form
            }
        }

        // If you have other event handlers defined in your designer, make sure they are here.
        // Example: private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { ... }
        // Example: private void textBox1_TextChanged(object sender, EventArgs e) { ... }
        // Remove any duplicate or unused event handlers.
    }
}