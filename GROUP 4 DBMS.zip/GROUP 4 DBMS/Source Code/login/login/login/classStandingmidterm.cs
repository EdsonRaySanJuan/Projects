﻿// classStandingmidterm.cs
// This form is specifically for Midterm calculations,
// inheriting logic from the general classStanding structure.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics; // Added for Debug.WriteLine

// Ensure CourseDetails class is accessible (defined elsewhere, e.g., CourseDetails.cs or in this namespace)
// Example:
/*
public class CourseDetails
{
    public int AcademicPeriodId { get; set; } // Or string, depending on your data
    public string Code { get; set; }
    public string Name { get; set; }
    public double Units { get; set; } // Or decimal
    public string SchoolYear { get; set; }
    public string Semester { get; set; }
    // Potentially add StudentID if it's part of the course context for this user
    // public int StudentID { get; set; } 
}
*/

namespace login
{
    public partial class classStandingmidterm : Form
    {
        // Fields to store received data and form references
        private CourseDetails _selectedCourse;
        private string _gradingTerm;      // Should be "Midterm" for this specific form
        private Form _selectCourseForm;   // Reference to the selectcourse form that opened this one
        private Form _dashboardForm;      // Reference to the Dashboard form

        const int MAX_INPUT_ROWS_PER_CATEGORY = 10;

        // Parameterized constructor
        public classStandingmidterm(CourseDetails course, string gradingTerm, Form selectCourseForm, Form dashboard)
        {
            InitializeComponent();
            _selectedCourse = course;
            _gradingTerm = gradingTerm; // Expecting "Midterm" to be passed here
            _selectCourseForm = selectCourseForm;
            _dashboardForm = dashboard;
            DisplayDetails(_selectedCourse, _gradingTerm);
        }

        // Parameterless constructor (Needed by the form designer)
        public classStandingmidterm()
        {
            InitializeComponent();
            _selectedCourse = null;
            _gradingTerm = "Midterm"; // Default for this specific form
            _selectCourseForm = null;
            _dashboardForm = null;
            this.Load += (s, e) => HandleParameterlessConstructorContext();
            DisplayDetails(null, _gradingTerm); // Show default term in designer or if no data
        }

        private void HandleParameterlessConstructorContext()
        {
            if (_selectedCourse == null) // Simplified check for this context
            {
                MessageBox.Show("Warning: Midterm Class Standing form initialized without required course data. Please go back and select a course.", "Initialization Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Debug.WriteLine("Warning: classStandingmidterm initialized without expected course data.");
                Control submitButton = this.Controls.Find("button1", true).FirstOrDefault();
                if (submitButton != null) submitButton.Enabled = false;
            }
        }

        private void DisplayDetails(CourseDetails course, string gradingTerm)
        {
            Control lblTermControl = this.Controls.Find("label1", true).FirstOrDefault();
            if (lblTermControl is Label lblTerm) { lblTerm.Text = $"Term: {gradingTerm}"; }
            else if (lblTermControl is TextBox txtTerm) { txtTerm.Text = $"Term: {gradingTerm}"; }
            else { Debug.WriteLine("Warning: Control 'label1' for Term display not found."); }

            Control lblAcademicPeriodControl = this.Controls.Find("lblAcademicPeriod", true).FirstOrDefault();
            if (lblAcademicPeriodControl is Label lblAP)
            {
                if (course != null) lblAP.Text = $"Academic Period: {course.Semester} ({course.SchoolYear})";
                else lblAP.Text = "Academic Period: N/A";
            }
            else { Debug.WriteLine("Warning: Control 'lblAcademicPeriod' for Academic Period display not found."); }

            if (course != null)
            {
                Control lblCourseControl = this.Controls.Find("label4", true).FirstOrDefault();
                if (lblCourseControl is Label lblCourse) { lblCourse.Text = $"{course.Name} ({course.Code})"; }
                else if (lblCourseControl is TextBox txtCourse) { txtCourse.Text = $"{course.Name} ({course.Code})"; }
                else { Debug.WriteLine("Warning: Control 'label4' for Course display not found."); }
                Debug.WriteLine($"Displayed details for Course: {course.Code}, Term: {gradingTerm}");
            }
            else
            {
                Control lblCourseControl = this.Controls.Find("label4", true).FirstOrDefault();
                if (lblCourseControl is Label lblCourse) { lblCourse.Text = "Course: N/A"; }
                // No error message if course is null, HandleParameterlessConstructorContext shows a warning
                Debug.WriteLine($"DisplayDetails called with null course for term: {gradingTerm}.");
            }
        }

        private double GetDoubleFromTextBox(TextBox textBox, string fieldName)
        {
            if (textBox == null)
            {
                Debug.WriteLine($"Warning: Textbox for {fieldName} is null in GetDoubleFromTextBox.");
                return 0;
            }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }
            if (double.TryParse(textBox.Text.Trim(), out double value)) { return value; }
            else
            {
                MessageBox.Show($"Invalid input for {fieldName}. Please enter a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus();
                return double.NaN;
            }
        }

        private int GetIntFromTextBox(TextBox textBox, string fieldName) // Kept for utility, though not used in core calc
        {
            if (textBox == null)
            {
                Debug.WriteLine($"Warning: Textbox for {fieldName} is null.");
                return 0;
            }
            if (string.IsNullOrWhiteSpace(textBox.Text)) { return 0; }
            if (int.TryParse(textBox.Text.Trim(), out int value)) { return value; }
            else
            {
                MessageBox.Show($"Invalid input for {fieldName}. Please enter an integer.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox.Focus();
                return -1;
            }
        }

        private double ProcessCategory(string categoryName)
        {
            List<double> itemScoresAsPercentages = new List<double>();
            for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
            {
                Control scoreControl = this.Controls.Find($"txt{categoryName}Score{i}", true).FirstOrDefault();
                if (scoreControl == null)
                {
                    if (i == 1) { Debug.WriteLine($"Info: No input control found for {categoryName} item {i} (expected txt{categoryName}Score{i}). Assuming no items for this category."); }
                    else { Debug.WriteLine($"Info: No more controls for {categoryName} starting from item {i}."); }
                    break;
                }
                TextBox scoreTextBox = scoreControl as TextBox;
                if (scoreTextBox == null) { Debug.WriteLine($"Warning: Control txt{categoryName}Score{i} is not a TextBox."); continue; }

                double scoreAsPercentage = GetDoubleFromTextBox(scoreTextBox, $"{categoryName} Score {i}");
                if (double.IsNaN(scoreAsPercentage)) { return double.NaN; }
                if (scoreAsPercentage < 0 || scoreAsPercentage > 100)
                {
                    MessageBox.Show($"Score ({scoreAsPercentage}%) for {categoryName} item {i} must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scoreTextBox.Focus(); return double.NaN;
                }
                // Only add if text was not originally empty/whitespace, to distinguish from an explicit 0.
                // GetDoubleFromTextBox returns 0 for whitespace, so we check original text.
                if (!string.IsNullOrWhiteSpace(scoreTextBox.Text))
                {
                    itemScoresAsPercentages.Add(scoreAsPercentage);
                    Debug.WriteLine($"Read {scoreAsPercentage:F2}% for {categoryName} item {i}. Total items: {itemScoresAsPercentages.Count}");
                }
                else { Debug.WriteLine($"Skipping empty score input for {categoryName} item {i}."); }
            }

            double overallAverage = 0;
            if (itemScoresAsPercentages.Count > 0)
            {
                overallAverage = itemScoresAsPercentages.Sum() / itemScoresAsPercentages.Count;
            }

            // Assumes txt[CategoryName]FinalPercentage exists on the form
            Control finalPercentageControl = this.Controls.Find($"txt{categoryName}FinalPercentage", true).FirstOrDefault();
            if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Text = overallAverage.ToString("F2") + "%"; }
            else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = overallAverage.ToString("F2") + "%"; }
            else { Debug.WriteLine($"Warning: UI Control 'txt{categoryName}FinalPercentage' for displaying category average not found."); }

            // Assumes txt[CategoryName]Weight exists on the form
            Control weightControl = this.Controls.Find($"txt{categoryName}Weight", true).FirstOrDefault();
            double weightPercentage = 0;
            if (weightControl is TextBox weightTextBox)
            {
                weightPercentage = GetDoubleFromTextBox(weightTextBox, $"{categoryName} Weight");
                if (double.IsNaN(weightPercentage)) { return double.NaN; }
                if (weightPercentage < 0 || weightPercentage > 100)
                { MessageBox.Show($"Weight for {categoryName} must be between 0 and 100.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error); weightTextBox.Focus(); return double.NaN; }
            }
            else { Debug.WriteLine($"Warning: UI Control 'txt{categoryName}Weight' not found. Assuming weight 0."); }

            double weightedContribution = overallAverage * (weightPercentage / 100.0);

            // Assumes txt[CategoryName]WeightedContribution exists on the form
            Control weightedContributionControl = this.Controls.Find($"txt{categoryName}WeightedContribution", true).FirstOrDefault();
            if (weightedContributionControl is TextBox txtWeightedContribution) { txtWeightedContribution.Text = weightedContribution.ToString("F2"); }
            else if (weightedContributionControl is Label lblWeightedContribution) { lblWeightedContribution.Text = weightedContribution.ToString("F2"); }
            else { Debug.WriteLine($"Warning: UI Control 'txt{categoryName}WeightedContribution' for display not found."); }

            Debug.WriteLine($"Category: {categoryName}, Average: {overallAverage:F2}%, Weight: {weightPercentage:F2}%, Contribution: {weightedContribution:F2}%");
            return double.IsNaN(weightPercentage) ? double.NaN : weightedContribution; // Ensure NaN propagates if weight was an issue
        }

        private double CalculateOverallClassStanding()
        {
            double totalClassStanding = 0;
            double totalWeightSum = 0;
            bool calculationFailed = false;
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };

            foreach (string category in categories)
            {
                double categoryContribution = ProcessCategory(category);
                if (double.IsNaN(categoryContribution)) { calculationFailed = true; break; } // Stop if any category fails
                totalClassStanding += categoryContribution;

                // Accumulate weight for sum validation
                Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                if (weightControl is TextBox weightTextBox)
                {
                    // We re-get the double for sum to ensure any parsing issues are caught here for the sum itself
                    // even if ProcessCategory might have used a parsed value.
                    double weightForSum = GetDoubleFromTextBox(weightTextBox, $"{category} Weight (for total sum check)");
                    if (double.IsNaN(weightForSum) || weightForSum < 0 || weightForSum > 100)
                    {
                        // This implies ProcessCategory should also have failed or an issue exists if it didn't.
                        Debug.WriteLine($"Error in weight for {category} during final sum check.");
                        calculationFailed = true; break;
                    }
                    totalWeightSum += weightForSum;
                }
                else
                {
                    Debug.WriteLine($"Warning: Weight TextBox for {category} not found during sum check. Assuming 0 weight contribution to sum from this category.");
                }
            }

            if (calculationFailed) { return double.NaN; }

            if (categories.Length > 0 && Math.Abs(totalWeightSum - 100.0) > 0.01)
            {
                MessageBox.Show($"The total weight of all categories must add up to 100%. Current total weight: {totalWeightSum:F2}%", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return double.NaN;
            }
            else if (categories.Length > 0 && totalWeightSum < 0.01 && totalClassStanding > 0.01) // Weights are zero but standing is not
            { Debug.WriteLine("Warning: Total weight is zero or negligible, but class standing has a value. This might be an error in weights."); }

            return totalClassStanding;
        }

        private void button1_Click(object sender, EventArgs e) // Submit Button
        {
            Debug.WriteLine("Calculate Midterm CS button clicked.");
            if (_selectedCourse == null || string.IsNullOrEmpty(_gradingTerm))
            {
                MessageBox.Show("Cannot calculate Midterm class standing. Course details or grading term are missing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (_gradingTerm != "Midterm")
            {
                Debug.WriteLine($"Warning: Grading term is '{_gradingTerm}', but this form is for Midterm. Calculation will proceed for '{_gradingTerm}'.");
                // Optionally, enforce term or just proceed:
                // MessageBox.Show($"This form is for Midterm calculations. Current term is '{_gradingTerm}'.", "Term Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // return;
            }

            double calculatedClassStanding = CalculateOverallClassStanding();

            // ASSUMPTION: txtClassStandingResult exists for display
            Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();

            if (!double.IsNaN(calculatedClassStanding))
            {
                if (classStandingResultControl is TextBox txtClassStandingResult) { txtClassStandingResult.Text = calculatedClassStanding.ToString("F2") + "%"; }
                else if (classStandingResultControl is Label lblClassStandingResult) { lblClassStandingResult.Text = $"Midterm Class Standing: {calculatedClassStanding:F2}%"; }
                else { MessageBox.Show($"Midterm Class Standing: {calculatedClassStanding:F2}%", "Midterm Result", MessageBoxButtons.OK, MessageBoxIcon.Information); }

                Debug.WriteLine($"Midterm Class Standing: {calculatedClassStanding:F2}% for course {_selectedCourse.Code} ({_selectedCourse.Name}) Term: {_gradingTerm}");

                // TODO: Implement saving the calculated class standing to the database (e.g., dbo.midterm).
                // This would involve:
                // 1. Getting StudentID, CourseID, AcademicPeriodID.
                // 2. Saving overallStanding to a 'midterm_classstand' column.
                // 3. Saving each category's weighted contribution (e.g., from txtQuizWeightedContribution.Text) to corresponding DB columns
                //    (e.g., midterm_quiz, midterm_assignment, etc.).

                DialogResult proceedToExam = MessageBox.Show("Midterm Class Standing calculation complete. Do you want to proceed to Midterm Exam calculation?", "Next Step", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (proceedToExam == DialogResult.Yes) { MessageBox.Show("Midterm Exam calculation functionality is not yet available.", "Information"); }
            }
            // If NaN, errors were already shown.
        }

        // Back button - assuming button3 is the name in your designer for this form
        private void button3_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Back button clicked from classStandingmidterm.");
            this.Hide();
            if (_selectCourseForm != null && !_selectCourseForm.IsDisposed) { _selectCourseForm.Show(); }
            else if (_dashboardForm != null && !_dashboardForm.IsDisposed) { _dashboardForm.Show(); }
            else
            {
                MessageBox.Show("Cannot navigate back. Previous form references are missing or disposed.", "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Consider closing or disabling if no valid back navigation
            }
        }

        // Renamed Load event handler
        private void classStandingmidterm_Load(object sender, EventArgs e)
        {
            Debug.WriteLine("classStandingmidterm form loaded.");
            if (_selectedCourse == null)
            {
                // This might be too late if HandleParameterlessConstructorContext already showed a message
                // but can be a fallback or if form is shown directly without proper data.
                Debug.WriteLine("Form loaded without selected course - data might be missing for calculation.");
            }
        }

        // Empty label click handlers (can be removed if not used)
        private void label1_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }

        // Placeholder for TableLayoutPanel paint event, if you have one.
        // If not, this can be removed. Ensure it's not wired up in the Designer.cs if removed.
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e) { }


        // --- TextChanged Event Handlers from your classStanding.cs reference ---
        // These are named textBoxX_TextChanged_1.
        // You need to wire these up to your actual item score TextBoxes
        // (txtQuizScore1, txtQuizScore2, ..., txtRecitationScore10) in the designer
        // according to the mapping you intend (e.g., txtQuizScore1.TextChanged -> textBox1_TextChanged_1).

        // quiz1 item textbox
        private void textBox1_TextChanged_1(object sender, EventArgs e) { }
        // quiz2 item textbox
        private void textBox2_TextChanged_1(object sender, EventArgs e) { }
        // ... (all 50 textBoxX_TextChanged_1 handlers as per your classStanding.cs) ...
        private void textBox3_TextChanged_1(object sender, EventArgs e) { }
        private void textBox4_TextChanged_1(object sender, EventArgs e) { }
        private void textBox5_TextChanged_1(object sender, EventArgs e) { }
        private void textBox6_TextChanged_1(object sender, EventArgs e) { }
        private void textBox7_TextChanged_1(object sender, EventArgs e) { }
        private void textBox8_TextChanged_1(object sender, EventArgs e) { }
        private void textBox9_TextChanged_1(object sender, EventArgs e) { }
        private void textBox10_TextChanged_1(object sender, EventArgs e) { }
        private void textBox11_TextChanged_1(object sender, EventArgs e) { }
        private void textBox12_TextChanged_1(object sender, EventArgs e) { }
        private void textBox13_TextChanged_1(object sender, EventArgs e) { }
        private void textBox14_TextChanged_1(object sender, EventArgs e) { }
        private void textBox15_TextChanged_1(object sender, EventArgs e) { }
        private void textBox16_TextChanged_1(object sender, EventArgs e) { }
        private void textBox17_TextChanged_1(object sender, EventArgs e) { }
        private void textBox18_TextChanged_1(object sender, EventArgs e) { }
        private void textBox19_TextChanged_1(object sender, EventArgs e) { }
        private void textBox20_TextChanged_1(object sender, EventArgs e) { }
        private void textBox21_TextChanged_1(object sender, EventArgs e) { }
        private void textBox22_TextChanged_1(object sender, EventArgs e) { }
        private void textBox23_TextChanged_1(object sender, EventArgs e) { }
        private void textBox24_TextChanged_1(object sender, EventArgs e) { }
        private void textBox25_TextChanged_1(object sender, EventArgs e) { }
        private void textBox26_TextChanged_1(object sender, EventArgs e) { }
        private void textBox27_TextChanged_1(object sender, EventArgs e) { }
        private void textBox28_TextChanged_1(object sender, EventArgs e) { }
        private void textBox29_TextChanged_1(object sender, EventArgs e) { }
        private void textBox30_TextChanged_1(object sender, EventArgs e) { }
        private void textBox31_TextChanged_1(object sender, EventArgs e) { }
        private void textBox32_TextChanged_1(object sender, EventArgs e) { }
        private void textBox33_TextChanged_1(object sender, EventArgs e) { }
        private void textBox34_TextChanged_1(object sender, EventArgs e) { }
        private void textBox35_TextChanged_1(object sender, EventArgs e) { }
        private void textBox36_TextChanged_1(object sender, EventArgs e) { }
        private void textBox37_TextChanged_1(object sender, EventArgs e) { }
        private void textBox38_TextChanged_1(object sender, EventArgs e) { }
        private void textBox39_TextChanged_1(object sender, EventArgs e) { }
        private void textBox40_TextChanged_1(object sender, EventArgs e) { }
        private void textBox41_TextChanged_1(object sender, EventArgs e) { }
        private void textBox42_TextChanged_1(object sender, EventArgs e) { }
        private void textBox43_TextChanged_1(object sender, EventArgs e) { }
        private void textBox44_TextChanged_1(object sender, EventArgs e) { }
        private void textBox45_TextChanged_1(object sender, EventArgs e) { }
        private void textBox46_TextChanged_1(object sender, EventArgs e) { }
        private void textBox47_TextChanged_1(object sender, EventArgs e) { }
        private void textBox48_TextChanged_1(object sender, EventArgs e) { }
        private void textBox49_TextChanged_1(object sender, EventArgs e) { }
        private void textBox50_TextChanged_1(object sender, EventArgs e) { }

        // This was the only weight TextChanged handler present in the reference classStanding.cs
        // If you need them for other weights, you'll need to add them similarly.
        private void txtSeatworkWeight_TextChanged(object sender, EventArgs e) { }

        // --- End of TextChanged Event Handlers ---

        private void button2_Click(object sender, EventArgs e) // Clear Inputs button
        {
            Debug.WriteLine("Clear Inputs button clicked for Midterm.");
            string[] categories = { "Quiz", "Assignment", "Seatwork", "Laboratory", "Recitation" };
            foreach (string category in categories)
            {
                for (int i = 1; i <= MAX_INPUT_ROWS_PER_CATEGORY; i++)
                {
                    Control scoreControl = this.Controls.Find($"txt{category}Score{i}", true).FirstOrDefault();
                    if (scoreControl is TextBox scoreTextBox) { scoreTextBox.Clear(); }
                }
                Control weightControl = this.Controls.Find($"txt{category}Weight", true).FirstOrDefault();
                if (weightControl is TextBox weightTextBox) { weightTextBox.Clear(); }

                Control finalPercentageControl = this.Controls.Find($"txt{category}FinalPercentage", true).FirstOrDefault();
                if (finalPercentageControl is TextBox txtFinalPercentage) { txtFinalPercentage.Clear(); }
                else if (finalPercentageControl is Label lblFinalPercentage) { lblFinalPercentage.Text = string.Empty; }

                Control weightedContributionControl = this.Controls.Find($"txt{category}WeightedContribution", true).FirstOrDefault();
                if (weightedContributionControl is TextBox txtWeightedContribution) { txtWeightedContribution.Clear(); }
                else if (weightedContributionControl is Label lblWeightedContribution) { lblWeightedContribution.Text = string.Empty; }
            }
            Control classStandingResultControl = this.Controls.Find("txtClassStandingResult", true).FirstOrDefault();
            if (classStandingResultControl is TextBox txtClassStandingResult) { txtClassStandingResult.Clear(); }
            else if (classStandingResultControl is Label lblClassStandingResult) { lblClassStandingResult.Text = "Midterm Class Standing:"; }

            Control firstInput = this.Controls.Find("txtQuizScore1", true).FirstOrDefault();
            firstInput?.Focus();
        }
    }
}