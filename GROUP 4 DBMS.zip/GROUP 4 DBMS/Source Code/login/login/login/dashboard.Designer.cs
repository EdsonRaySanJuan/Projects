﻿namespace login
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            buttonStudent = new Button();
            buttonCourse = new Button();
            buttonGoal = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("MS UI Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(74, 63);
            label1.Name = "label1";
            label1.Size = new Size(168, 33);
            label1.TabIndex = 0;
            label1.Text = "Main Menu";
            // 
            // buttonStudent
            // 
            buttonStudent.BackColor = Color.Black;
            buttonStudent.Cursor = Cursors.Hand;
            buttonStudent.FlatAppearance.BorderSize = 0;
            buttonStudent.FlatStyle = FlatStyle.Flat;
            buttonStudent.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonStudent.ForeColor = Color.White;
            buttonStudent.Location = new Point(90, 115);
            buttonStudent.Name = "buttonStudent";
            buttonStudent.Size = new Size(129, 40);
            buttonStudent.TabIndex = 1;
            buttonStudent.Text = "Student";
            buttonStudent.UseVisualStyleBackColor = false;
            buttonStudent.Click += button1_Click;
            // 
            // buttonCourse
            // 
            buttonCourse.BackColor = Color.Black;
            buttonCourse.Cursor = Cursors.Hand;
            buttonCourse.FlatAppearance.BorderSize = 0;
            buttonCourse.FlatStyle = FlatStyle.Flat;
            buttonCourse.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonCourse.ForeColor = Color.White;
            buttonCourse.Location = new Point(90, 161);
            buttonCourse.Name = "buttonCourse";
            buttonCourse.Size = new Size(129, 40);
            buttonCourse.TabIndex = 2;
            buttonCourse.Text = "Course";
            buttonCourse.UseVisualStyleBackColor = false;
            buttonCourse.Click += buttonCourse_Click;
            // 
            // buttonGoal
            // 
            buttonGoal.BackColor = Color.Black;
            buttonGoal.Cursor = Cursors.Hand;
            buttonGoal.FlatAppearance.BorderSize = 0;
            buttonGoal.FlatStyle = FlatStyle.Flat;
            buttonGoal.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonGoal.ForeColor = Color.White;
            buttonGoal.Location = new Point(90, 207);
            buttonGoal.Name = "buttonGoal";
            buttonGoal.Size = new Size(129, 40);
            buttonGoal.TabIndex = 3;
            buttonGoal.Text = "Goal";
            buttonGoal.UseVisualStyleBackColor = false;
            buttonGoal.Click += buttonGoal_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(90, 253);
            button1.Name = "button1";
            button1.Size = new Size(129, 40);
            button1.TabIndex = 4;
            button1.Text = "Summary";
            button1.UseVisualStyleBackColor = false;
            // 
            // dashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.th__1_;
            ClientSize = new Size(319, 352);
            Controls.Add(button1);
            Controls.Add(buttonGoal);
            Controls.Add(buttonCourse);
            Controls.Add(buttonStudent);
            Controls.Add(label1);
            Name = "dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "dashboard";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button buttonStudent;
        private Button buttonCourse;
        private Button buttonGoal;
        private Button button1;
    }
}