#include <iostream>
#include <iomanip>
#include <string>

using namespace std;
void headerfor3 ()
{
	cout << "*---------------------------------------------------------------*"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*                   Calculate Class standin                     *"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*---------------------------------------------------------------*"<<endl<<endl;
}
double calculatePercentage(int score, int total) // Formula to getting the percent per category
{			
    return static_cast<double>(score) / total * 100;
}

double calculateOverallTotal(double* percentages, int numItems) {
    double total;
    for (int i = 0; i < numItems; i++) {					// Formula to calculate the overall total per category
        total += percentages[i];
    }
    return total / numItems;
}

double getPercentEquivalent(const string& category) {
    double percentEquivalent;
    double decimalEqui;										// Formula to convert whole number to decimal
    cout << "Enter percent equivalent for " << category << ": ";
    cin >> percentEquivalent;
    cout << "_______________________________________________________________" << endl;
    decimalEqui = percentEquivalent / 100;
    return decimalEqui;
}

void processCategory(const string category, double& classStanding) {
    char hasCategory;
    cout << "Do you have " << category << "? (Y/N): ";					// Asking the user if they have this, per category
    cin >> hasCategory;
    cout << endl;
													

    if (hasCategory == 'Y' || hasCategory == 'y') {
        int numItems;
        cout << "How many " << category << " do you have?: ";
        cin >> numItems;
        cout << "_______________________________________________________________" << endl;
        

        double* percentages = new double[numItems];						

        for (int i = 0; i < numItems; i++) {				// This put number in the right side of the category
            int score, total;
            do {
			cout << "Enter score for " << category << " " << i + 1 << ": ";
            cin >> score;
        	} 
        	while (score < 0 || score > 100);
            
            do {
			cout << "Enter total for " << category << " " << i + 1 << ": ";
            cin >> total;
        	}
        	while (total < 0 || total > 100);
    
            double percentage = calculatePercentage(score, total);
            cout << "Percentage for " << category << " " << i + 1 << ": " << fixed << setprecision(2) << percentage << "%" << endl<<endl;

            percentages[i] = percentage;
           
        }

        double overallTotal = calculateOverallTotal(percentages, numItems);		// Outputing the percents and overall
        double percentEquivalent = getPercentEquivalent(category);
        double finalResult = overallTotal * percentEquivalent;

        cout << "Overall total percentage for " << category << ": " << fixed << setprecision(2) << overallTotal << "%" << endl;
        cout << "Final for this category: " << finalResult << "%" << endl;
        cout << "_______________________________________________________________" << endl;

        classStanding += finalResult; // Add the final result to classStanding

        delete[] percentages;
    } else if (hasCategory == 'N' || hasCategory == 'n') {
        cout << "No " << category << "." << endl;
        cout << "_______________________________________________________________" << endl;
    } else {
        cout << "Invalid input for " << category << "." << endl;
    }
}

int main() {
    double classStanding;
	headerfor3 ();
    processCategory("quiz", classStanding);				// Calling the parts of cs
    processCategory("assignment", classStanding);
    processCategory("seatwork", classStanding);
    processCategory("activity", classStanding);
    processCategory("laboratory", classStanding);
    processCategory("homework", classStanding);
    processCategory("recitation", classStanding);

    cout << "Class standing: " << fixed << setprecision(2) << classStanding << "%" << endl;
    cout << "_______________________________________________________________" << endl;

    return 0;
}
