#include <iostream>
using namespace std;

int main ()
{
	double FCS, FE, FG, MG;
	
	cout <<"Enter your FCS: ";
	cin >>FCS;
	
	cout <<"Enter your FE: " ;
	cin >>FE;
	
	cout <<"Enter your MG: ";
	cin >>MG;
	
	double partialFG = (FCS * 0.5) + (FE * 0.5);
	
	MG = (partialFG * 2/3) + (MG * 1/3);
	cout<<"Your FG is: "<<FG;


}
