#include <iostream>
using namespace std;

int main ()
{
	double PCS, PE, PG;
	
	cout <<"Enter your PCS: ";
	cin >>PCS;
	
	cout <<"Enter your PE: " ;
	cin >>PE;
	
	
	PG = (PCS * 0.5) + (PE * 0.5);
	cout<<"Your PG is: "<<PG;


}
