#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
using namespace std;

void design ()
{
	cout << "*---------------------------------------------------------------*"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*                       Grade Calculator                        *"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*---------------------------------------------------------------*"<<endl<<endl;
}
int optionfor2 ()
{
	int choicefor2;
	cout <<"  [1] Preliminary   [2] Mid-Term   [3] Final"<<endl;
	cout <<"_____________________________________________________"<<endl<<endl;
	cout <<"What do you want to calculate?: ";
	cin >>choicefor2;
	cout <<"_____________________________________________________"<<endl<<endl;	
	return choicefor2;
}
double PG ()
{
	
	double PCS, PE, PG;
	double prelimGrade;
	cout <<"Enter your Class Standing: ";
	cin >>PCS;
	
	cout <<"Enter your Preliminary Exam: " ;
	cin >>PE;
		
	prelimGrade = (PCS * 0.5) + (PE * 0.5);

	return prelimGrade;
}
double MG ()
{
	double MCS, ME, MG, PG;
	
	cout <<"Enter your Class Standing: ";
	cin >>MCS;
	
	cout <<"Enter your Mid-Term Exam: " ;
	cin >>ME;
	
	cout <<"Enter your Preliminary Grade: ";
	cin >>PG;
	
	double partialMG = (MCS * 0.5) + (ME * 0.5);
	
	MG = (partialMG * 2/3) + (PG * 1/3);
	double midtermGrade = MG;
	return midtermGrade;
}
double FG ()
{
	double FCS, FE, FG, MG;
	
	cout <<"Enter your Class Standing: ";
	cin >>FCS;
	
	cout <<"Enter your Final Exam: " ;
	cin >>FE;
	
	cout <<"Enter your Mid-Term Grade: ";
	cin >>MG;
	
	double partialFG = (FCS * 0.5) + (FE * 0.5);
	
	FG = (partialFG * 2/3) + (MG * 1/3);
	double finalGrade = FG;

	return finalGrade;
}
double gradingScheme(double grade)
{
	
	;
	if (grade >= 94 && grade <= 100)
	{
		grade = 1.00;
	}
	else if (grade >= 88.5 && grade <= 93.99)
	{
		grade = 1.25;
	}
	else if (grade >= 83 && grade <= 88.49)
	{
		grade = 1.50;
	}
	else if (grade >= 77.5 && grade <= 82.99)
	{
		grade = 1.75;
	}
	else if (grade >= 72 && grade <= 77.49)
	{
		grade = 2.00;
	}
	else if (grade >= 65.5 && grade <= 71.99)
	{
		grade = 2.25;
	}
	else if (grade >= 61 && grade <= 65.49)
	{
		grade = 2.50;
	}
	else if (grade >= 55.5 && grade <= 60.99)
	{
		grade = 2.75;
	}
	else if (grade >= 50 && grade <= 55.49)
	{
		grade = 3.00;
	}
	else 
	{
		grade = 5.00;
	}
	
	double gradeEquiv = grade;
	return gradeEquiv;
}
int calculatefor2 (int choicefor2)
{
	if (choicefor2 == 1)
	{
		double grade = PG ();
		double gradeEquiv = gradingScheme(grade);
		cout <<"_____________________________________________________"<<endl;
		cout <<"Your Preliminary Grade is: "<<grade<<endl;
		cout <<"Your Preliminary Grade is (Rounded Off): "<< round(grade*100)/100 <<endl;
		cout <<"Your Equivalent Grade is: "<< fixed << setprecision(2) << gradeEquiv <<endl;
	}
	else if (choicefor2 == 2)
	{
		double grade= MG ();
		double gradeEquiv = gradingScheme(grade);
		cout <<"_____________________________________________________"<<endl;
		cout <<"Your Mid-Term Grade is: "<<grade <<endl;
		cout <<"Your Mid-Term Grade is (Rounded Off): "<<round(grade*100)/100<<endl;
		cout <<"Your Equivalent Grade is: "<< fixed << setprecision(2) << gradeEquiv <<endl;	
	}
	else if (choicefor2 == 3)
	{
		double grade= FG ();
		double gradeEquiv = gradingScheme(grade);
		cout <<"_____________________________________________________"<<endl;
		cout <<"Your Final Grade is: "<<grade<<endl;
		cout <<"Your Final Grade is (Rounded Off): "<<round(grade*100)/100<<endl;
		cout <<"Your Equivalent Grade is: "<< fixed << setprecision(2) << gradeEquiv <<endl;
	}
	else
	cout <<"Invalid Input";
}
int main ()
{
	string ans, Y, N;
	do
	{
		design ();
		int choicefor2 = optionfor2 ();
		calculatefor2 (choicefor2);
		cout <<"_____________________________________________________"<<endl;
		do
		{
			cout << "Do you want to calculate again (Y/N): ";
			cin >>ans;           
		} while (ans != "Y" && ans != "N");
		system ("CLS");
	} while (ans == "Y");


	return 0;
}
	
	
	
	

