#include <iostream>
using namespace std;

int main ()
{
	double MCS, ME, MG, PG;
	
	cout <<"Enter your MCS: ";
	cin >>MCS;
	
	cout <<"Enter your ME: " ;
	cin >>ME;
	
	cout <<"Enter your PG: ";
	cin >>PG;
	
	double partialMG = (MCS * 0.5) + (ME * 0.5);
	
	MG = (partialMG * 2/3) + (PG * 1/3);
	cout<<"Your MG is: "<<MG;


}
