#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int numOfQuestions ();
int main ()
{

	double desiredGrade, prelimClassStanding, midtermClassStanding, prelimGrade, finalClassStanding, midtermGrade, NOQ, score, average;
    int choice;
    
    do
    {
	    cout << "Enter your desired grade: ";
		cin >> desiredGrade;
	}while (desiredGrade < 0 || desiredGrade > 100);
	
	cout << "-------------------------------------------" << endl; 
	cout << "Enter what grade period would you like to calculate" << endl;
    string grades [4] = {" ", """Prelims", "Midterms","Finals"};
    cout << "[1]Prelims [2]Midterms [3]Finals" << endl;
    cout << "-------------------------------------------" << endl; 
    cout << endl;
    
    do
    {
    	cout << "Enter what grade you want to evaluate: ";
    	cin >> choice;
	}while (choice < 1||choice > 3);
	cout << "you picked " << grades [choice];
	system ("CLS");
	cout << endl;
	
	if (choice == 1)
	{
		do
		{
			cout << "Enter the percentage of your class standing: ";
			cin >> prelimClassStanding;
		}while (prelimClassStanding <= 0 || prelimClassStanding > 100);
		NOQ = numOfQuestions ();
		NOQ = NOQ / 100;
		prelimClassStanding = prelimClassStanding * 0.5;
		average = desiredGrade - prelimClassStanding;
		score = average / 0.5;
		score = score * NOQ;
		cout << endl;
		NOQ = (NOQ * 100) + 0.02;
		average = (average / 0.5) - 0.02;
		if (score > NOQ)
		{
			cout << "------------------------------------------------------------------------------"<< endl;
			cout << "Cannot achieve " << desiredGrade << " because Prelim Class Standing is too low"<<endl;
			cout << "The average you need is: " << average << "%";
		}																					
		else
		{																			
			cout << "The score you need to get in your exam in order to get " << desiredGrade << " is: " << round(score) << endl;
			cout << "The average you need is: " << fixed<< setprecision (2)<< average << "%";
		}	
	}
	
	else if (choice == 2)
	{
		do
		{
			cout << "Enter the percentage of your class standing: ";
			cin >> midtermClassStanding;
		}while (midtermClassStanding <= 0 || midtermClassStanding > 100);
		do
		{
			cout << "Enter the percentage of your Prelim Grade: ";
			cin >> prelimGrade;
		} while (prelimGrade <= 0 || prelimGrade > 100);
		NOQ = numOfQuestions ();
		NOQ = NOQ / 100;
		midtermClassStanding = midtermClassStanding * 0.3333333333;
		prelimGrade = prelimGrade * 0.3333333333;
		average = desiredGrade - (midtermClassStanding + prelimGrade);
		score = average / 0.3333333333;
		score = score * NOQ;
		cout << endl;
		NOQ = (NOQ * 100) + 0.02;
		average = (average / 0.3333333333) - 0.02;
		if (score > NOQ)
		{
			if (midtermClassStanding < prelimGrade)
			{
				cout << "------------------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Midterm Class Standing is too low"<<endl;
				cout << "The average you need is: " << average << "%";
			}
			else
			{
				cout << "--------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Prelim Grade is too low"<<endl;
				cout << "The average you need is: " << average << "%";
			}
		}
		else
		{
			cout << "The score you need to get in your exam in order to get " << desiredGrade << " is: " << round(score) << endl;
			cout << "The average you need is: " << average << "%"<<endl;
			
		}
	}
	
	else
	{
		do
		{
			cout << "Enter the percentage of your class standing: ";
			cin >> finalClassStanding;
		}while (finalClassStanding <= 0 || finalClassStanding > 100);
		do
		{
			cout << "Enter the percentage of your Midterm Grade: ";
			cin >> midtermGrade;
		} while (midtermGrade <= 0 || midtermGrade > 100);
		NOQ = numOfQuestions ();
		NOQ = NOQ / 100;
		finalClassStanding = finalClassStanding * 0.3333333333;
		midtermGrade = midtermGrade * 0.3333333333;
		score = desiredGrade - (finalClassStanding + midtermGrade);
		score = average / 0.3333333333;
		score = score * NOQ;
		cout << endl;
		NOQ = (NOQ * 100) + 0.02;
		average = (average / 0.3333333333) - 0.02;
		if (score > NOQ)
		{
			if (finalClassStanding < midtermGrade)
			{
				cout << "----------------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Final Class Standing is too low"<<endl;
				cout << "The average you need is: " << average << "%";
			}
			else
			{
				cout << "---------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Midterm Grade is too low"<<endl;
				cout << "The average you need is: " << average << "%";
			}
		}
		else
		{
			cout << "The score you need to get in your exam in order to get " << desiredGrade << " is: " << round(score) << endl;
			cout << "The average you need is: " << average << "%";
		}
	}
	return 0;
}
	

int numOfQuestions ()
{
	int NOQ;
	do
	{
	cout << "Enter your predicted number of question in your exam: ";
	cin >> NOQ;
	}while (NOQ <= 0);
	return NOQ;
}
