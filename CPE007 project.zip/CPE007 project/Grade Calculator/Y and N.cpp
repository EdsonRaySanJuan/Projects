#include <string>
#include <iostream>
using namespace std;

string ans, Y, N;

int main ()
{
	do
	{
	
		do
		{
			//lagay mo rito gagawin mo
			cout << "Do you want to enter again (Y/N): ";
			cin >>ans;           
		} while (ans != "Y" && ans != "N");
	
	} while (ans == "Y");
}
