#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
using namespace std;

void header ()
{
	cout << " _____________________________________________________________________" << endl;
	cout << "|                                                                     |"<< endl;
	cout << "|                                                                     |"<< endl;
	cout << "|                          Grade Calculator                           |"<< endl;
	cout << "|                                                                     |"<< endl;
	cout << "|_____________________________________________________________________|"<< endl<<endl;
	
}
void option ()
{
	int choice;
	cout << " [1] Predict your Major Exam." << endl;
	cout << " [2] Calculate Overall Grades." << endl;
	cout << " [3] Calculate Class Standing."<< endl;
	cout << "______________________________________________________________________"<< endl;
}
//functions for phase 1
//-----------------------------------------------------------------------------------------------------------------
void headerfor1 ()
{
	cout << "*---------------------------------------------------------------*"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*                   Predict your Major Exam                     *"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*---------------------------------------------------------------*"<<endl<<endl;
}
int numOfQuestions ()
{
	int NOQ;
	do
	{
	cout << "Enter your predicted number of question in your exam: ";
	cin >> NOQ;
	}while (NOQ <= 0);
	return NOQ;
}
int predictMajorexams ()
{

	double desiredGrade, prelimClassStanding, midtermClassStanding, prelimGrade, finalClassStanding, midtermGrade, NOQ, score, average;
    int choicefor1;
    
    do
    {
	    cout << "Enter your desired grade: ";
		cin >> desiredGrade;
	}while (desiredGrade < 0 || desiredGrade > 100);
	
	cout <<"_____________________________________________________"<<endl<<endl;
	cout << "Enter what grade period would you like to calculate" << endl;
    string grades [4] = {" ", """Prelims", "Midterms","Finals"};
    cout <<"  [1] Preliminary   [2] Mid-Term   [3] Final"<<endl;
    cout <<"_____________________________________________________"<<endl; 
    
    
    do
    {
    	cout << "Enter what grade you want to evaluate: ";
    	cin >> choicefor1;
	}while (choicefor1 < 1||choicefor1 > 3);
	cout << "you picked " << grades [choicefor1] <<endl;
	cout <<"_____________________________________________________"<<endl;
	cout << endl;
	
	if (choicefor1 == 1)
	{
		do
		{
			cout << "Enter the percentage of your class standing: ";
			cin >> prelimClassStanding;
		}while (prelimClassStanding < 0 || prelimClassStanding > 100);
		NOQ = numOfQuestions ();
		NOQ = NOQ / 100;
		prelimClassStanding = prelimClassStanding * 0.5;
		average = desiredGrade - prelimClassStanding;
		score = average / 0.5;
		score = score * NOQ;
		cout << endl;
		NOQ = (NOQ * 100) + 0.02;
		average = (average / 0.5) - 0.02;
		if (score > NOQ)
		{
			cout << "------------------------------------------------------------------------------"<< endl;
			cout << "Cannot achieve " << desiredGrade << " because Prelim Class Standing is too low"<<endl;
			cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%";
		}																					
		else
		{																			
			cout << "The score you need to get for your exam in order to get " << desiredGrade << " is: " << round(score) << endl;
			cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%";
		}	
	}
	
	else if (choicefor1 == 2)
	{
		do
		{
			cout << "Enter the percentage of your class standing: ";
			cin >> midtermClassStanding;
		}while (midtermClassStanding < 0 || midtermClassStanding > 100);
		do
		{
			cout << "Enter the percentage of your Prelim Grade: ";
			cin >> prelimGrade;
		} while (prelimGrade < 0 || prelimGrade > 100);
		NOQ = numOfQuestions ();
		NOQ = NOQ / 100;
		midtermClassStanding = midtermClassStanding * 0.3333333333;
		prelimGrade = prelimGrade * 0.3333333333;
		average = desiredGrade - (midtermClassStanding + prelimGrade);
		score = average / 0.3333333333;
		score = score * NOQ;
		cout << endl;
		NOQ = (NOQ * 100) + 0.02;
		average = (average / 0.3333333333) - 0.02;
		if (score > NOQ)
		{
			if (midtermClassStanding < prelimGrade)
			{
				cout << "------------------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Midterm Class Standing is too low"<<endl;
				cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%";
			}
			else
			{
				cout << "--------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Prelim Grade is too low"<<endl;
				cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%";
			}
		}
		else
		{
			cout << "The score you need to get for your exam in order to get " << desiredGrade << " is: " << round(score) << endl;
			cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%"<<endl;
			
		}
	}
	
	else
	{
		do
		{
			cout << "Enter the percentage of your class standing: ";
			cin >> finalClassStanding;
		}while (finalClassStanding < 0 || finalClassStanding > 100);
		do
		{
			cout << "Enter the percentage of your Midterm Grade: ";
			cin >> midtermGrade;
		} while (midtermGrade < 0 || midtermGrade > 100);
		NOQ = numOfQuestions ();
		NOQ = NOQ / 100;
		finalClassStanding = finalClassStanding * 0.3333333333;
		midtermGrade = midtermGrade * 0.3333333333;
		average = desiredGrade - (finalClassStanding + midtermGrade);
		score = average / 0.3333333333;
		score = score * NOQ;
		cout << endl;
		NOQ = (NOQ * 100) + 0.02;
		average = (average / 0.3333333333) - 0.02;
		if (score > NOQ)
		{
			if (finalClassStanding < midtermGrade)
			{
				cout << "----------------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Final Class Standing is too low"<<endl;
				cout << "The average you need is: " << fixed<< setprecision (2)<< round (average)<< "%";
			}
			else
			{
				cout << "---------------------------------------------------------------------"<< endl;
				cout << "Cannot achieve " << desiredGrade << " because Midterm Grade is too low"<<endl;
				cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%";
			}
		}
		else
		{
			cout << "The score you need to get for your exam in order to get " << desiredGrade << " is: " << round(score) << endl;
			cout << "The average you need is: " << fixed<< setprecision (2)<< round (average) << "%";
		}
	}

}
//-----------------------------------------------------------------------------------------------------------------

//functions for phase 2
//-----------------------------------------------------------------------------------------------------------------
void headerfor2 ()
{
	cout << "*---------------------------------------------------------------*"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*                   Calculate Overall Grades                    *"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*---------------------------------------------------------------*"<<endl<<endl;
}
int optionfor2 ()
{
	int choicefor2;
	cout <<"  [1] Preliminary   [2] Mid-Term   [3] Final"<<endl;
	cout <<"_____________________________________________________"<<endl<<endl;
	cout <<"What do you want to calculate?: ";
	cin >>choicefor2;
	cout <<"_____________________________________________________"<<endl<<endl;	
	return choicefor2;
}
double PG ()
{
	
	double PCS, PE, PG;
	double prelimGrade;
	cout <<"Enter your Class Standing: ";
	cin >>PCS;
	
	cout <<"Enter your Preliminary Exam: " ;
	cin >>PE;
		
	prelimGrade = (PCS * 0.5) + (PE * 0.5);

	return prelimGrade;
}
double MG ()
{
	double MCS, ME, MG, PG;
	
	cout <<"Enter your Class Standing: ";
	cin >>MCS;
	
	cout <<"Enter your Mid-Term Exam: " ;
	cin >>ME;
	
	cout <<"Enter your Preliminary Grade: ";
	cin >>PG;
	
	double partialMG = (MCS * 0.5) + (ME * 0.5);
	
	MG = (partialMG * 2/3) + (PG * 1/3);
	double midtermGrade = MG;
	return midtermGrade;
}
double FG ()
{
	double FCS, FE, FG, MG;
	
	cout <<"Enter your Class Standing: ";
	cin >>FCS;
	
	cout <<"Enter your Final Exam: " ;
	cin >>FE;
	
	cout <<"Enter your Mid-Term Grade: ";
	cin >>MG;
	
	double partialFG = (FCS * 0.5) + (FE * 0.5);
	
	FG = (partialFG * 2/3) + (MG * 1/3);
	double finalGrade = FG;

	return finalGrade;
}
double gradingScheme(double grade)
{
	
	;
	if (grade >= 94 && grade <= 100)
	{
		grade = 1.00;
	}
	else if (grade >= 88.5 && grade <= 93.99)
	{
		grade = 1.25;
	}
	else if (grade >= 83 && grade <= 88.49)
	{
		grade = 1.50;
	}
	else if (grade >= 77.5 && grade <= 82.99)
	{
		grade = 1.75;
	}
	else if (grade >= 72 && grade <= 77.49)
	{
		grade = 2.00;
	}
	else if (grade >= 65.5 && grade <= 71.99)
	{
		grade = 2.25;
	}
	else if (grade >= 61 && grade <= 65.49)
	{
		grade = 2.50;
	}
	else if (grade >= 55.5 && grade <= 60.99)
	{
		grade = 2.75;
	}
	else if (grade >= 50 && grade <= 55.49)
	{
		grade = 3.00;
	}
	else 
	{
		grade = 5.00;
	}
	
	double gradeEquiv = grade;
	return gradeEquiv;
}
int calculatefor2 (int choicefor2)
{
	if (choicefor2 == 1)
	{
		double grade = PG ();
		double gradeEquiv = gradingScheme(grade);
		cout <<"_____________________________________________________"<<endl;
		cout <<"Your Preliminary Grade is: "<<grade<<endl;
//		cout <<"Your Preliminary Grade is (Rounded Off): "<< round(grade*100)/100 <<endl;
		cout <<"Your Equivalent Grade is: "<< fixed << setprecision(2) << gradeEquiv <<endl;
	}
	else if (choicefor2 == 2)
	{
		double grade= MG ();
		double gradeEquiv = gradingScheme(grade);
		cout <<"_____________________________________________________"<<endl;
		cout <<"Your Mid-Term Grade is: "<<grade <<endl;
//		cout <<"Your Mid-Term Grade is (Rounded Off): "<<round(grade*100)/100<<endl;
		cout <<"Your Equivalent Grade is: "<< fixed << setprecision(2) << gradeEquiv <<endl;	
	}
	else if (choicefor2 == 3)
	{
		double grade= FG ();
		double gradeEquiv = gradingScheme(grade);
		cout <<"_____________________________________________________"<<endl;
		cout <<"Your Final Grade is: "<<grade<<endl;
//		cout <<"Your Final Grade is (Rounded Off): "<<round(grade*100)/100<<endl;
		cout <<"Your Equivalent Grade is: "<< fixed << setprecision(2) << gradeEquiv <<endl;
	}
	else
	cout <<"Invalid Input";
}
//functions for phase 3
//-----------------------------------------------------------------------------------------------------------------
void headerfor3 ()
{
	cout << "*---------------------------------------------------------------*"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*                   Calculate Class Standing                    *"<<endl;
	cout << "*                                                               *"<<endl;
	cout << "*---------------------------------------------------------------*"<<endl<<endl;
}
double calculatePercentage(int score, int total) 
{			
    return static_cast<double>(score) / total * 100;
}
double calculateOverallTotal(double* percentages, int numItems) 
{
    double total;
    for (int i = 0; i < numItems; i++) {			
        total += percentages[i];
    }
    return total / numItems;
}
double getPercentEquivalent(const string& category) 
{
    double percentEquivalent;
    double decimalEqui;									
    cout << "Enter percent equivalent for " << category << ": ";
    cin >> percentEquivalent;
    cout << "_______________________________________________________________" << endl;
    decimalEqui = percentEquivalent / 100;
    return decimalEqui;
}
void processCategory(const string category, double& classStanding) 
{
    char hasCategory;
    cout << "Do you have " << category << "? (Y/N): ";				
    cin >> hasCategory;
    cout << endl;
													

    if (hasCategory == 'Y' || hasCategory == 'y') {
        int numItems;
        cout << "How many " << category << " do you have?: ";
        cin >> numItems;
        cout << "_______________________________________________________________" << endl;
        

        double* percentages = new double[numItems];						

        for (int i = 0; i < numItems; i++) {			
            int score, total;
            do {
			cout << "Enter your score for " << category << " " << i + 1 << ": ";
            cin >> score;
        	} 
        	while (score < 0 || score > 100);
            
            do {
			cout << "Enter the total for " << category << " " << i + 1 << ": ";
            cin >> total;
        	}
        	while (total < 0 || total > 100);
    
            double percentage = calculatePercentage(score, total);
            cout << "Percentage for " << category << " " << i + 1 << ": " << fixed << setprecision(2) << percentage << "%" << endl<<endl;

            percentages[i] = percentage;
           
        }

        double overallTotal = calculateOverallTotal(percentages, numItems);		
        double percentEquivalent = getPercentEquivalent(category);
        double finalResult = overallTotal * percentEquivalent;

        cout << "Overall total percentage for " << category << ": " << fixed << setprecision(2) << overallTotal << "%" << endl;
        cout << "Final for this category: " << finalResult << "%" << endl;
        cout << "_______________________________________________________________" << endl;

        classStanding += finalResult; 
        delete[] percentages;
    } else if (hasCategory == 'N' || hasCategory == 'n') {
        cout << "No " << category << "." << endl;
        cout << "_______________________________________________________________" << endl;
    } else {
        cout << "Invalid input for " << category << "." << endl;
    }
}
//-----------------------------------------------------------------------------------------------------------------

int calculation ()
{
	int choice;

	cout << " What do you want to do?: ";
	cin >> choice;
	cout << endl;
	
	if (choice == 1)
	{
		string ans, Y, N;
		do
		{
			system ("CLS");
			headerfor1 ();
			predictMajorexams ();
			cout <<endl;
			cout <<"_____________________________________________________"<<endl;
			do
			{
				cout << "Do you want to enter again (Y/N): ";
				cin >>ans;    
			    
			} while (ans != "Y" && ans != "N");
			system ("CLS");
		} while (ans == "Y");
	
	}
	else if (choice == 2)
	{
		string ans, Y, N;
		do
		{
			system ("CLS");
			headerfor2 ();
			int choicefor2 = optionfor2 ();
			calculatefor2 (choicefor2);
			cout <<"_____________________________________________________"<<endl;
			do
			{
				cout << "Do you want to calculate again (Y/N): ";
				cin >>ans;           
			} while (ans != "Y" && ans != "N");
			system ("CLS");
		} while (ans == "Y");	
	}
	else if (choice == 3)
	{
		string ans, Y, N;
	    do
		{
				system ("CLS");
			    double classStanding;
				headerfor3 ();
			    processCategory("quiz", classStanding);				
			    processCategory("assignment", classStanding);
			    processCategory("seatwork", classStanding);
			    processCategory("activity", classStanding);
			    processCategory("laboratory", classStanding);
			    processCategory("homework", classStanding);
			    processCategory("recitation", classStanding);
			
			    cout << "Class standing: " << fixed << setprecision(2) << classStanding << "%" << endl;
			    cout << "_______________________________________________________________" << endl;			
	  		do
			{
				cout << "Do you want to enter again (Y/N): ";
				cin >>ans;           
			} while (ans != "Y" && ans != "N");
			system ("CLS");
		} while (ans == "Y");
	}
	else 
	{
		cout <<"Invalid Input."<<endl;
	}
	
}
void credits ()
{
	cout << "Thank you for using our program!" <<endl<<endl;
	cout << "Programmers: "<<endl<<endl;
	cout << "BONA, ANDREI NYCOLE SO" << endl;
	cout << "ANTIPOLO, JOHN PAUL" << endl;
	cout << "EREBETE, JAN KENNETH" << endl;
	cout << "SAN JUAN, EDSON RAY" << endl;
	cout << "TIONG, MARTIN ANDREI" << endl;
	cout << endl;
	cout << "CPE 007 Programming Logic and Design."<<endl;
	cout << "CPE 11S2, A.Y. 2023-2024."<<endl;
}
int menu ()
{
	string ans, Y, N;
	do
	{
		header ();
		option ();
		calculation ();	
		do
		{
			cout << "_______________________________________________________________" << endl;
			cout << "Do you want to go back to menu? (Y/N): ";
			cin >>ans;           
		} while (ans != "Y" && ans != "N");
		system ("CLS");
	} while (ans == "Y");
}

int main ()
{
	menu ();
	credits ();
	
	return 0;
}
